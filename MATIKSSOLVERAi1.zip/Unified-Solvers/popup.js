const solvers = [
  { id: 'sprint-duel', name: 'Sprint Duel', file: 'sprint-duel-popup.html', logo: 'solvers/sprint-duel/branding/math-duel-logo-square.png' },
  { id: 'ability-duels', name: 'Ability Duels', file: 'ability-duels-popup.html', logo: 'solvers/ability-duels/icons/icon128.png' },
  { id: 'mind-snap', name: 'MindSnap', file: 'mind-snap-popup.html', logo: 'solvers/mind-snap/assets/icon-128.png' },
  { id: 'flash-anzan', name: 'Flash Anzan', file: 'flash-anzan-popup.html', logo: 'solvers/flash-anzan/icon128.png' },
  { id: 'sudoku', name: 'Sudoku', file: 'sudoku-popup.html', logo: 'solvers/sudoku/branding/sudoku-green-mark.png' },
  { id: 'cross-math', name: 'Cross Math', file: 'cross-math-popup.html', logo: 'solvers/cross-math/branding/math-lightning-x-logo.png' },
  { id: 'ken-ken', name: 'Ken-Ken', file: 'ken-ken-popup.html', logo: 'solvers/ken-ken/branding/kenken-logo-128.png' },
  { id: 'math-maze', name: 'Math Maze', file: 'math-maze-popup.html', logo: 'solvers/math-maze/branding/math-maze-solver-logo.png' }
];

const list = document.getElementById('solver-list');
const picker = document.getElementById('picker');
const view = document.getElementById('solver-view');
const frameWrap = document.getElementById('solver-frame-wrap');
const back = document.getElementById('back');

function renderList() {
  list.replaceChildren(...solvers.map(solver => {
    const button = document.createElement('button');
    button.className = 'solver-card';
    button.type = 'button';
    button.innerHTML = `<img class="solver-logo" src="${solver.logo}" alt=""><span class="solver-name">${solver.name}</span>`;
    button.addEventListener('click', () => openSolver(solver));
    return button;
  }));
}

async function openSolver(solver) {
  chrome.storage.local.set({ hubLastSolver: solver.id });
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const selected = await chrome.runtime.sendMessage({ type: 'HUB_SELECT_SOLVER', solverId: solver.id, tabId: tab?.id });
    if (!selected?.ok) throw new Error(selected?.error || 'Could not activate solver.');
    if (Number.isInteger(tab?.id)) {
      const injected = await chrome.runtime.sendMessage({ type: 'HUB_INJECT_SOLVER', solverId: solver.id, tabId: tab.id });
      if (!injected?.ok) throw new Error(injected?.error || 'Could not connect solver to the game page.');
    }
  } catch (error) {
    console.warn('Solver activation warning:', error);
  }
  const frame = document.createElement('iframe');
  frame.className = 'solver-frame';
  frame.title = `${solver.name} solver`;
  frame.src = `solvers/${solver.id}/${solver.file}`;
  frame.addEventListener('load', () => {
    // Stable per-solver bounds. Never measure the hub or changing iframe DOM.
    // MindSnap is compact but tall enough to show its full lower puzzle.
    const bounds = {
      'sprint-duel': { width: 226, height: 310 },
      'ability-duels': { width: 226, height: 310 },
      'mind-snap': { width: 226, height: 430 },
      'flash-anzan': { width: 286, height: 430 },
      'sudoku': { width: 226, height: 330 },
      'cross-math': { width: 300, height: 470 },
      'ken-ken': { width: 230, height: 360 },
      'math-maze': { width: 220, height: 330 }
    };
    const size = bounds[solver.id] || { width: 232, height: 360 };
    const width = size.width;
    const height = size.height;
    frame.style.width = `${width}px`;
    frame.style.height = `${height}px`;
    frame.style.transform = 'none';
    frame.style.transformOrigin = 'top center';
    frame.style.display = 'block';
    frame.style.margin = '0 auto';
    frame.style.overflow = 'hidden';
    frameWrap.style.width = `${width}px`;
    frameWrap.style.height = `${height}px`;
    frameWrap.style.margin = '0 auto';
    frameWrap.style.display = 'flex';
    frameWrap.style.justifyContent = 'center';
    frameWrap.style.overflow = 'hidden';
    view.style.width = `${width + 10}px`;
    view.style.height = `${height + 28}px`;
    view.style.margin = '0 auto';
    document.documentElement.style.width = `${width + 10}px`;
    document.body.style.width = `${width + 10}px`;
    document.documentElement.style.height = `${height + 28}px`;
    document.body.style.height = `${height + 28}px`;
  });
  frameWrap.replaceChildren(frame);
  document.documentElement.classList.add('solver-mode');
  document.body.classList.add('solver-mode');
  picker.classList.add('hidden');
  view.classList.remove('hidden');
}

back.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    await chrome.runtime.sendMessage({ type: 'HUB_CLEAR_SOLVER', tabId: tab?.id });
  } catch (_) {}
  frameWrap.replaceChildren();
  document.documentElement.classList.remove('solver-mode');
  document.body.classList.remove('solver-mode');
  document.documentElement.style.width = '';
  document.body.style.width = '';
  view.style.width = '';
  frameWrap.style.width = '';
  view.classList.add('hidden');
  picker.classList.remove('hidden');
});

renderList();
