const $ = id => document.getElementById(id);
const solveButton = $('solve');
const autoButton = $('autoButton');
const status = $('status');
const dot = $('statusDot');
let autoModeOn = false;

function setStatus(text, good = true) {
  status.textContent = text;
  dot.style.background = good ? '#ffd400' : '#e04b4b';
  dot.style.boxShadow = `0 0 8px ${good ? '#ffd400' : '#e04b4b'}`;
}

async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab?.id;
}

async function action(name, extra = {}) {
  const tabId = await activeTabId();
  if (!tabId) throw new Error('No active tab found.');
  const result = await chrome.runtime.sendMessage({ type: 'SPRINT_DUEL_POPUP_ACTION', action: name, tabId, ...extra });
  return result || { ok: false, error: 'No response from the active tab.' };
}

solveButton.addEventListener('click', async () => {
  if (solveButton.disabled) return;
  solveButton.disabled = true;
  setStatus('Solving…');
  try {
    const result = await action('solve', { submit: true });
    if (!result.ok) { setStatus(result.error || 'Solver did not find a path.', false); return; }
    setStatus('Solved');
  } catch (error) {
    setStatus(error.message || 'Extension communication failed.', false);
  } finally {
    solveButton.disabled = false;
  }
});

autoButton.addEventListener('click', async () => {
  if (autoButton.disabled) return;
  autoButton.disabled = true;
  const nextAction = autoModeOn ? 'stop' : 'start';
  setStatus(autoModeOn ? 'Stopping…' : 'Starting Auto…');
  try {
    const result = await action(nextAction, { autoSubmit: true });
    if (!result.ok) throw new Error(result.error || 'Could not change Auto Mode.');
    autoModeOn = nextAction === 'start';
    autoButton.classList.toggle('active', autoModeOn);
    autoButton.setAttribute('aria-pressed', String(autoModeOn));
    setStatus(autoModeOn ? 'Auto On' : 'Auto Off');
  } catch (error) {
    setStatus(error.message || 'Extension communication failed.', false);
  } finally {
    autoButton.disabled = false;
  }
});

chrome.runtime.sendMessage({ type: 'SPRINT_DUEL_GET_STATE' }).then(response => {
  const state = response?.state;
  if (!state) return;
  autoModeOn = Boolean(state.autoWatch);
  autoButton.classList.toggle('active', autoModeOn);
  autoButton.setAttribute('aria-pressed', String(autoModeOn));
  setStatus(state.status || 'Ready', !/error|found|failed/i.test(state.status || ''));
}).catch(() => {});

chrome.storage.onChanged.addListener(changes => {
  const state = changes.sprintDuelState?.newValue;
  if (!state) return;
  autoModeOn = Boolean(state.autoWatch);
  autoButton.classList.toggle('active', autoModeOn);
  autoButton.setAttribute('aria-pressed', String(autoModeOn));
  setStatus(state.status || 'Ready', !/error|found|failed/i.test(state.status || ''));
});
