if (!globalThis.__MATIKS_SPRINT_DUEL_CONTENT_LOADED__) {
  globalThis.__MATIKS_SPRINT_DUEL_CONTENT_LOADED__ = true;
(() => {
  'use strict';

  const MAX_ROWS = 40;
  let watchObserver = null;
  let watchQueued = false;
  let lastExpression = '';
  let autoSubmit = true;
  const unresolvedGlyphs = new Set();
  let wrapperCache = null;
  let wrapperCacheAt = 0;
  const domObserver = new MutationObserver(() => { wrapperCache = null; });
  domObserver.observe(document.documentElement, { subtree: true, childList: true, characterData: true });

  // Optional per-site calibration. A fingerprint can be stored as { char, signature }.
  const learnedGlyphs = new Map();
  const variantGlyphs = new Map();
  chrome.storage?.local.get(['sprintDuelGlyphMap', 'sprintDuelVariantMap']).then(({ sprintDuelGlyphMap, sprintDuelVariantMap }) => {
    for (const [signature, char] of Object.entries(sprintDuelGlyphMap || {})) learnedGlyphs.set(signature, char);
    for (const [signature, char] of Object.entries(sprintDuelVariantMap || {})) variantGlyphs.set(signature, char);
  }).catch(() => {});
  function saveVariant(signature, char) {
    if (!signature || !/^[0-9]$/.test(char) || variantGlyphs.has(signature)) return;
    variantGlyphs.set(signature, char);
    const payload = Object.fromEntries([...variantGlyphs].slice(-160));
    chrome.storage?.local.set({ sprintDuelVariantMap: payload }).catch(() => {});
  }
  const BUILTIN_HINTS = new Map([
    ['plus', '+'], ['minus', '-']
  ]);

  const cleanPath = (d) => String(d || '').trim().replace(/\s+/g, ' ');
  function fingerprint(d) {
    const value = cleanPath(d);
    if (!value) return '';
    // Ignore small coordinate drift while preserving command structure and relative shape.
    const commands = (value.match(/[a-zA-Z]/g) || []).join('').toUpperCase();
    const nums = (value.match(/-?\d*\.?\d+/g) || []).map(Number);
    if (!nums.length) return commands;
    const min = Math.min(...nums), max = Math.max(...nums);
    const span = Math.max(0.001, max - min);
    const normalized = nums.map(n => ((n - min) / span).toFixed(2)).join(',');
    return `${commands}|${normalized}`;
  }
  function shapeSignature(d) {
    const value = cleanPath(d);
    const commands = (value.match(/[a-zA-Z]/g) || []).join('').toUpperCase();
    const nums = (value.match(/-?\d*\.?\d+/g) || []).map(Number);
    if (!nums.length) return commands;
    const min = Math.min(...nums), max = Math.max(...nums), span = Math.max(0.001, max - min);
    return `${commands}|${nums.map(n => Math.round(((n - min) / span) * 20) / 20).join(',')}`;
  }
  function shapeSimilarity(a, b) {
    if (!a || !b) return 0;
    const [ac, an = ''] = a.split('|'), [bc, bn = ''] = b.split('|');
    const commandScore = ac === bc ? 1 : Math.min(ac.length, bc.length) / Math.max(ac.length, bc.length);
    const av = an.split(',').filter(Boolean).map(Number), bv = bn.split(',').filter(Boolean).map(Number);
    if (!av.length || !bv.length) return commandScore * 0.5;
    const n = Math.min(av.length, bv.length);
    let distance = 0;
    for (let i = 0; i < n; i++) distance += Math.min(1, Math.abs(av[i] - bv[i]));
    const numericScore = (n / Math.max(av.length, bv.length)) * (1 - distance / n);
    return commandScore * 0.35 + numericScore * 0.65;
  }
  function nearestVariant(raw) {
    const current = shapeSignature(raw);
    let best = { score: 0, char: null, signature: '' };
    for (const [signature, char] of variantGlyphs) {
      const score = shapeSimilarity(current, signature);
      if (score > best.score) best = { score, char, signature };
    }
    return best.score >= 0.76 ? best : null;
  }
  function coarseFingerprint(d) {
    const value = cleanPath(d);
    const commands = (value.match(/[a-zA-Z]/g) || []).join('').toUpperCase();
    const nums = (value.match(/-?\d*\.?\d+/g) || []).map(Number);
    if (!nums.length) return commands;
    const rounded = nums.map(n => Math.round(n * 4) / 4).join(',');
    return `${commands}|${rounded}`;
  }

  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function rowScore(el) {
    const r = el.getBoundingClientRect();
    const paths = el.querySelectorAll('svg path').length;
    const text = (el.textContent || '').trim();
    return paths * 8 + (/[+\-\d]/.test(text) ? 6 : 0) + Math.min(20, r.width / 50);
  }
  function candidateRows() {
    const all = [...document.querySelectorAll('div, section, li, p, [role="row"]')];
    const rows = all.filter(el => {
      if (!visible(el)) return false;
      const paths = el.querySelectorAll('svg path');
      if (!paths.length || paths.length > 16) return false;
      const r = el.getBoundingClientRect();
      const knownRow = el.className && String(el.className).includes('css-g5y9jx');
      return knownRow || (r.height >= 10 && r.height <= 120 && r.width > 1);
    });
    // Prefer compact leaf-ish containers, removing nested duplicate candidates.
    const compact = rows.filter(el => ![...el.children].some(child => rows.includes(child) && rowScore(child) >= rowScore(el)));
    const known = [...document.querySelectorAll('[class*="css-g5y9jx"]')].filter(el => visible(el) && (el.querySelector('svg path') || /^[+\-×÷*/]$/.test((el.textContent || '').trim())));
    for (const el of known) if (!compact.includes(el)) compact.push(el);
    const byLine = new Map();
    for (const el of compact) {
      const r = el.getBoundingClientRect();
      const key = `${Math.round(r.top / 5)}:${Math.round(r.height / 5)}`;
      const previous = byLine.get(key);
      if (!previous || rowScore(el) > rowScore(previous)) byLine.set(key, el);
    }
    return [...byLine.values()].sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top).slice(0, MAX_ROWS);
  }

  function inferOperator(path, svg, parent) {
    const d = cleanPath(path.getAttribute('d'));
    const hint = `${path.getAttribute('aria-label') || ''} ${svg.getAttribute('aria-label') || ''} ${(parent.textContent || '').trim()}`.toLowerCase();
    if (/[+]/.test(hint)) return '+';
    if (/minus|subtract/.test(hint)) return '-';
    // Plus/minus glyphs are generally much wider than tall or have few path commands.
    const r = svg.getBoundingClientRect();
    const ratio = r.width / Math.max(1, r.height);
    const commandCount = (d.match(/[a-zA-Z]/g) || []).length;
    if (ratio > 0.85 && ratio < 1.35 && commandCount <= 8) return '+';
    if (ratio > 1.8 && commandCount <= 6) return '-';
    return null;
  }

  function glyphItems(row) {
    const seen = new Set();
    return [...row.querySelectorAll('svg')].filter(visible).map(svg => {
      const r = svg.getBoundingClientRect();
      const path = svg.querySelector(':scope > path') || svg.querySelector('path');
      return { svg, path, key: `${Math.round(r.left)}:${Math.round(r.top)}:${Math.round(r.width)}:${Math.round(r.height)}:${fingerprint(path?.getAttribute('d'))}` };
    }).filter(item => item.path && !seen.has(item.key) && (seen.add(item.key), true)).sort((a, b) => a.svg.getBoundingClientRect().left - b.svg.getBoundingClientRect().left);
  }

  const BUILTIN_PROFILES = [
    { char: '9', markers: ['M6.72 6.96', 'Q9.02 6.96', 'Q5.76 24.24', 'Q6.89 9.41', 'Q5.93 9.41', 'Q8.02 9.41', 'Q6.36 17.57'] },
    { char: '6', markers: ['M6.72 6.96', 'Q9.02 6.96', 'Q5.76 24.24', 'Q4.73 16.93', 'Q6.79 14.04'] }
  ];
  function builtinSimilarity(raw) {
    const compact = raw.replace(/\s+/g, '');
    let best = null;
    for (const profile of BUILTIN_PROFILES) {
      const hits = profile.markers.filter(marker => compact.includes(marker.replace(/\s+/g, ''))).length;
      const score = hits / profile.markers.length;
      if (!best || score > best.score) best = { char: profile.char, score };
    }
    return best && best.score >= 0.42 ? best.char : null;
  }
  function glyphChar(path, index, svg, row) {
    const raw = cleanPath(path.getAttribute('d'));
    const builtin = raw.startsWith('M8.06 24.24') ? '0' : raw.startsWith('M6.86 24') ? '1' : raw.startsWith('M13.22 24') ? '2' : raw.startsWith('M6.34 24.24') ? '3' : raw.startsWith('M16.03 20.18') ? '4' : raw.startsWith('M6.62 24.24') ? '5' : raw.startsWith('M8.33 24.24') ? '6' : raw.startsWith('M7.20 24') ? '7' : raw.startsWith('M7.80 24.24') ? '8' : /^M6\.72\s+6\.96\s*L\s*6\.72\s+6\.96/.test(raw) && raw.includes('Q3.42 16.93') ? '6' : /^M6\.72\s+6\.96\s*L\s*6\.72\s+6\.96/.test(raw) && (raw.includes('Q4.73 16.93') || raw.includes('Q6.89 9.41')) ? '9' : null;
    if (builtin) { saveVariant(shapeSignature(raw), builtin); return builtin; }
    const similar = builtinSimilarity(raw);
    if (similar) { saveVariant(shapeSignature(raw), similar); return similar; }
    const sig = fingerprint(path.getAttribute('d'));
    const coarse = coarseFingerprint(path.getAttribute('d'));
    if (learnedGlyphs.has(sig)) return learnedGlyphs.get(sig);
    for (const [known, char] of learnedGlyphs) if (known === coarse || known.startsWith(`${coarse}|`)) { saveVariant(shapeSignature(raw), char); return char; }
    const nearest = nearestVariant(raw);
    if (nearest) { saveVariant(shapeSignature(raw), nearest.char); return nearest.char; }
    const op = inferOperator(path, svg, row);
    if (op) return op;
    unresolvedGlyphs.add(`${fingerprint(raw).slice(0, 80)} | ${raw.slice(0, 90)}`);
    // Sites sometimes expose an invisible/accessibility label on the SVG or wrapper.
    const hint = [path.getAttribute('data-char'), path.getAttribute('aria-label'), svg.getAttribute('data-char'), svg.getAttribute('aria-label')].filter(Boolean).join('');
    if (/^[0-9]$/.test(hint)) return hint;
    // A calibration hook: digits can be learned from a DOM attribute or external mapping.
    const dataMap = document.documentElement.dataset.mathGlyphMap;
    if (dataMap) {
      try {
        const map = JSON.parse(dataMap);
        if (map[sig] || map[coarse]) return map[sig] || map[coarse];
      } catch {}
    }
    return '?';
  }

  function extractRowValue(row) {
    const visual = glyphItems(row).map((item, i) => ({ x: item.svg.getBoundingClientRect().left, value: glyphChar(item.path, i, item.svg, row) }));
    const operators = [...row.querySelectorAll('div,span,p')].filter(el => {
      if (!visible(el) || el.children.length || !/^[+\-×÷*/]$/.test((el.textContent || '').trim())) return false;
      return true;
    }).map(el => ({ x: el.getBoundingClientRect().left, value: el.textContent.trim() }));
    const merged = [...visual, ...operators].sort((a, b) => a.x - b.x);
    const value = merged.map(item => item.value).join('');
    const direct = (row.textContent || '').replace(/\s+/g, '');
    return /[+\-×÷*/]/.test(direct) && /\d/.test(value) ? value : value.replace(/[^0-9?]/g, '');
  }
  function boardRoot() {
    const candidates = [...document.querySelectorAll('div')].filter(el => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const paths = el.querySelectorAll('svg path').length;
      return r.width >= 180 && r.width <= 600 && r.height >= 120 && r.height <= 520 && Math.abs(cx - innerWidth / 2) < innerWidth * 0.28 && paths >= 2;
    });
    return candidates.sort((a, b) => (a.getBoundingClientRect().width * a.getBoundingClientRect().height) - (b.getBoundingClientRect().width * b.getBoundingClientRect().height))[0] || document;
  }
  function questionBox() {
    // The game uses separate sibling wrappers for each visual token; using the
    // exact wrapper selector plus viewport geometry is more reliable than
    // choosing a single nested ancestor that may contain only one row.
    return document;
  }
  function directGlyphWrappers() {
    const now = performance.now();
    if (wrapperCache && now - wrapperCacheAt < 100) return wrapperCache;
    const root = questionBox();
    const exact = [...root.querySelectorAll('div.css-g5y9jx.r-12ym1je')];
    const fallback = [...root.querySelectorAll('div[class*="css-g5y9jx"]')].filter(el => String(el.className).includes('r-12ym1je'));
    const all = [...new Set([...exact, ...fallback])];
    wrapperCache = all.filter(el => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      const inBoardBand = r.top > 70 && r.top < innerHeight * 0.82 && Math.abs((r.left + r.width / 2) - innerWidth / 2) < innerWidth * 0.45;
      const hasPath = Boolean(el.querySelector('svg > path, svg path'));
      const text = (el.textContent || '').trim();
      const isOperator = /^[+\-×÷*/]$/.test(text);
      return inBoardBand && r.height >= 26 && r.height <= 36 && (hasPath || isOperator);
    });
    wrapperCacheAt = now;
    return wrapperCache;
  }
  function extractRows() {
    const groups = new Map();
    for (const wrapper of directGlyphWrappers()) {
      const r = wrapper.getBoundingClientRect();
      const key = Math.round((r.top + r.height / 2) / 5);
      if (!groups.has(key)) groups.set(key, []);
      const svg = wrapper.querySelector('svg');
      const path = svg?.querySelector(':scope > path') || svg?.querySelector('path');
      const text = (wrapper.textContent || '').trim();
      groups.get(key).push({ x: r.left, value: path ? glyphChar(path, 0, svg, wrapper) : (/^[+\-×÷*/]$/.test(text) ? text : '') });
    }
    return [...groups.entries()].sort((a, b) => a[0] - b[0]).map(([, group]) => group.sort((a, b) => a.x - b.x).map(t => t.value).join('')).filter(Boolean);
  }

  function normalizeExpressions(rows) {
    return rows.map(s => s.replace(/\?+/g, '').trim()).filter(s => /^[+\-]?\d+$/.test(s));
  }
  function calculate(rows) {
    const expressions = rows.map(s => s.replace(/\s+/g, '')).filter(Boolean);
    if (!expressions.length || !/^\d+$/.test(expressions[0])) return null;
    let total = Number(expressions[0]);
    if (!Number.isSafeInteger(total)) return null;
    for (const expression of expressions.slice(1)) {
      const match = expression.match(/^([+\-×÷*/])(\d+)$/);
      if (!match) return null;
      const operand = Number(match[2]);
      if (!Number.isSafeInteger(operand)) return null;
      const op = match[1];
      if (op === '+') total += operand;
      else if (op === '-') total -= operand;
      else if (op === '×' || op === '*') total *= operand;
      else if (op === '÷' || op === '/') { if (operand === 0) return null; total /= operand; }
      if (!Number.isFinite(total)) return null;
    }
    return { expressions, answer: String(total) };
  }

  function findInput() {
    const list = [...document.querySelectorAll('input:not([type="hidden"]), textarea, [contenteditable="true"]')];
    return list.filter(visible).sort((a, b) => {
      const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
      return (br.width * br.height) - (ar.width * ar.height);
    })[0] || null;
  }
  function setNativeValue(el, value) {
    el.focus();
    if (el.isContentEditable) el.textContent = value;
    else {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value')?.set?.call(el, value);
    }
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function fillAnswer(answer, submit = autoSubmit) {
    const input = findInput();
    if (!input) throw new Error('Visible answer input was not found.');
    setNativeValue(input, answer);
    if (submit) {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    }
    return true;
  }
  function extractionDiagnostics(rows) {
    const wrappers = directGlyphWrappers();
    const paths = wrappers.map(el => el.querySelector('svg path')).filter(Boolean);
    const operators = wrappers.filter(el => /^[+\-×÷*/]$/.test((el.textContent || '').trim()) && !el.querySelector('svg'));
    return { rowsFound: rows.length, visibleSvgPaths: paths.length, visibleOperators: operators.length, rawRows: rows, unresolved: rows.join('').match(/\?/g)?.length || 0, unresolvedSamples: [...unresolvedGlyphs].slice(0, 3), boardText: rows.join(' / ') || 'none' };
  }
  function extractAndMaybeFill(fill = false, submit = autoSubmit) {
    const rows = extractRows();
    const diagnostics = extractionDiagnostics(rows);
    const solved = calculate(rows);
    if (!solved) return { ok: false, rows, diagnostics, error: 'No readable arithmetic rows found.' };
    if (fill) fillAnswer(solved.answer, submit);
    return { ok: true, ...solved, diagnostics };
  }
  function runWatchScan() {
    if (!watchObserver) return;
    try {
      const result = extractAndMaybeFill(false, autoSubmit);
      if (result.ok && result.expressions.join('|') !== lastExpression) {
        lastExpression = result.expressions.join('|');
        try { fillAnswer(result.answer, autoSubmit); } catch {}
        chrome.runtime.sendMessage({ type: 'SPRINT_DUEL_SOLVER_RESULT', result }).catch(() => {});
      }
    } catch {}
  }
  function scheduleWatchScan() {
    if (watchQueued || !watchObserver) return;
    watchQueued = true;
    const run = () => { watchQueued = false; runWatchScan(); };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
    else setTimeout(run, 0);
  }
  function startWatch() {
    if (watchObserver) return;
    watchObserver = new MutationObserver(scheduleWatchScan);
    watchObserver.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
    // Scan immediately when Auto Solver Mode is enabled.
    scheduleWatchScan();
  }
  function stopWatch() {
    watchObserver?.disconnect();
    watchObserver = null;
    watchQueued = false;
  }

  function calibrateFromVisible(expression) {
    const expected = String(expression || '').replace(/\s+/g, '');
    const glyphs = candidateRows().flatMap(row => glyphItems(row).map(item => ({ path: item.path, svg: item.svg, row })));
    const chars = [...expected];
    if (!chars.length) throw new Error('No calibration characters supplied.');
    let learned = 0;
    glyphs.forEach((item, i) => { const char = chars[i]; if (/^[0-9+-]$/.test(char)) { learnedGlyphs.set(fingerprint(item.path.getAttribute('d')), char); learnedGlyphs.set(coarseFingerprint(item.path.getAttribute('d')), char); learned++; } });
    chrome.storage?.local.set({ sprintDuelGlyphMap: Object.fromEntries(learnedGlyphs) }).catch(() => {});
    return { ok: true, learned, message: `Learned ${learned} SVG glyphs.` };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    try {
      if (message.type === 'EXTRACT_TEXT' || message.type === 'SOLVE_NOW') return sendResponse(extractAndMaybeFill(message.type === 'SOLVE_NOW', message.submit !== false));
      if (message.type === 'SPRINT_DUEL_FILL_ANSWER') { fillAnswer(String(message.answer), message.submit !== false); return sendResponse({ ok: true }); }
      if (message.type === 'START_WATCH') { autoSubmit = message.autoSubmit !== false; startWatch(); return sendResponse({ ok: true }); }
      if (message.type === 'STOP_WATCH') { stopWatch(); return sendResponse({ ok: true }); }
      if (message.type === 'SET_GLYPH_MAP') { for (const item of message.items || []) learnedGlyphs.set(item.signature, item.char); return sendResponse({ ok: true }); }
      if (message.type === 'CALIBRATE') return sendResponse(calibrateFromVisible(message.expression));
    } catch (error) { return sendResponse({ ok: false, error: error.message }); }
    return false;
  });
})();

}
