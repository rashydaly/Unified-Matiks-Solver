const STORAGE_KEY = 'sprintDuelState';
const initialState = { autoWatch: false, status: 'Ready — open a Math Duel game.', lastAnswer: '', lastExpressions: [], updatedAt: 0 };

chrome.runtime.onInstalled.addListener(() => chrome.storage.local.set({ [STORAGE_KEY]: initialState }));

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SPRINT_DUEL_SOLVER_RESULT' && sender.tab?.id) {
    saveState({ lastAnswer: message.result.answer, lastExpressions: message.result.expressions, status: `Solved: ${message.result.answer}` });
    return false;
  }
  if (message.type === 'SPRINT_DUEL_POPUP_ACTION') {
    handleAction(message.action, message.tabId, message).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'SPRINT_DUEL_GET_STATE') {
    chrome.storage.local.get(STORAGE_KEY).then(data => sendResponse({ ok: true, state: { ...initialState, ...(data[STORAGE_KEY] || {}) } }));
    return true;
  }
});

async function handleAction(action, requestedTabId, message) {
  const tab = await resolveTab(requestedTabId);
  if (!tab.id) throw new Error('No active tab found.');
  const response = await sendToContent(tab.id, action === 'solve' ? { type: 'SOLVE_NOW', submit: message.submit !== false } : action === 'start' ? { type: 'START_WATCH', autoSubmit: message.autoSubmit !== false } : action === 'calibrate' ? { type: 'CALIBRATE', expression: message.expression } : { type: 'STOP_WATCH' });
  if (!response?.ok && action !== 'stop') {
    await saveState({ status: response?.error || 'DOM scan completed without a solution.' });
    return { ok: false, ...(response || {}), error: response?.error || 'DOM scan completed without a solution.' };
  }
  if (action === 'solve') await saveState({ lastAnswer: response.answer, lastExpressions: response.expressions, status: `Solved: ${response.answer}` });
  if (action === 'calibrate') await saveState({ status: response.message || 'Glyph calibration complete.' });
  if (action === 'start') await saveState({ autoWatch: true, status: 'Auto Solver Mode active.' });
  if (action === 'stop') await saveState({ autoWatch: false, status: 'Auto Solver Mode is off.' });
  return { ok: true, ...(response || {}) };
}
async function resolveTab(id) {
  if (Number.isInteger(id)) return chrome.tabs.get(id);
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab;
}
async function sendToContent(tabId, message) {
  try { return await chrome.tabs.sendMessage(tabId, message); }
  catch (firstError) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['solvers/sprint-duel/sprint-duel-content.js'] });
    return chrome.tabs.sendMessage(tabId, message).catch(() => { throw firstError; });
  }
}
async function saveState(patch) {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  const next = { ...initialState, ...(data[STORAGE_KEY] || {}), ...patch, updatedAt: Date.now() };
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}
