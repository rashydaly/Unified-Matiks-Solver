const $ = id => document.getElementById(id);
const startButton = $('startButton');
const statusEl = $('status');
const dot = $('dot');
const targetEl = $('target');
const boardPanel = $('boardPanel');
const mazeGrid = $('mazeGrid');
const SVG_NS = 'http://www.w3.org/2000/svg';
let busy = false;
let autoModeOn = false;

function setStatus(text, good = true, busyState = false) {
  statusEl.textContent = text;
  dot.className = `status-dot ${good ? 'good' : 'bad'}${busyState ? ' busy' : ''}`;
}

function svgNode(tag, attrs = {}) {
  const el = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, String(value));
  return el;
}

function renderMaze(result) {
  const rows = Number(result?.rows) || result?.grid?.length || 0;
  const cols = Number(result?.cols) || result?.grid?.[0]?.length || 0;
  const path = result?.solution?.path || [];
  const hasBoard = Boolean(rows && cols && result?.grid?.length);
  targetEl.textContent = hasBoard && result?.target != null ? result.target : '—';
  boardPanel.classList.toggle('is-hidden', !hasBoard);
  if (!hasBoard) {
    mazeGrid.replaceChildren();
    return;
  }

  const pathSet = new Set(path.map(p => `${p.r}:${p.c}`));
  mazeGrid.className = 'maze-board';
  mazeGrid.style.setProperty('--cols', String(cols));
  const svg = svgNode('svg', { viewBox: `0 0 ${cols} ${rows}`, role: 'img', 'aria-label': 'Math Maze solution path' });
  svg.append(svgNode('rect', { x: 0, y: 0, width: cols, height: rows, rx: .18, class: 'board-bg' }));
  if (path.length > 1) {
    const points = path.map(p => `${p.c + .5},${p.r + .5}`).join(' ');
    svg.append(svgNode('polyline', { points, class: 'tunnel-shadow' }));
    svg.append(svgNode('polyline', { points, class: 'tunnel' }));
    svg.append(svgNode('polyline', { points, class: 'tunnel-highlight' }));
  }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const key = `${r}:${c}`;
    const value = result.grid[r]?.[c] || '·';
    const isStart = r === result.start?.r && c === result.start?.c;
    const isEnd = r === result.end?.r && c === result.end?.c;
    const group = svgNode('g', { class: `maze-node${pathSet.has(key) ? ' on-path' : ''}${isStart ? ' start' : ''}${isEnd ? ' end' : ''}` });
    group.append(svgNode('circle', { cx: c + .5, cy: r + .5, r: .32 }));
    const text = svgNode('text', { x: c + .5, y: r + .59, 'text-anchor': 'middle' });
    text.textContent = value;
    group.append(text);
    svg.append(group);
  }
  mazeGrid.replaceChildren(svg);
}

async function send(type) {
  return chrome.runtime.sendMessage({ type });
}

async function toggleAutoMode() {
  if (busy) return;
  busy = true;
  startButton.disabled = true;
  const nextAction = autoModeOn ? 'PATH_AUTO_STOP' : 'PATH_AUTO_START';
  setStatus(autoModeOn ? 'Stopping…' : 'Starting…', true, true);
  try {
    const mode = await send(nextAction);
    if (!mode?.ok) throw new Error(mode?.message || 'Could not change Auto Mode.');
    autoModeOn = Boolean(mode.active);
    startButton.textContent = 'START';
    startButton.classList.toggle('active', autoModeOn);
    startButton.setAttribute('aria-pressed', String(autoModeOn));
    if (autoModeOn) {
      const scan = await send('PATH_CAPTURE');
      renderMaze(scan);
      setStatus(scan?.solved ? 'Auto On · Guide ready' : 'Auto On · Waiting for puzzle', true);
    } else {
      setStatus('Ready', true);
    }
  } catch (error) {
    setStatus(error.message || 'Extension communication failed.', false);
  } finally {
    busy = false;
    startButton.disabled = false;
  }
}

startButton.addEventListener('click', toggleAutoMode);
