const ACTIONS = new Set(['PATH_SOLVE','PATH_CAPTURE','PATH_AUTO_START','PATH_AUTO_STOP']);
async function ensureContent(tabId) {
  try { const ping = await chrome.tabs.sendMessage(tabId, { type: 'PATH_PING' }); if (ping?.version === 'oneclick-1.0.0-auto-assist-r13') return; } catch {}
  await chrome.scripting.executeScript({ target: { tabId }, files: ['solvers/math-maze/math-maze-content.js'] });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!ACTIONS.has(msg?.type)) return;
  chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(async tabs => {
    const tab = tabs[0]; if (!tab?.id) throw new Error('No active game tab found.');
    await ensureContent(tab.id);
    return chrome.tabs.sendMessage(tab.id, msg);
  }).then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message }));
  return true;
});
