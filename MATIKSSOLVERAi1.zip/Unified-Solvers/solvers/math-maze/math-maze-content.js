if (!globalThis.__MATIKS_MATH_MAZE_CONTENT_LOADED__) {
  globalThis.__MATIKS_MATH_MAZE_CONTENT_LOADED__ = true;
(() => {
  'use strict';
  const BUILD_VERSION = 'oneclick-1.0.0-auto-assist-r13';
  if (window.__mathMazeSolverLoaded === BUILD_VERSION) return;
  window.__mathMazeSolverLoaded = BUILD_VERSION;
  const TOKEN_RE = /^[0-9+\-*/×÷]$/;
  const visible = el => {
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  };
  const norm = value => String(value || '').trim().replace('x', '*').replace('X', '*');
  function inTargetGoal(el) {
    let node = el;
    for (let i = 0; node && i < 7; i++, node = node.parentElement) {
      if (/target\s*goal/i.test((node.textContent || '').trim())) return true;
    }
    return false;
  }
  function readTargetGoal() {
    const labels = [...document.querySelectorAll('div,span,p')].filter(el => visible(el) && /^target\s*goal$/i.test((el.textContent || '').trim()));
    const label = labels.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width)[0];
    if (!label) return null;
    const lr = label.getBoundingClientRect(), lx = lr.left + lr.width / 2;
    const candidates = [...document.querySelectorAll('div,span,p')].filter(el => {
      if (!visible(el) || el === label) return false;
      const text = (el.textContent || '').trim();
      if (!/^-?\d+(?:\s*\/\s*\d+)?$/.test(text)) return false;
      const r = el.getBoundingClientRect(), style = getComputedStyle(el), font = parseFloat(style.fontSize) || 0;
      const cx = r.left + r.width / 2;
      return r.top >= lr.bottom - 8 && r.top < lr.bottom + 180 && Math.abs(cx - lx) < Math.max(150, innerWidth * 0.22) && font >= 28;
    }).sort((a, b) => {
      const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
      return (parseFloat(getComputedStyle(b).fontSize) || 0) - (parseFloat(getComputedStyle(a).fontSize) || 0) || (br.width * br.height - ar.width * ar.height);
    });
    return candidates[0]?.textContent.trim() || null;
  }
  function tokenCandidates() {
    return [...document.querySelectorAll('div[dir="auto"], span, p, [role="gridcell"]')]
      .filter(el => visible(el) && !inTargetGoal(el) && TOKEN_RE.test(norm(el.textContent)))
      .filter(el => ![...el.children].some(child => TOKEN_RE.test(norm(child.textContent))))
      .map(el => {
        const r = el.getBoundingClientRect();
        return { el, value: norm(el.textContent), x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height };
      })
      .filter(t => t.y > innerHeight * 0.18 && t.y < innerHeight * 0.9 && t.x > innerWidth * 0.12 && t.x < innerWidth * 0.88 && t.w >= 5 && t.h >= 8);
  }
  function cluster(values, tolerance) {
    const out = [];
    for (const value of [...values].sort((a, b) => a - b)) {
      const last = out[out.length - 1];
      if (last && Math.abs(value - last.mean) <= tolerance) { last.values.push(value); last.mean = last.values.reduce((a, b) => a + b, 0) / last.values.length; }
      else out.push({ mean: value, values: [value] });
    }
    return out.map(c => c.mean);
  }
  function markerPosition(label, raw, xs, ys) {
    const labels = [...document.querySelectorAll('div,span,p')].filter(el => visible(el) && (el.textContent || '').trim().toUpperCase() === label);
    if (!labels.length || !raw.length) return null;
    const lr = labels.sort((a, b) => a.getBoundingClientRect().width - b.getBoundingClientRect().width)[0].getBoundingClientRect();
    const lx = lr.left + lr.width / 2, ly = lr.top + lr.height / 2;
    const nearest = raw.slice().sort((a, b) => Math.hypot(a.x - lx, a.y - ly) - Math.hypot(b.x - lx, b.y - ly))[0];
    if (!nearest) return null;
    return { r: ys.reduce((best, y, i) => Math.abs(y - nearest.y) < Math.abs(ys[best] - nearest.y) ? i : best, 0), c: xs.reduce((best, x, i) => Math.abs(x - nearest.x) < Math.abs(xs[best] - nearest.x) ? i : best, 0) };
  }
  function capture() {
    const raw = tokenCandidates();
    if (raw.length < 3) return { ok: false, error: 'No arithmetic token board found.', tokens: [], grid: [] };
    const sizes = raw.map(t => Math.max(6, Math.min(t.w, t.h))).sort((a, b) => a - b);
    const medianSize = sizes[Math.floor(sizes.length / 2)] || 20;
    // Scale the grouping tolerance with the rendered token size; this keeps
    // small 3×3 boards and dense/larger boards separate without hardcoding size.
    const tolerance = Math.max(8, Math.min(30, medianSize * 0.7));
    const xs = cluster(raw.map(t => t.x), tolerance), ys = cluster(raw.map(t => t.y), tolerance);
    const grid = ys.map(y => xs.map(x => {
        const radius = Math.max(18, medianSize * 0.95);
        const matches = raw.filter(t => Math.hypot(t.x - x, t.y - y) < radius).sort((a, b) => Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y));
      return matches[0]?.value || '.';
    }));
    const tokens = raw.map(t => ({ value: t.value, x: Math.round(t.x), y: Math.round(t.y), row: ys.indexOf(ys.reduce((a, b) => Math.abs(b - t.y) < Math.abs(a - t.y) ? b : a)), col: xs.indexOf(xs.reduce((a, b) => Math.abs(b - t.x) < Math.abs(a - t.x) ? b : a)) }));
    const start = markerPosition('START', raw, xs, ys) || { r: 0, c: 0 }; const end = markerPosition('END', raw, xs, ys) || { r: ys.length - 1, c: xs.length - 1 }; return { ok: true, target: readTargetGoal(), tokens, grid, rows: ys.length, cols: xs.length, start, end, message: `${tokens.length} characters captured in ${ys.length} × ${xs.length} structure.` };
  }
  const isNumber = v => /^\d+$/.test(v);
  const operator = v => ({ '×': '*', 'x': '*', 'X': '*', '*': '*', '÷': '/', '/': '/', '+': '+', '-': '-' }[v] || null);
  function applyValue(total, op, value) {
    if (op === '+') return total + value;
    if (op === '-') return total - value;
    if (op === '*') return total * value;
    if (op === '/') return value === 0 ? null : total / value;
    return null;
  }
  function solvePath(captured) {
    const { grid, rows, cols, target } = captured;
    const goal = Number(String(target ?? '').match(/-?\d+/)?.[0]);
    if (!Number.isFinite(goal) || !grid?.length || rows < 1 || cols < 1 || !isNumber(grid[0][0]) || !isNumber(grid[rows - 1][cols - 1])) return null;
    const start = captured.start || { r: 0, c: 0 }, end = captured.end || { r: rows - 1, c: cols - 1 }, visited = new Set(), validPaths = [];
    const allDirections = [[1,0],[0,1],[-1,0],[0,-1]];
    const monotonic = start.r <= end.r && start.c <= end.c ? [[1,0],[0,1]] : allDirections;
    let directions = monotonic, usedFallback = false;
    const path = [{ r: start.r, c: start.c, value: grid[start.r][start.c] }];
    let explored = 0;
    const evaluate = (value, op, num) => op === '+' ? value + num : op === '-' ? value - num : op === '*' ? value * num : op === '/' ? (num !== 0 && value % num === 0 ? value / num : null) : num;
    function dfs(r, c, currentVal, pendingOp) {
      if (++explored > 500000 || validPaths.length) return;
      if (r === end.r && c === end.c) {
        if (pendingOp === null && currentVal === goal) validPaths.push(path.map(p => ({ ...p })));
        return;
      }
      visited.add(`${r}:${c}`);
      for (const [dr, dc] of directions) {
        const nr = r + dr, nc = c + dc, key = `${nr}:${nc}`;
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols || visited.has(key)) continue;
        const next = grid[nr]?.[nc];
        if (!next || next === '.') continue;
        if (operator(next) && pendingOp === null) {
          visited.add(key); path.push({ r: nr, c: nc, value: next });
          dfs(nr, nc, currentVal, operator(next));
          path.pop(); visited.delete(key);
        } else if (isNumber(next) && pendingOp !== null) {
          const num = Number(next);
          const nextVal = evaluate(currentVal, pendingOp, num);
          if (nextVal === null || !Number.isFinite(nextVal) || Math.abs(nextVal) > 1e9) continue;
          visited.add(key); path.push({ r: nr, c: nc, value: next });
          dfs(nr, nc, nextVal, null);
          path.pop(); visited.delete(key);
        }
      }
      visited.delete(`${r}:${c}`);
    }
    dfs(start.r, start.c, Number(grid[start.r][start.c]), null);
    if (!validPaths.length && !usedFallback && allDirections.length !== directions.length) {
      usedFallback = true; directions = allDirections; visited.clear(); path.splice(1); explored = 0;
      dfs(start.r, start.c, Number(grid[start.r][start.c]), null);
    }
    const found = validPaths[0];
    return found ? { path: found, expression: found.map(p => p.value).join(' '), result: goal, explored } : null;
  }
  function clearGuide() { document.getElementById('math-maze-solver-guide')?.remove(); }
  function drawGuide(result) {
    clearGuide();
    if (!result.solution) return;
    const byCell = new Map(result.tokens.map(t => [`${t.row}:${t.col}`, t]));
    const points = result.solution.path.map(p => byCell.get(`${p.r}:${p.c}`)).filter(Boolean);
    if (points.length < 2) return;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.id = 'math-maze-solver-guide'; svg.setAttribute('viewBox', `0 0 ${innerWidth} ${innerHeight}`);
    Object.assign(svg.style, { position:'fixed', inset:'0', width:'100vw', height:'100vh', zIndex:'2147483646', pointerEvents:'none', overflow:'visible' });
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    poly.setAttribute('points', points.map(p => `${p.x},${p.y}`).join(' '));
    poly.setAttribute('fill','none'); poly.setAttribute('stroke','#ffffff'); poly.setAttribute('stroke-width','3'); poly.setAttribute('stroke-linecap','round'); poly.setAttribute('stroke-linejoin','round'); poly.setAttribute('opacity','.28');
    svg.appendChild(poly);
    const manual = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    manual.setAttribute('x1', points[0].x); manual.setAttribute('y1', points[0].y); manual.setAttribute('x2', points[1].x); manual.setAttribute('y2', points[1].y);
    manual.setAttribute('stroke', '#8f2d2d'); manual.setAttribute('stroke-width', '3.6'); manual.setAttribute('stroke-linecap', 'round'); manual.setAttribute('opacity', '.95');
    svg.appendChild(manual);
    points.forEach((p, i) => {       const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle'); dot.setAttribute('cx',p.x); dot.setAttribute('cy',p.y); dot.setAttribute('r', i === 0 || i === points.length - 1 ? '5' : '2.5'); dot.setAttribute('fill', i === 0 ? '#fff0a8' : i === points.length - 1 ? '#b9ffd0' : '#9dffbd'); dot.setAttribute('opacity','.25'); svg.appendChild(dot); });
    document.documentElement.appendChild(svg);
  }
  function captureAndSolve() {
    const result = capture();
    if (!result.ok) { clearGuide(); return result; }
    const solution = solvePath(result);
    const output = { ...result, solution, solved: Boolean(solution), message: solution ? `Valid path found: ${solution.expression} = ${solution.result}.` : `No path reached target ${result.target ?? '?'}.` };
    drawGuide(output);
    return output;
  }
  async function clearMazeSelection() {
    const clear = [...document.querySelectorAll('button,[role="button"]')].find(el => visible(el) && /^clear$/i.test((el.textContent || '').trim()));
    if (clear) { tapToken(clear); await new Promise(r => setTimeout(r, 25)); return true; }
    return false;
  }
  async function autoComplete(output) {
    if (!output?.solution?.path?.length) return { ...output, ok: false, completed: false, error: 'No valid path was found.' };
    const byCell = new Map(output.tokens.map(t => [`${t.row}:${t.col}`, t]));
    const elements = output.solution.path.map(p => { const t = byCell.get(`${p.r}:${p.c}`); return t ? clickableTile(tokenAtPoint(t.x, t.y, t.value)) : null; });
    if (elements.some(el => !el)) return { ...output, ok: false, completed: false, error: 'Could not bind every solution tile to the live board.' };
    const beforeKey = boardKey();
    try { swipePath(elements); } catch (_) {}
    await new Promise(r => setTimeout(r, 80));
    if (completionConfirmed(beforeKey)) return { ...output, ok: true, completed: true, message: `Solved and completed: ${output.solution.expression} = ${output.solution.result}.` };
    await clearMazeSelection();
    for (const element of elements) { tapToken(element); await new Promise(r => setTimeout(r, 5)); if (completionConfirmed(beforeKey)) break; }
    const completed = completionConfirmed(beforeKey);
    return { ...output, ok: completed, completed, message: completed ? `Solved and completed: ${output.solution.expression} = ${output.solution.result}.` : `Path calculated but the game did not confirm completion.` };
  }
  function tokenAtPoint(x, y, value) {
    const direct = document.elementFromPoint(x, y);
    const candidates = [direct, ...(direct ? [...direct.querySelectorAll('span,div')] : []), ...tokenCandidates().map(t => t.el)];
    return candidates.filter(el => el && visible(el) && norm(el.textContent) === value).sort((a, b) => {
      const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
      return Math.hypot(ar.left + ar.width / 2 - x, ar.top + ar.height / 2 - y) - Math.hypot(br.left + br.width / 2 - x, br.top + br.height / 2 - y);
    })[0] || null;
  }
  function clickableTile(el) {
    let node = el;
    for (let i = 0; node && i < 6; i++, node = node.parentElement) {
      const cls = String(node.className || '');
      if (node.getAttribute?.('role') === 'button' || node.tabIndex === 0 || /r-1loqt21|r-1otgn73/.test(cls)) return node;
    }
    return el;
  }
  function tapToken(el) {
    const target = clickableTile(el), r = target.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    target.focus?.();
    for (const type of ['pointerdown', 'mousedown', 'touchstart']) target.dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
    target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));
    for (const type of ['pointerup', 'mouseup', 'touchend']) target.dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
  }
  function swipePath(elements) {
    if (!elements.length) return;
    const first = elements[0].getBoundingClientRect(), fx = first.left + first.width / 2, fy = first.top + first.height / 2;
    elements[0].dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: fx, clientY: fy, pointerId: 1, isPrimary: true }));
    for (const el of elements.slice(1)) { const r = el.getBoundingClientRect(); el.dispatchEvent(new PointerEvent('pointermove', { bubbles: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, pointerId: 1, isPrimary: true })); }
    const last = elements.at(-1).getBoundingClientRect();
    elements.at(-1).dispatchEvent(new PointerEvent('pointerup', { bubbles: true, clientX: last.left + last.width / 2, clientY: last.top + last.height / 2, pointerId: 1, isPrimary: true }));
  }
  let autoScanEnabled = false, autoObserver = null, autoInterval = null, autoKey = '', autoTimer = null, autoBusy = false;
  let autoAssistOutput = null, autoAssistTriggered = false, autoCheckTimer = null, autoInputBound = false, autoLastInput = null, autoGestureStart = null, autoGestureSawMove = false, autoSecondVisualBaseline = '', autoSelectedBaseline = 0, autoFirstTransitionReady = false, autoSecondTargetHit = false;
  const hasVisibleLabel = label => [...document.querySelectorAll('div,span,p,[role="button"]')].some(el => visible(el) && new RegExp(`^${label}$`, 'i').test((el.textContent || '').trim()));
  const creamLike = value => { const m = String(value || '').match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/i); return Boolean(m && Number(m[1]) > 210 && Number(m[2]) > 195 && Number(m[3]) > 120 && Number(m[1]) - Number(m[2]) < 70); };
  const tileVisualSignature = () => tokenCandidates().map(t => { const tile = clickableTile(t.el); return [t.el, tile, tile?.parentElement].filter(Boolean).map(el => { const s = getComputedStyle(el); return `${el.className || ''}|${el.getAttribute('style') || ''}|${s.backgroundColor}|${s.borderColor}|${s.boxShadow}`; }).join('>'); }).join('||');
  const selectedTokenCount = () => tokenCandidates().filter(t => { const tile = clickableTile(t.el); return [t.el, tile, tile?.parentElement].filter(Boolean).some(el => { const s = getComputedStyle(el); return /selected|active|path/i.test(String(el.className || '')) || creamLike(s.backgroundColor) || creamLike(s.borderColor) || creamLike(s.boxShadow); }); }).length;
  const visualSignature = el => {
    const tile = clickableTile(el);
    return [el, tile, tile?.parentElement].filter(Boolean).map(node => {
      const s = getComputedStyle(node);
      return `${String(node.className || '')}|${node.getAttribute('style') || ''}|${s.backgroundColor}|${s.borderColor}|${s.boxShadow}|${s.opacity}`;
    }).join('>');
  };
  const routeVisualSignature = (output, index) => {
    const point = output?.solution?.path?.[index];
    const token = output?.tokens?.find(t => t.row === point?.r && t.col === point?.c);
    return token?.el ? visualSignature(token.el) : '';
  };
  const scheduleAutoProgressCheck = event => {
    if (event) {
      const touch = event.changedTouches?.[0] || event.touches?.[0];
      const x = Number(event.clientX ?? touch?.clientX), y = Number(event.clientY ?? touch?.clientY);
      const active = event.type === 'pointerup' || event.type === 'mouseup' || event.type === 'touchend' || Number(event.buttons) > 0 || Boolean(touch);
      if (Number.isFinite(x) && Number.isFinite(y) && (active || event.type === 'pointerdown' || event.type === 'touchstart')) {
        if (event.type === 'pointerdown' || event.type === 'touchstart') { autoGestureStart = { x, y, time: Date.now() }; autoGestureSawMove = false; autoSecondTargetHit = false; }
        if (event.type === 'pointermove' || event.type === 'mousemove' || event.type === 'touchmove') autoGestureSawMove = true;
        if (autoAssistOutput?.solution?.path?.length) {
          const secondPoint = autoAssistOutput.solution.path[1];
          const secondToken = autoAssistOutput.tokens?.find(t => t.row === secondPoint?.r && t.col === secondPoint?.c);
          const secondTile = secondToken?.el && clickableTile(secondToken.el);
          const eventTarget = event.target;
          if (secondToken && eventTarget && (eventTarget === secondToken.el || secondToken.el.contains?.(eventTarget) || secondTile?.contains?.(eventTarget))) autoSecondTargetHit = true;
        }
        autoLastInput = { x, y, time: Date.now(), active, type: event.type, target: event.target || null };
      }
    }
    if (!autoScanEnabled || autoCheckTimer) return;
    autoCheckTimer = setTimeout(() => { autoCheckTimer = null; checkAutoProgress(); }, 0);
  };
  const hasPuzzleBoard = () => hasVisibleLabel('START') && hasVisibleLabel('END') && Boolean(readTargetGoal()) && tokenCandidates().length >= 3;
  const GUIDE_SETTLE_DELAY = 500;
  const boardKey = () => tokenCandidates().map(t => t.value).join('|') + `#${readTargetGoal() || ''}`;
  const completionText = () => /XP\s*BOOSTED|YOU\s*EARNED|NEXT\s*PUZZLE|AWESOME|YOUR\s*BEST|XP\s*GAINED|VIEW\s*SOLUTION|PLAY\s*MORE/i.test(document.body?.innerText || '');
  const gameFinished = () => completionText();
  const completionConfirmed = beforeKey => completionText() || Boolean(beforeKey && boardKey() && boardKey() !== beforeKey && !hasPuzzleBoard());
  const clearAutoState = () => { clearGuide(); autoKey = ''; autoBusy = false; autoAssistOutput = null; autoAssistTriggered = false; autoLastInput = null; autoGestureStart = null; autoGestureSawMove = false; autoSecondVisualBaseline = ''; autoSelectedBaseline = 0; autoFirstTransitionReady = false; autoSecondTargetHit = false; if (autoCheckTimer) clearTimeout(autoCheckTimer); autoCheckTimer = null; if (autoTimer) clearTimeout(autoTimer); autoTimer = null; };
  const scanIfNewBoard = () => {
    if (!autoScanEnabled || autoBusy) return;
    if (gameFinished()) { clearAutoState(); return; }
    const key = boardKey();
    if (!key || key === autoKey) return;
    clearGuide(); autoKey = key; autoBusy = true; autoAssistOutput = null; autoAssistTriggered = false;
    if (autoTimer) clearTimeout(autoTimer);
    autoTimer = setTimeout(() => {
      autoTimer = null;
      if (autoScanEnabled && !gameFinished() && boardKey() === key) {
        const output = captureAndSolve();
        autoAssistOutput = output?.solved ? output : null;
        autoSecondVisualBaseline = autoAssistOutput ? routeVisualSignature(autoAssistOutput, 1) : '';
        autoSelectedBaseline = selectedTokenCount();
        autoFirstTransitionReady = false;
      }
      autoBusy = false;
      scheduleAutoProgressCheck();
    }, GUIDE_SETTLE_DELAY);
  };
  const transitionReadyFromCurrentState = () => {
    if (!autoAssistOutput?.solution?.path?.length || !autoGestureStart || !autoLastInput || !autoGestureSawMove) return false;
    const path = autoAssistOutput.solution.path;
    const routeTokens = autoAssistOutput.tokens || [];
    const routeNode = index => routeTokens.find(t => t.row === path[index]?.r && t.col === path[index]?.c);
    const first = routeNode(0), second = routeNode(1);
    if (!first || !second) return false;
    const firstSize = Math.max(first.w || 0, first.h || 0);
    const startTolerance = Math.max(24, Math.min(54, firstSize * 0.95));
    const secondTolerance = Math.max(26, Math.min(52, Math.max(second.w || 0, second.h || 0) * 0.9));
    const age = Date.now() - autoGestureStart.time;
    const startedAtFirst = Math.hypot(autoGestureStart.x - first.x, autoGestureStart.y - first.y) <= startTolerance;
    const recent = Date.now() - autoLastInput.time < 5000;
    const endedNearSecond = ['pointerup', 'mouseup', 'touchend'].includes(autoLastInput.type) && Math.hypot(autoLastInput.x - second.x, autoLastInput.y - second.y) <= secondTolerance;
    const secondStateChanged = Boolean(autoSecondVisualBaseline && routeVisualSignature(autoAssistOutput, 1) !== autoSecondVisualBaseline);
    const selectedPathAdvanced = selectedTokenCount() > autoSelectedBaseline;
    return startedAtFirst && recent && age >= 25 && age < 5000 && (autoSecondTargetHit || endedNearSecond || secondStateChanged || selectedPathAdvanced);
  };
  const triggerAutoContinuation = () => {
    if (!autoScanEnabled || autoBusy || autoAssistTriggered || !autoAssistOutput?.solution?.path?.length) return false;
    autoAssistTriggered = true; autoFirstTransitionReady = true; autoBusy = true;
    captureAndSolveAsync().finally(() => { autoBusy = false; scheduleAutoProgressCheck(); });
    return true;
  };
  const checkAutoProgress = () => {
    if (!autoScanEnabled || autoBusy || autoAssistTriggered || !autoAssistOutput?.solution?.path?.length) return;
    if (transitionReadyFromCurrentState()) autoFirstTransitionReady = true;
    if (!autoFirstTransitionReady) return;
    triggerAutoContinuation();
  };
  function startAutoScan() {
    if (autoScanEnabled) return { ok: true, active: true, message: 'Auto mode is already enabled. Drag START to the next node.' };
    autoScanEnabled = true; clearAutoState();
    autoObserver = new MutationObserver(mutations => {
      if (gameFinished()) { clearAutoState(); return; }
      const meaningful = mutations.some(m => {
        if (m.type === 'characterData') return true;
        if (m.type !== 'childList') return false;
        return [...m.addedNodes, ...m.removedNodes].some(n => n?.id !== 'math-maze-solver-guide' && !n?.closest?.('#math-maze-solver-guide'));
      });
      if (meaningful) scanIfNewBoard();
      scheduleAutoProgressCheck();
    });
    autoObserver.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['class', 'style'] });
    autoInterval = setInterval(() => { scanIfNewBoard(); scheduleAutoProgressCheck(); }, 500);
    if (!autoInputBound) {
      ['pointerdown', 'pointermove', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchmove', 'touchend'].forEach(type => document.addEventListener(type, scheduleAutoProgressCheck, true));
      autoInputBound = true;
    }
    scanIfNewBoard(); scheduleAutoProgressCheck();
    return { ok: true, active: true, message: 'Auto mode ready. Drag START to the second node; the rest will fill automatically.' };
  }
  function stopAutoScan() {
    autoScanEnabled = false; autoObserver?.disconnect(); autoObserver = null; if (autoInterval) clearInterval(autoInterval); autoInterval = null; if (autoTimer) clearTimeout(autoTimer); autoTimer = null;
    if (autoInputBound) { ['pointerdown', 'pointermove', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchmove', 'touchend'].forEach(type => document.removeEventListener(type, scheduleAutoProgressCheck, true)); autoInputBound = false; }
    clearAutoState(); return { ok: true, active: false, message: 'Auto mode disabled.' };
  }
  function resultModel(output, overrides = {}) {
    return {
      ok: Boolean(overrides.ok ?? output?.ok), solved: Boolean(overrides.solved ?? output?.solved), completed: Boolean(overrides.completed ?? output?.completed),
      target: output?.target ?? null, rows: output?.rows ?? 0, cols: output?.cols ?? 0, grid: output?.grid || [], start: output?.start || null, end: output?.end || null,
      solution: output?.solution || null, message: overrides.message ?? output?.message ?? '', error: overrides.error ?? output?.error ?? null
    };
  }
  async function captureAndSolveAsync() {
    const output = captureAndSolve();
    if (!output.solved) return resultModel(output, { ok: false, solved: false, completed: false, error: output.error || output.message || 'No valid path was found.' });
    const completed = await autoComplete(output);
    return resultModel(completed, { ok: completed.ok, solved: true, completed: Boolean(completed.completed), message: completed.message, error: completed.error || null });
  }
  window.__mathMazeSolverDebug = { capture, solvePath, captureAndSolve, captureAndSolveAsync, autoComplete, startAutoScan, stopAutoScan, selectedTokenCount, resultModel };
  window.__mathMazeSolverCleanup = () => { clearGuide(); stopAutoScan(); };
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'PATH_SOLVE') { captureAndSolveAsync().then(sendResponse).catch(e => sendResponse(resultModel({}, { ok: false, solved: false, completed: false, error: e.message }))); return true; } if (msg?.type === 'PATH_CAPTURE') { sendResponse(captureAndSolve()); return false; }
    if (msg?.type === 'PATH_AUTO_START') { sendResponse(startAutoScan()); return false; }
    if (msg?.type === 'PATH_AUTO_STOP') { sendResponse(stopAutoScan()); return false; }
    if (msg?.type === 'PATH_PING') { sendResponse({ ok: true, version: BUILD_VERSION }); return false; }
  });
})();

}
