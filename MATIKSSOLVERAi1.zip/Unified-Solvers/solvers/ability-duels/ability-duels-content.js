if (!globalThis.__MATIKS_ABILITY_DUELS_CONTENT_LOADED__) {
  globalThis.__MATIKS_ABILITY_DUELS_CONTENT_LOADED__ = true;
/**
 * Logic Duel Solver V1 — DOM Extractor & Auto Filler
 */

const MODE_PATTERN = /^[A-Z][A-Z &'’+()/-]{2,64}$/i;
const TOKEN_PATTERN = /^-?\d+$|^[%+\-−x×÷*\/^=()]+$/;
const WORD_OPERATOR_PATTERN = /^(LCM|HCF|GCD|MOD|REMAINDER|SUM|OF|SQUARES|SQUARE|PRIME|FACTORS|FACTOR|ROOTS|ROOT|LOG|POWER|CUBE|CUBES)$/i;
const RADICAL_INDEX_PATTERN = /^\d+$/;
const MIN_TOKEN_FONT_SIZE = 28;

let autoWatchObserver = null;
let autoWatchQueued = false;
let lastSignature = '';
let blankFrameSeen = true;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return undefined;

  if (message.type === 'EXTRACT_LOGIC_TEXT') {
    try {
      sendResponse({ ok: true, capture: extractLogicText() });
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || 'Text extraction failed.' });
    }
    return true;
  }

  if (message.type === 'START_LOGIC_WATCH') {
    startAutoWatch();
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'STOP_LOGIC_WATCH') {
    stopAutoWatch();
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'FILL_LOGIC_ANSWER') {
    try {
      fillGameAnswer(message.answer, message.submit);
      sendResponse({ ok: true });
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || 'Could not fill answer.' });
    }
    return true;
  }

  return undefined;
});

function publishChangedCapture() {
  if (autoWatchQueued) return;
  autoWatchQueued = true;

  // A microtask runs after the game finishes its current DOM update, without polling.
  queueMicrotask(() => {
    autoWatchQueued = false;
    try {
      const capture = extractLogicText();
      const hasContent = Boolean(capture.mode && capture.value);
      if (!hasContent) {
        blankFrameSeen = true;
        lastSignature = '';
        return;
      }

      const signature = `${capture.mode}|${capture.value}`;
      if (!blankFrameSeen && signature === lastSignature) return;

      lastSignature = signature;
      blankFrameSeen = false;
      chrome.runtime.sendMessage({ type: 'LOGIC_TEXT_UPDATED', capture }).catch(() => {});
    } catch {}
  });
}

function startAutoWatch() {
  stopAutoWatch();
  lastSignature = '';
  blankFrameSeen = true;
  publishChangedCapture();

  if (document.body && typeof MutationObserver === 'function') {
    autoWatchObserver = new MutationObserver(() => publishChangedCapture());
    autoWatchObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
}

function stopAutoWatch() {
  autoWatchObserver?.disconnect();
  autoWatchObserver = null;
  autoWatchQueued = false;
  lastSignature = '';
  blankFrameSeen = true;
}

function extractLogicText() {
  const modeCandidates = [];
  const directExpressions = [];
  const visualTokens = [];
  const seenElements = new Set();

  // 1. Check for KaTeX rendered powers
  const powerExpr = extractKaTeXPower();
  if (powerExpr) {
    directExpressions.push({
      value: powerExpr,
      parts: [powerExpr],
      fontSize: 80,
      centerDistance: 0,
      rect: { left: 0, right: 100, top: 0, bottom: 100 },
      score: 9999,
    });
  }

  // 1.5. Check for KaTeX / SVG Roots (Only if root symbol / sqrt class actually exists)
  const rootExpr = extractKaTeXRoot();
  if (rootExpr) {
    directExpressions.push({
      value: rootExpr,
      parts: [rootExpr],
      fontSize: 80,
      centerDistance: 0,
      rect: { left: 0, right: 100, top: 0, bottom: 100 },
      score: 9999,
    });
  }

  for (const element of document.querySelectorAll('div, span, p, h1, h2, h3')) {
    if (seenElements.has(element)) continue;
    seenElements.add(element);

    const text = getRenderableText(element);
    if (!text || !isVisible(element) || isIgnoredMirror(element)) continue;

    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const fontSize = Number.parseFloat(style.fontSize) || 0;

    if (MODE_PATTERN.test(text) && looksLikePuzzleMode(text)) {
      modeCandidates.push({
        text: text.toUpperCase(),
        fontSize,
        centerDistance: distanceFromViewportCenter(rect),
        element,
      });
    }

    if (fontSize < MIN_TOKEN_FONT_SIZE) continue;

    if (isDirectExpression(text)) {
      directExpressions.push({
        value: normalizeExpression(text),
        parts: splitExpressionParts(text),
        fontSize,
        centerDistance: distanceFromViewportCenter(rect),
        rect,
        score: scoreExpression({ fontSize, rect, isDirect: true, partCount: splitExpressionParts(text).length }),
      });
      continue;
    }

    if (TOKEN_PATTERN.test(text) || WORD_OPERATOR_PATTERN.test(text)) {
      visualTokens.push({
        text: normalizeToken(text),
        fontSize,
        rect,
        centerY: rect.top + rect.height / 2,
        centerDistance: distanceFromViewportCenter(rect),
        kind: /^-?\d+$/.test(text) ? 'number' : 'operator',
      });
    }
  }

  // Detect SVG radicals
  for (const svg of document.querySelectorAll('svg')) {
    if (!isVisible(svg)) continue;
    const rect = svg.getBoundingClientRect();
    const fontSize = inferSvgFontSize(svg, rect);
    if (fontSize < MIN_TOKEN_FONT_SIZE) continue;

    const rootInfo = readRootSvg(svg);
    if (!rootInfo.isRoot) continue;

    visualTokens.push({
      text: `√[${rootInfo.index || 2}]`,
      rootIndex: Number(rootInfo.index || 2),
      fontSize,
      rect,
      centerY: rect.top + rect.height / 2,
      centerDistance: distanceFromViewportCenter(rect),
      kind: 'root',
    });
  }

  const dedupedTokens = dedupeVisualTokens(visualTokens);
  const rootTokens = dedupedTokens.filter((token) => token.kind === 'root');
  const nonRootTokens = dedupedTokens.filter((token) => token.kind !== 'root');

  const rootExpressions = rootTokens.map((rootToken) => buildRootExpression(rootToken, nonRootTokens)).filter(Boolean);
  const groupedExpressions = groupTokensByVisualLine(nonRootTokens);

  const expressions = dedupeExpressions([...directExpressions, ...rootExpressions, ...groupedExpressions]).sort((left, right) => right.score - left.score);
  const bestMode = chooseMode(modeCandidates);
  const bestExpression = expressions[0] || null;
  const value = bestExpression?.value || null;

  return {
    mode: bestMode?.text || null,
    value,
    rawText: [bestMode?.text, value].filter(Boolean).join('\n'),
    parts: bestExpression?.parts || [],
    numbers: value ? extractNumbers(value) : [],
    operators: value ? extractOperators(value) : [],
    root: value ? extractRoot(value) : null,
  };
}

function extractKaTeXPower() {
  const msupsub = document.querySelector('.msupsub');
  if (!msupsub) return null;

  const mtightNode = msupsub.querySelector('.mtight');
  const expVal = mtightNode ? (mtightNode.textContent || '').replace(/\D/g, '') : '';
  if (!expVal) return null;

  const parentKatex = msupsub.closest('.katex') || msupsub.parentElement;
  if (!parentKatex) return null;

  const baseContainer = parentKatex.querySelector('.base') || parentKatex;
  const clone = baseContainer.cloneNode(true);
  
  const supInClone = clone.querySelector('.msupsub, .mtight, .sup, sup');
  if (supInClone) supInClone.remove();

  const allText = clone.textContent || '';
  const digits = allText.match(/\d+/g);
  let baseText = digits ? digits.join('') : '';

  if (baseText.length > 0 && expVal) {
    return `${baseText}^${expVal}`;
  }

  return null;
}

function extractKaTeXRoot() {
  // Check if actual root/sqrt element exists on screen before proceeding
  const hasSqrtElement = document.querySelector('.sqrt, .mord.sqrt') || 
    Array.from(document.querySelectorAll('svg')).some(svg => {
      const markup = String(svg.outerHTML || '').toLowerCase();
      return /path|polyline|line/.test(markup) && (svg.getAttribute('viewBox') || '').includes('1000');
    });

  if (!hasSqrtElement) return null;

  const container = document.querySelector('.katex-html, .katex') || document.body;
  const text = container.innerText || container.textContent || '';
  
  const allDigits = text.match(/\d+/g);
  if (!allDigits || allDigits.length === 0) return null;

  let index = '2';
  let target = '';

  for (const d of allDigits) {
    if (d.length <= 2 && Number(d) <= 10 && index === '2') {
      index = d;
    } else if (d.length >= 3) {
      target = d;
      break;
    }
  }

  if (!target && allDigits.length >= 2) {
    index = allDigits[0];
    target = allDigits.slice(1).join('');
  } else if (!target && allDigits.length === 1) {
    target = allDigits[0];
  }

  if (target) {
    return `√[${index}] ${target}`;
  }

  return null;
}

function dedupeVisualTokens(tokens) {
  const ordered = [...tokens].sort((left, right) => right.fontSize - left.fontSize || left.rect.left - right.rect.left);
  const unique = [];

  for (const token of ordered) {
    const duplicate = unique.some((existing) => (
      existing.text === token.text &&
      sameVisualRegion(existing.rect, token.rect, existing.fontSize, token.fontSize)
    ));
    if (!duplicate) unique.push(token);
  }

  return unique;
}

function dedupeExpressions(expressions) {
  const ordered = [...expressions].sort((left, right) => right.score - left.score);
  const unique = [];

  for (const expression of ordered) {
    const duplicate = unique.some((existing) => (
      existing.value === expression.value &&
      sameVisualRegion(existing.rect, expression.rect, existing.fontSize, expression.fontSize)
    ));
    if (!duplicate) unique.push(expression);
  }

  return unique;
}

function sameVisualRegion(left, right, leftFontSize = 40, rightFontSize = 40) {
  if (!left || !right) return false;

  const leftCenterX = (left.left + left.right) / 2;
  const rightCenterX = (right.left + right.right) / 2;
  const leftCenterY = (left.top + left.bottom) / 2;
  const rightCenterY = (right.top + right.bottom) / 2;
  const centerTolerance = Math.max(12, Math.min(leftFontSize, rightFontSize) * 0.55);
  const overlap = rectangleOverlap(left, right);

  return (
    (Math.abs(leftCenterX - rightCenterX) <= centerTolerance && Math.abs(leftCenterY - rightCenterY) <= centerTolerance) ||
    overlap >= 0.55
  );
}

function rectangleOverlap(left, right) {
  const width = Math.max(0, Math.min(left.right, right.right) - Math.max(left.left, right.left));
  const height = Math.max(0, Math.min(left.bottom, right.bottom) - Math.max(left.top, right.top));
  const overlapArea = width * height;
  const leftArea = Math.max(1, (left.right - left.left) * (left.bottom - left.top));
  const rightArea = Math.max(1, (right.right - right.left) * (right.bottom - right.top));
  return overlapArea / Math.min(leftArea, rightArea);
}

function groupTokensByVisualLine(tokens) {
  const groups = [];
  const sorted = [...tokens].sort((left, right) => left.centerY - right.centerY || left.rect.left - right.rect.left);

  for (const token of sorted) {
    const tolerance = Math.max(18, Math.min(token.fontSize * 0.36, 44));
    let group = groups.find((candidate) => Math.abs(candidate.centerY - token.centerY) <= tolerance);

    if (!group) {
      group = { centerY: token.centerY, tokens: [] };
      groups.push(group);
    }

    group.tokens.push(token);
    group.centerY = group.tokens.reduce((sum, item) => sum + item.centerY, 0) / group.tokens.length;
  }

  return groups
    .map((group) => buildExpressionFromGroup(group.tokens))
    .filter(Boolean);
}

function buildExpressionFromGroup(tokens) {
  const ordered = collapseConsecutiveMirrors([...tokens].sort((left, right) => left.rect.left - right.rect.left));
  const numbers = ordered.filter((token) => token.kind === 'number');
  const meaningful = ordered.filter((token) => token.kind !== 'operator' || token.text !== 'OF');
  if (numbers.length === 0 || meaningful.length === 0) return null;

  const left = ordered[0].rect.left;
  const right = ordered[ordered.length - 1].rect.right;
  const span = right - left;
  if (span > Math.max(720, window.innerWidth * 0.9)) return null;

  const value = normalizeExpression(ordered.map((token) => token.text).join(' '));
  const averageFontSize = ordered.reduce((sum, token) => sum + token.fontSize, 0) / ordered.length;
  const averageCenterDistance = ordered.reduce((sum, token) => sum + token.centerDistance, 0) / ordered.length;
  const rect = {
    left,
    right,
    top: Math.min(...ordered.map((token) => token.rect.top)),
    bottom: Math.max(...ordered.map((token) => token.rect.bottom)),
  };

  return {
    value,
    parts: ordered.map((token) => token.text),
    fontSize: averageFontSize,
    centerDistance: averageCenterDistance,
    rect,
    score: scoreExpression({
      fontSize: averageFontSize,
      rect,
      isDirect: false,
      partCount: ordered.length,
      hasRoot: ordered.some((token) => token.kind === 'root'),
    }),
  };
}

function buildRootExpression(rootToken, tokens) {
  const rootCenterX = (rootToken.rect.left + rootToken.rect.right) / 2;
  const rootCenterY = (rootToken.rect.top + rootToken.rect.bottom) / 2;
  const lineTolerance = Math.max(50, rootToken.fontSize * 1.2);

  const numericCandidates = tokens
    .filter((token) => token.kind === 'number')
    .filter((token) => Math.abs(token.centerY - rootCenterY) <= lineTolerance)
    .filter((token) => ((token.rect.left + token.rect.right) / 2) > rootCenterX - 20)
    .sort((left, right) => left.rect.left - right.rect.left);

  const radicand = numericCandidates[0];
  if (!radicand) {
    return {
      value: `√[${rootToken.rootIndex || 2}]`,
      parts: [`√[${rootToken.rootIndex || 2}]`],
      fontSize: rootToken.fontSize,
      centerDistance: rootToken.centerDistance,
      rect: rootToken.rect,
      score: scoreExpression({ fontSize: rootToken.fontSize, rect: rootToken.rect, isDirect: true, partCount: 1, hasRoot: true }),
    };
  }

  const rect = {
    left: Math.min(rootToken.rect.left, radicand.rect.left),
    right: Math.max(rootToken.rect.right, radicand.rect.right),
    top: Math.min(rootToken.rect.top, radicand.rect.top),
    bottom: Math.max(rootToken.rect.bottom, radicand.rect.bottom),
  };
  const value = `√[${rootToken.rootIndex || 2}] ${radicand.text}`;

  return {
    value,
    parts: [`√[${rootToken.rootIndex || 2}]`, radicand.text],
    fontSize: Math.max(rootToken.fontSize, radicand.fontSize),
    centerDistance: distanceFromViewportCenter(rect),
    rect,
    score: scoreExpression({ fontSize: Math.max(rootToken.fontSize, radicand.fontSize), rect, isDirect: true, partCount: 2, hasRoot: true }),
  };
}

function collapseConsecutiveMirrors(tokens) {
  const compacted = [];
  for (const token of tokens) {
    const previous = compacted[compacted.length - 1];
    if (
      previous &&
      previous.text === token.text &&
      (sameVisualRegion(previous.rect, token.rect, previous.fontSize, token.fontSize) || horizontalGap(previous.rect, token.rect) <= Math.max(18, Math.min(previous.fontSize, token.fontSize) * 0.8))
    ) {
      continue;
    }
    compacted.push(token);
  }
  return compacted;
}

function horizontalGap(left, right) {
  if (right.left >= left.right) return right.left - left.right;
  if (left.left >= right.right) return left.left - right.right;
  return 0;
}

function readRootSvg(svg) {
  const markup = String(svg.outerHTML || '').toLowerCase();
  const viewBox = (svg.getAttribute('viewBox') || '').trim().split(/\s+/).map(Number);
  const viewBoxWidth = viewBox[2] || 0;
  const viewBoxHeight = viewBox[3] || 0;
  const widthAttribute = String(svg.getAttribute('width') || '').toLowerCase();
  const looksLikeMathSvg = Boolean(
    /path|polyline|line/.test(markup) &&
    markup.includes('preserveaspectratio') &&
    (viewBoxWidth >= 1000 || (viewBoxWidth / Math.max(viewBoxHeight, 1)) >= 4 || widthAttribute.endsWith('em'))
  );

  let index = null;
  const previous = svg.previousElementSibling;
  const previousText = normalizeText(previous?.innerText || previous?.textContent || '');
  if (previous && RADICAL_INDEX_PATTERN.test(previousText)) index = previousText;

  return { isRoot: looksLikeMathSvg, index };
}

function inferSvgFontSize(svg, rect) {
  const parentSize = Number.parseFloat(window.getComputedStyle(svg.parentElement || svg).fontSize) || 0;
  const heightSize = rect.height || 0;
  return Math.max(parentSize, heightSize * 0.9);
}

function chooseMode(candidates) {
  return [...candidates].sort((left, right) => {
    const leftScore = Math.min(left.fontSize, 60) * 2 + Math.max(0, 700 - left.centerDistance) * 0.2;
    const rightScore = Math.min(right.fontSize, 60) * 2 + Math.max(0, 700 - right.centerDistance) * 0.2;
    return rightScore - leftScore;
  })[0] || null;
}

function scoreExpression({ fontSize, rect, isDirect, partCount = 1, hasRoot = false }) {
  const centerDistance = distanceFromViewportCenter(rect);
  return (
    Math.min(fontSize, 140) * 6 +
    Math.max(0, 800 - centerDistance) * 0.36 +
    Math.min(partCount, 12) * 18 +
    (hasRoot ? 65 : 0) +
    (isDirect ? 85 : 0)
  );
}

function isDirectExpression(text) {
  return /\d/.test(text) && (/[%+\-−x×÷*\/^=]/.test(text) || /\^/.test(text)) && /^[\d\s%+\-−x×÷*\/^=()]+$/.test(text);
}

function splitExpressionParts(value) {
  return normalizeExpression(value).split(/\s+/).filter(Boolean);
}

function looksLikePuzzleMode(text) {
  if (/\d/.test(text)) return false;
  const words = text.split(/\s+/).filter(Boolean);
  const blocked = /^(YOU|OPPONENT|PLAYER|SCORE|TIME|ENTER|ANSWER|START|PAUSE|QUIT|MENU)$/i;
  return words.length >= 1 && words.length <= 9 && !words.every((word) => blocked.test(word));
}

function extractNumbers(value) {
  const withoutRootIndex = String(value).replace(/√\[\d+\]/g, '√');
  return (withoutRootIndex.match(/-?\d+/g) || []).map((number) => Number.parseInt(number, 10));
}

function extractOperators(value) {
  return (value.match(/[%+\-−x×÷*\/^=()^]/g) || []).filter(Boolean);
}

function extractRoot(value) {
  const match = value.match(/√(?:\[(\d+)\])?/);
  return match ? { symbol: '√', index: match[1] ? Number.parseInt(match[1], 10) : 2 } : null;
}

function normalizeExpression(value) {
  return String(value)
    .replace(/−/g, '-')
    .replace(/\s+/g, ' ')
    .replace(/\s*([%+x×÷*\/^=()])\s*/g, ' $1 ')
    .replace(/\s*√\s*/g, '√')
    .replace(/\s*\[\s*(\d+)\s*\]/g, '[$1]')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeToken(value) {
  return String(value).replace(/−/g, '-').trim();
}

function getRenderableText(element) {
  const directText = Array.from(element.childNodes || [])
    .filter((node) => node.nodeType === 3)
    .map((node) => node.nodeValue || '')
    .join(' ');

  if (normalizeText(directText)) return normalizeText(directText);
  if (element.children.length === 0) return normalizeText(element.textContent || '');
  return '';
}

function isIgnoredMirror(element) {
  return Boolean(
    element.getAttribute('aria-hidden') === 'true' ||
    element.closest('[aria-hidden="true"]') ||
    element.getAttribute('data-testid') === 'hidden'
  );
}

function isVisible(element) {
  const style = window.getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return Boolean(
    rect.width > 0 &&
    rect.height > 0 &&
    style.display !== 'none' &&
    style.visibility !== 'hidden' &&
    style.opacity !== '0'
  );
}

function distanceFromViewportCenter(rect) {
  const x = (rect.left + rect.right) / 2;
  const y = (rect.top + rect.bottom) / 2;
  return Math.hypot(x - window.innerWidth / 2, y - window.innerHeight / 2);
}

function normalizeText(value) {
  return String(value).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
}

function fillGameAnswer(answer, submit = false) {
  const parts = String(answer || '').trim().split(/\s+/).filter(Boolean);
  const inputs = Array.from(document.querySelectorAll('input, textarea, [contenteditable="true"]')).filter((el) => isVisible(el));

  if (inputs.length === 0) throw new Error('No game input field found on page.');

  if (parts.length > 1 && inputs.length >= parts.length) {
    for (let i = 0; i < parts.length; i++) {
      setInputValue(inputs[i], parts[i], submit && i === parts.length - 1);
    }
    return;
  }

  setInputValue(inputs[inputs.length - 1], parts.join(' '), submit);
}

function setInputValue(targetInput, val, submit = false) {
  targetInput.focus();
  if (targetInput.tagName === 'INPUT' || targetInput.tagName === 'TEXTAREA') {
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(targetInput, val);
    } else {
    targetInput.value = val;
    }
    targetInput.dispatchEvent(new Event('input', { bubbles: true }));
    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    targetInput.textContent = val;
    targetInput.dispatchEvent(new Event('input', { bubbles: true }));
  }

  if (submit) {
    setTimeout(() => {
      targetInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      targetInput.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      targetInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    }, 50);
  }
}

}
