const $ = id => document.getElementById(id);
const setStatus = (message, good = true, busy = false) => {
  $('status').textContent = message;
  $('dot').className = `status-dot ${good ? 'good' : 'bad'}${busy ? ' busy' : ''}`;
};
const solutionKey = cell => `${cell.row - 1},${cell.col - 1}`;
let lastSolvedResult = null;

function wallStyle(side) {
  const wall = Boolean(side?.wall);
  return {
    [`border${side.name}Width`]: wall ? '2px' : '1px',
    [`border${side.name}Style`]: 'solid',
    [`border${side.name}Color`]: wall ? '#ffffff' : 'rgba(255, 255, 255, .18)'
  };
}

function renderBoard(result) {
  const board = $('grid');
  board.replaceChildren();
  if (!result?.ok) {
    board.innerHTML = '<span class="empty-state">Open a KenKen puzzle and scan it.</span>';
    return;
  }
  board.style.setProperty('--cols', result.cols || 5);
  const solvedKeys = new Set((result.solutionCells || []).map(solutionKey));
  const cells = result.cells || [];
  for (let r = 0; r < result.rows; r++) {
    for (let c = 0; c < result.cols; c++) {
      const cell = cells.find(item => item.row === r + 1 && item.col === c + 1);
      const token = String(result.grid?.[r]?.[c] ?? '·');
      const tile = document.createElement('div');
      tile.className = token === '·' ? 'tile gap' : solvedKeys.has(`${r},${c}`) ? 'tile solution' : 'tile open';
      tile.dataset.row = String(r + 1); tile.dataset.col = String(c + 1);
      tile.title = `R${r + 1}C${c + 1}${cell?.cageId !== undefined ? ` · Cage ${cell.cageId + 1}` : ''}`;
      if (cell?.walls) {
        for (const [name, side] of [['Top', cell.walls.top], ['Right', cell.walls.right], ['Bottom', cell.walls.bottom], ['Left', cell.walls.left]]) Object.assign(tile.style, wallStyle({ ...side, name }));
      }
      if (cell?.clue) {
        const clue = document.createElement('span'); clue.className = 'clue'; clue.textContent = cell.clue.display; tile.appendChild(clue);
      }
      if (tile.classList.contains('gap')) { board.appendChild(tile); continue; }
      const value = document.createElement('span'); value.className = 'value'; value.textContent = token === '□' || token === '?' ? '' : token; tile.appendChild(value); board.appendChild(tile);
    }
  }
}

function render(result) {
  if (!result?.ok) {
    $('challengeLabel').textContent = 'Board not found'; $('solutionState').textContent = 'ERROR'; $('solutionState').className = 'state-pill bad'; renderBoard(null); setStatus(result?.error || result?.message || 'Could not read the board.', false); return;
  }
  $('challengeLabel').textContent = `${result.rows}×${result.cols} puzzle`;
  $('solutionState').textContent = result.solved ? 'SOLVED' : 'SCANNED';
  $('solutionState').className = `state-pill ${result.solved ? 'good' : ''}`;
  renderBoard(result);
  setStatus(result.message || 'Board scanned.', Boolean(result.solved || result.ok));
}

async function send(type, result) { return chrome.runtime.sendMessage(result ? { type, result } : { type }); }
function setBusy(busy) { $('scan').disabled = busy; }

$('scan').addEventListener('click', async () => {
  setBusy(true); setStatus('Scanning, solving, and validating…', true, true);
  try {
    const result = await send('KENKEN_V1_SOLVE');
    render(result);
    if (!result?.ok) throw new Error(result?.error || 'Could not scan the board.');
    if (!result?.solved) throw new Error(result?.message || 'Board scanned, but no validated solution was found.');
    lastSolvedResult = result;
    setStatus('Solved and validated. Filling values…', true, true);
    const filled = await send('KENKEN_V1_FILL_CACHED', result);
    render(filled);
    if (!filled?.fill?.ok) throw new Error(filled?.fill?.error || 'Could not fill the validated solution.');
    setStatus(`Solved, validated, and filled ${filled.fill.filled} value${filled.fill.filled === 1 ? '' : 's'}.`, true);
  } catch (error) { setStatus(error.message || 'Could not scan and solve.', false); }
  finally { setBusy(false); }
});

