const ACTIONS = new Set(['SUDOKU_SCAN','SUDOKU_SOLVE','SUDOKU_SCAN_SOLVE','SUDOKU_FILL','SUDOKU_RESET']);
async function ensureContent(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'SUDOKU_PING' });
    if (ping?.version === 'oneclick-1.0.0') return;
  } catch (_) {}
  await chrome.scripting.executeScript({ target: { tabId }, files: ['solvers/sudoku/sudoku-content.js'] });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!ACTIONS.has(message?.type)) return;
  chrome.tabs.query({ active: true, currentWindow: true }).then(async tabs => {
    const tab = tabs[0];
    if (!tab?.id) throw new Error('No active tab found.');
    await ensureContent(tab.id);
    const response = await chrome.tabs.sendMessage(tab.id, message);
    return response || { ok: false, error: 'The page did not return a response.' };
  }).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));
  return true;
});
