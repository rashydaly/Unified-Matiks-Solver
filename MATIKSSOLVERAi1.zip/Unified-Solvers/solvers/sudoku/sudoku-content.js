if (!globalThis.__MATIKS_SUDOKU_CONTENT_LOADED__) {
  globalThis.__MATIKS_SUDOKU_CONTENT_LOADED__ = true;
(() => {
  'use strict';
  if (window.__sudokuGridSolverCleanup) { try { window.__sudokuGridSolverCleanup(); } catch (_) {} }
  if (window.__sudokuGridSolverLoaded === 'oneclick-1.0.0') return;
  window.__sudokuGridSolverLoaded = 'oneclick-1.0.0';

  const CELL_SELECTOR = '[data-testid^="sudoku-cell-"]';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Tuned for the board's React rendering latency: keep verification, shorten idle waits.
  const FILL_SELECT_WAIT = 18;
  const FILL_ENTRY_WAIT = 42;
  const FILL_RETRY_SELECT_WAIT = 22;
  const FILL_RETRY_ENTRY_WAIT = 65;
  const FILL_SETTLE_WAIT = 18;
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect(), s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden'; };
  const cellIndex = el => Number((el.getAttribute('data-testid') || '').match(/sudoku-cell-(\d+)/)?.[1] ?? -1);

  function readCell(el, size) {
    const node = el.querySelector('div[dir="auto"], [class*="css-146c3p1"]');
    const match = (node?.textContent || '').trim().match(size === 6 ? /[1-6]/ : /[1-9]/);
    return match ? Number(match[0]) : 0;
  }

  function readGrid() {
    const all = [...document.querySelectorAll(CELL_SELECTOR)].filter(visible).sort((a, b) => cellIndex(a) - cellIndex(b));
    const cells = []; const seen = new Set();
    for (const cell of all) { const i = cellIndex(cell); if (i >= 0 && !seen.has(i)) { seen.add(i); cells[i] = cell; } }
    const count = cells.filter(Boolean).length;
    const size = count >= 81 ? 9 : count >= 36 ? 6 : 0;
    if (!size) return { cells, grid: null, size: 0, reason: `Could not find a complete 6×6 or 9×9 board; found ${count} cells.` };
    const grid = Array.from({ length: size }, (_, r) => Array.from({ length: size }, (_, c) => readCell(cells[r * size + c], size)));
    return { cells: cells.slice(0, size * size), grid, size, reason: '' };
  }

  function candidates(grid, r, c, size) {
    if (grid[r][c]) return [];
    const used = new Set();
    for (let i = 0; i < size; i++) { used.add(grid[r][i]); used.add(grid[i][c]); }
    const boxRows = size === 6 ? 2 : 3, boxCols = size === 6 ? 3 : 3;
    const br = Math.floor(r / boxRows) * boxRows, bc = Math.floor(c / boxCols) * boxCols;
    for (let rr = br; rr < br + boxRows; rr++) for (let cc = bc; cc < bc + boxCols; cc++) used.add(grid[rr][cc]);
    const out = []; for (let n = 1; n <= size; n++) if (!used.has(n)) out.push(n); return out;
  }

  function validPartialGrid(grid, size) {
    if (!grid || grid.length !== size) return false;
    for (let r = 0; r < size; r++) { const seen = new Set(); for (const n of grid[r]) if (n && (seen.has(n) || n < 1 || n > size)) return false; else if (n) seen.add(n); }
    for (let c = 0; c < size; c++) { const seen = new Set(); for (let r = 0; r < size; r++) { const n = grid[r][c]; if (n && seen.has(n)) return false; if (n) seen.add(n); } }
    const boxRows = size === 6 ? 2 : 3, boxCols = 3;
    for (let br = 0; br < size; br += boxRows) for (let bc = 0; bc < size; bc += boxCols) { const seen = new Set(); for (let r = br; r < br + boxRows; r++) for (let c = bc; c < bc + boxCols; c++) { const n = grid[r][c]; if (n && seen.has(n)) return false; if (n) seen.add(n); } }
    return true;
  }

  function solveGrid(input, size) {
    const grid = input.map(row => row.slice());
    const validGiven = grid.flat().every(n => n >= 0 && n <= size);
    if (!validGiven) return null;
    // Fast logical propagation: naked and hidden singles.
    function propagate() {
      let changed = true;
      while (changed) {
        changed = false;
        for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) if (!grid[r][c]) {
          const opts = candidates(grid, r, c, size); if (!opts.length) return false;
          if (opts.length === 1) { grid[r][c] = opts[0]; changed = true; }
        }
        for (let r = 0; r < size; r++) for (let n = 1; n <= size; n++) {
          const spots = []; for (let c = 0; c < size; c++) if (!grid[r][c] && candidates(grid, r, c, size).includes(n)) spots.push(c);
          if (spots.length === 1) { grid[r][spots[0]] = n; changed = true; }
        }
        for (let c = 0; c < size; c++) for (let n = 1; n <= size; n++) {
          const spots = []; for (let r = 0; r < size; r++) if (!grid[r][c] && candidates(grid, r, c, size).includes(n)) spots.push(r);
          if (spots.length === 1) { grid[spots[0]][c] = n; changed = true; }
        }
      }
      return true;
    }
    function search() {
      if (!propagate()) return false;
      let best = null, bestOptions = null;
      for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) if (!grid[r][c]) {
        const opts = candidates(grid, r, c, size); if (!opts.length) return false;
        if (!bestOptions || opts.length < bestOptions.length) { best = [r, c]; bestOptions = opts; }
      }
      if (!best) return true;
      const snapshot = grid.map(row => row.slice());
      for (const n of bestOptions) { grid[best[0]][best[1]] = n; if (search()) return true; for (let r = 0; r < size; r++) grid[r] = snapshot[r].slice(); }
      return false;
    }
    return search() ? grid : null;
  }

  function keypadButtons(size) {
    return [...document.querySelectorAll('button, [role="button"], [tabindex="0"]')]
      .filter(el => visible(el) && !el.matches('[data-testid^="sudoku-cell-"]'))
      .reduce((map, el) => { const t = (el.textContent || '').trim(); if (new RegExp(`^[1-${size}]$`).test(t) && !map.has(t)) map.set(t, el); return map; }, new Map());
  }

  function activate(el) {
    if (!el) return false;
    el.focus?.();
    try { el.click(); return true; } catch (_) {}
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    return true;
  }
  function keypadButton(size, value) {
    const grid = readGrid();
    const minY = grid.cells.filter(Boolean).reduce((m, el) => Math.max(m, el.getBoundingClientRect().bottom), 0);
    return [...document.querySelectorAll('button,[role="button"],[tabindex="0"]')].filter(el => visible(el) && !el.matches('[data-testid^="sudoku-cell-"]') && (el.textContent || '').trim() === String(value)).sort((a, b) => {
      const ay = a.getBoundingClientRect().top, by = b.getBoundingClientRect().top;
      return (ay >= minY ? 0 : 100000) + ay - ((by >= minY ? 0 : 100000) + by);
    })[0] || null;
  }
  async function calibratePointer(size) {
    const state = readGrid();
    const firstCell = state.grid && state.size === size ? state.cells[0] : null;
    if (!firstCell) return false;
    activate(firstCell);
    await sleep(FILL_SELECT_WAIT);
    return true;
  }
  async function fillSolution(snapshot, solution) {
    fillCancelled = false;
    const size = snapshot.size, missing = [], visited = [];
    if (!(await calibratePointer(size))) return { filled: 0, missing: ['Could not calibrate pointer to [1,1]'], visited, stale: true };
    let filled = 0;
    const givensMatch = grid => grid && grid.length === size && snapshot.grid.every((row, r) => row.every((n, c) => !n || grid[r][c] === n));
    const pendingStateMatch = grid => givensMatch(grid) && grid.every((row, r) => row.every((value, c) => snapshot.grid[r][c] || value === 0 || value === solution[r][c]));
    // Deterministic traversal: [1,1] -> [1,2] ... [size,size].
    for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) {
      if (fillCancelled) return { filled, missing: ['Fill cancelled by Clear Sudoku'], visited, cancelled: true };
      const coordinate = `[${r + 1},${c + 1}]`;
      let live = readGrid();
      if (!live.grid || live.size !== size) { missing.push(`${coordinate}: board changed`); continue; }
      if (!pendingStateMatch(live.grid)) return { filled, missing: ['Puzzle changed or unexpected value detected before fill'], visited, stale: true };
      const liveBlanks = live.grid.flat().filter(n => !n).length;
      if (liveBlanks === 0) return { filled, missing: [], visited, complete: true };
      // Always inspect the live cell. If it is already occupied, move right.
      if (live.grid[r][c]) { visited.push(`${coordinate}:skip`); continue; }
      const n = solution[r][c], cell = live.cells[r * size + c];
      const button = keypadButton(size, n);
      if (!cell || !button) { missing.push(`${coordinate}=${n}: target missing`); continue; }
      activate(cell);
      await sleep(FILL_SELECT_WAIT);
      // Re-read after selection; React Native Web may replace the DOM node.
      live = readGrid();
      const liveCell = live.cells[r * size + c];
      if (!live.grid || live.grid[r][c]) { visited.push(`${coordinate}:occupied-after-select`); continue; }
      const liveButton = keypadButton(size, n);
      if (!liveCell || !liveButton) { missing.push(`${coordinate}=${n}: keypad missing`); continue; }
      activate(liveButton);
      await sleep(FILL_ENTRY_WAIT);
      let actual = readGrid().grid?.[r]?.[c] || 0;
      if (actual !== n) {
        // One controlled retry on the same coordinate, never jumping ahead.
        const retryGrid = readGrid(), retryCell = retryGrid.cells[r * size + c];
        activate(retryCell); await sleep(FILL_RETRY_SELECT_WAIT);
        activate(keypadButton(size, n)); await sleep(FILL_RETRY_ENTRY_WAIT);
        actual = readGrid().grid?.[r]?.[c] || 0;
      }
      const verifiedGrid = readGrid().grid;
      if (actual === n && pendingStateMatch(verifiedGrid) && validPartialGrid(verifiedGrid, size)) {
        filled++; visited.push(`${coordinate}:${n}`);
        const afterEntry = readGrid();
        if (!pendingStateMatch(afterEntry.grid)) return { filled, missing: ['Puzzle changed after fill; process stopped'], visited, stale: true };
        if (afterEntry.grid.flat().filter(v => !v).length === 0) return { filled, missing: [], visited, complete: true };
      } else {
        await eraseLastEntry(readGrid().cells[r * size + c] || cell);
        missing.push(`${coordinate}=${n}: verification failed`);
      }
      await sleep(FILL_SETTLE_WAIT);
    }
    return { filled, missing: [...new Set(missing)], visited };
  }

  function validSolvedGrid(grid, size) { return !!grid && grid.length === size && grid.every(row => row.length === size && row.every(n => n >= 1 && n <= size)) && grid.every((_, r) => new Set(grid[r]).size === size) && Array.from({ length: size }, (_, c) => new Set(grid.map(row => row[c]))).every(set => set.size === size); }
  async function eraseLastEntry(cell) {
    cell?.click();
    await sleep(120);
    const undo = [...document.querySelectorAll('button,[role="button"],[tabindex="0"]')].filter(visible).find(el => /undo|backspace|delete|erase/i.test(`${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.textContent || ''}`));
    if (undo) { undo.click(); await sleep(180); return; }
    cell?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true }));
    await sleep(180);
  }
  async function scanAndPlaceCertain(limit = Infinity) {
    const snapshot = readGrid();
    const givens = snapshot.grid?.flat().filter(Boolean).length || 0;
    const base = { cellsFound: snapshot.cells.filter(Boolean).length, size: snapshot.size, givens, blanks: snapshot.size ? snapshot.size * snapshot.size - givens : 0, grid: snapshot.grid ? snapshot.grid.map(row => row.map(n => n || '.').join(' ')).join('\n') : '' };
    if (!snapshot.grid) return { ok: false, error: snapshot.reason, diagnostics: base };
    const work = snapshot.grid.map(row => row.slice());
    const placements = [];
    const size = snapshot.size;
    const record = (r, c, n, reason) => { work[r][c] = n; placements.push({ r, c, n, reason }); };
    let progress = true;
    while (progress) {
      progress = false;
      for (let r = 0; r < size && !progress; r++) for (let c = 0; c < size && !progress; c++) if (!work[r][c]) {
        const opts = candidates(work, r, c, size);
        if (opts.length === 1) { record(r, c, opts[0], 'naked single'); progress = true; }
      }
      if (progress) continue;
      const units = [];
      for (let r = 0; r < size; r++) units.push(Array.from({ length: size }, (_, c) => [r, c]));
      for (let c = 0; c < size; c++) units.push(Array.from({ length: size }, (_, r) => [r, c]));
      const brs = size === 6 ? 2 : 3, bcs = 3;
      for (let br = 0; br < size; br += brs) for (let bc = 0; bc < size; bc += bcs) { const unit = []; for (let r = br; r < br + brs; r++) for (let c = bc; c < bc + bcs; c++) unit.push([r, c]); units.push(unit); }
      for (const unit of units) {
        for (let n = 1; n <= size && !progress; n++) {
          if (unit.some(([r, c]) => work[r][c] === n)) continue;
          const spots = unit.filter(([r, c]) => !work[r][c] && candidates(work, r, c, size).includes(n));
          if (spots.length === 1) { const [r, c] = spots[0]; record(r, c, n, 'hidden single'); progress = true; }
        }
        if (progress) break;
      }
    }
    const solved = solveGrid(snapshot.grid, size);
    if (!validSolvedGrid(solved, size)) return { ok: false, error: 'Internal solution validation failed; nothing was filled.', diagnostics: base };
    const buttons = keypadButtons(size); let filled = 0; const failed = [];
    for (const { r, c, n } of placements.slice(0, limit)) {
      const live = readGrid(), cell = live.cells[r * size + c], button = buttons.get(String(n));
      if (!live.grid || !cell || !button || live.grid[r][c] !== 0 || candidates(live.grid, r, c, size).length !== 1 || candidates(live.grid, r, c, size)[0] !== n) { failed.push(`${r + 1},${c + 1}=${n}`); continue; }
      cell.click(); await sleep(140); button.click(); await sleep(320);
      if (readCell(cell, size) !== n) { await eraseLastEntry(cell); failed.push(`${r + 1},${c + 1}=${n}`); continue; }
      const verified = readGrid();
      if (!verified.grid || verified.grid[r][c] !== n || !validPartialGrid(verified.grid, size)) { await eraseLastEntry(cell); failed.push(`${r + 1},${c + 1}=${n}`); continue; }
      filled++; await sleep(220);
    }
    const remaining = work.flat().filter(v => !v).length;
    const diagnostics = { ...base, filled, certainMoves: placements.length, remainingAfterLogic: remaining, grid: snapshot.grid.map(row => row.map(n => n || '.').join(' ')).join('\n') };
    if (failed.length) return { ok: false, filled, error: `Could not verify ${failed.length} placement(s).`, diagnostics };
    if (!placements.length) return { ok: false, filled: 0, error: remaining ? 'No certain move found; no guess was made.' : 'Grid is already complete.', diagnostics };
    return { ok: true, filled, answer: work.flat().join(''), error: remaining ? `Placed ${filled} certain move(s); ${remaining} cell(s) remain.` : '', diagnostics };
  }

  let pendingSnapshot = null;
  let pendingSolution = null;
  let fillCancelled = false;

  function gridText(grid) { return grid.map(row => row.join(' ')).join('\n'); }
  function solutionDiagnostics(snapshot, solution) {
    const givens = snapshot.grid.flat().filter(Boolean).length;
    return { cellsFound: snapshot.cells.filter(Boolean).length, size: snapshot.size, givens, blanks: snapshot.size * snapshot.size - givens, grid: gridText(snapshot.grid), solution: gridText(solution), certainMoves: snapshot.grid.flat().filter((n, i) => !n && solution.flat()[i]).length };
  }

  async function solveAndValidate() {
    const snapshot = readGrid();
    if (!snapshot.grid) return { ok: false, stage: 'scan', error: snapshot.reason, diagnostics: { cellsFound: snapshot.cells.filter(Boolean).length, size: snapshot.size || 0 } };
    if (!validPartialGrid(snapshot.grid, snapshot.size)) { await clearGameBoard(); return { ok: false, stage: 'validate', error: 'Scanned givens conflicted, so the Sudoku was cleared.', diagnostics: { ...solutionDiagnostics(snapshot, snapshot.grid) } }; }
    const solution = solveGrid(snapshot.grid, snapshot.size);
    if (!validSolvedGrid(solution, snapshot.size)) {
      pendingSnapshot = null; pendingSolution = null;
      await clearGameBoard();
      return { ok: false, stage: 'validate', error: 'No complete valid solution was found; the Sudoku was cleared.', diagnostics: { ...solutionDiagnostics(snapshot, snapshot.grid) } };
    }
    for (let r = 0; r < snapshot.size; r++) for (let c = 0; c < snapshot.size; c++) {
      if (snapshot.grid[r][c] && snapshot.grid[r][c] !== solution[r][c]) {
        pendingSnapshot = null; pendingSolution = null;
        await clearGameBoard();
        return { ok: false, stage: 'validate', error: 'Validation rejected the solution; the Sudoku was cleared.', diagnostics: { ...solutionDiagnostics(snapshot, solution) } };
      }
    }
    pendingSnapshot = snapshot; pendingSolution = solution;
    return { ok: true, stage: 'validated', filled: 0, answer: 'ready-to-fill', diagnostics: solutionDiagnostics(snapshot, solution), message: 'Solution validated and ready to fill.' };
  }

  async function fillPendingSolution() {
    if (!pendingSnapshot || !pendingSolution) return { ok: false, stage: 'fill', error: 'No validated solution is ready. Press Solve first.' };
    const result = await fillSolution(pendingSnapshot, pendingSolution);
    if (result.cancelled) return { ok: false, stage: 'reset', filled: result.filled, error: 'Fill stopped by Clear Sudoku.' };
    if (result.stale) { pendingSnapshot = null; pendingSolution = null; return { ok: false, stage: 'stale', filled: result.filled, error: 'New puzzle detected. Old solution discarded.' }; }
    const after = readGrid();
    if (after.grid && validPartialGrid(after.grid, after.size)) {
      const remaining = after.grid.flat().filter(n => !n).length;
      const diagnostics = { ...solutionDiagnostics(pendingSnapshot, pendingSolution), filled: result.filled, remaining };
      if (remaining === 0) { pendingSnapshot = null; pendingSolution = null; }
      return { ok: result.missing.length === 0, stage: 'fill', filled: result.filled, error: result.missing.length ? `Could not verify ${result.missing.length} cell(s).` : (remaining ? `${remaining} cell(s) remain.` : ''), diagnostics };
    }
    return { ok: false, stage: 'fill', filled: result.filled, error: 'Board validation failed after filling; check the game state.' };
  }

  async function solve() { return solveAndValidate(); }
  async function solveOneStep() { return solveAndValidate(); }
  async function clearAndResolve() {
    const clear = [...document.querySelectorAll('button,[role="button"],[tabindex="0"]')].filter(visible).find(el => /clear/i.test((el.textContent || '').trim()));
    if (!clear) return { ok: false, error: 'Game Clear button was not found.' };
    clear.click(); await sleep(90); return solve();
  }

  function findClearControl() {
    const textNode = [...document.querySelectorAll('div[dir="auto"],button,[role="button"],[tabindex="0"]')].filter(visible).find(el => /^clear$/i.test((el.textContent || '').trim()));
    if (!textNode) return null;
    return textNode.closest('[tabindex="0"],[role="button"],button') || textNode;
  }
  async function clearGameBoard() {
    const clear = findClearControl();
    if (!clear) return false;
    activate(clear);
    await sleep(450);
    return true;
  }
  async function resetSudoku() {
    fillCancelled = true;
    pendingSnapshot = null; pendingSolution = null;
    const cleared = await clearGameBoard();
    return cleared ? { ok: true, stage: 'reset', message: 'Process stopped and Sudoku cleared; ready at [1,1].' } : { ok: false, stage: 'reset', error: 'Game CLEAR control was not found.' };
  }

  let autoTimer = null, autoObserver = null, autoBusy = false, autoEnabled = false, autoSeen = '', autoBlocked = '', autoCandidate = '', autoStable = 0;
  function boardSignature(state) { return state?.grid ? `${state.size}:${state.grid.flat().join('')}:${state.cells.map(el => el?.getAttribute('data-testid') || '').join('|')}` : ''; }
  async function autoProcess() {
    if (!autoEnabled || autoBusy) return;
    const state = readGrid(), sig = boardSignature(state);
    if (!state.grid || !sig || sig === autoSeen || sig === autoBlocked) return;
    if (sig !== autoCandidate) { autoCandidate = sig; autoStable = 1; return; }
    if (++autoStable < 2) return;
    autoSeen = sig; autoCandidate = ''; autoStable = 0;
    if (state.grid.flat().filter(v => !v).length === 0) { pendingSnapshot = null; pendingSolution = null; return; }
    autoBusy = true;
    try {
      const solved = await solveAndValidate();
      if (!solved.ok) {
        pendingSnapshot = null; pendingSolution = null;
        await clearGameBoard();
        autoBlocked = boardSignature(readGrid());
        return;
      }
      const filled = await fillPendingSolution();
      if (!filled.ok) {
        pendingSnapshot = null; pendingSolution = null;
        await clearGameBoard();
        autoBlocked = boardSignature(readGrid());
        return;
      }
      pendingSnapshot = null; pendingSolution = null;
      autoSeen = boardSignature(readGrid());
    } finally { autoBusy = false; }
  }
  function startAuto() {
    if (autoTimer) return { ok: true, auto: true };
    autoEnabled = true; autoSeen = ''; autoBlocked = ''; autoCandidate = ''; autoStable = 0;
    const tick = () => autoProcess().catch(async () => { pendingSnapshot = null; pendingSolution = null; await clearGameBoard(); autoBlocked = boardSignature(readGrid()); });
    autoTimer = setInterval(tick, 500);
    autoObserver = new MutationObserver(() => { if (autoEnabled && !autoBusy) queueMicrotask(tick); });
    autoObserver.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['style', 'class', 'data-testid'] });
    return { ok: true, auto: true, message: 'Auto Mode enabled.' };
  }
  function stopAuto() { autoEnabled = false; if (autoTimer) clearInterval(autoTimer); autoTimer = null; autoObserver?.disconnect(); autoObserver = null; autoBusy = false; autoCandidate = ''; autoStable = 0; return { ok: true, auto: false, message: 'Auto Mode stopped.' }; }
  function stopWatch() { return stopAuto(); }
  window.__sudokuGridSolverCleanup = () => { fillCancelled = true; stopAuto(); };
  window.__sudokuGridSolverDebug = { candidates, validPartialGrid, solveGrid, validSolvedGrid, readGrid, fillSolution };
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {   if (msg?.type === 'SUDOKU_PING') { sendResponse({ ok: true, version: 'oneclick-1.0.0' }); return false; } if (msg?.type === 'SUDOKU_SCAN') { const snapshot = readGrid(); sendResponse(snapshot.grid ? { ok: true, stage: 'scan', diagnostics: { ...solutionDiagnostics(snapshot, snapshot.grid) }, message: 'Board scanned. Press Solve.' } : { ok: false, stage: 'scan', error: snapshot.reason, diagnostics: { cellsFound: snapshot.cells.filter(Boolean).length, size: snapshot.size || 0 } }); return false; } if (msg?.type === 'SUDOKU_SOLVE') { solveAndValidate().then(async solved => { if (!solved?.ok) return solved; const filled = await fillPendingSolution(); return { ...solved, ok: filled.ok, stage: 'fill', filled: filled.filled || 0, error: filled.error || '', diagnostics: filled.diagnostics || solved.diagnostics, message: filled.ok ? `Solved, validated, and filled ${filled.filled || 0} value(s).` : (filled.error || 'The validated solution could not be filled.') }; }).then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message })); return true; } if (msg?.type === 'SUDOKU_SCAN_SOLVE') { solve().then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message })); return true; } if (msg?.type === 'SUDOKU_FILL') { fillPendingSolution().then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message })); return true; } if (msg?.type === 'SUDOKU_RESET') { resetSudoku().then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message })); return true; } if (msg?.type === 'SUDOKU_AUTO_START') { sendResponse(startAuto()); return false; } if (msg?.type === 'SUDOKU_AUTO_STOP') { sendResponse(stopAuto()); return false; } if (msg?.type === 'SUDOKU_READ') { sendResponse(readGrid()); return false; }  });
})();

}
