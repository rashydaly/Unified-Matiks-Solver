const $ = id => document.getElementById(id);
const statusEl = $('status');
const dot = $('dot');
const solveButton = $('solveButton');
const gridEl = $('solutionGrid');
const sizeBadge = $('sizeBadge');

function setStatus(text, good = true, busy = false) {
  statusEl.textContent = text;
  dot.className = `status-dot ${good ? 'good' : 'bad'}${busy ? ' busy' : ''}`;
}

function parseGrid(text) {
  return String(text || '').trim().split(/\n+/).filter(Boolean).map(line =>
    line.trim().split(/\s+/).map(value => Number(value)).filter(value => Number.isFinite(value))
  );
}

function renderSolution(result) {
  const diagnostics = result?.diagnostics || {};
  const grid = parseGrid(diagnostics.solution);
  const size = Number(diagnostics.size) || grid.length;
  gridEl.replaceChildren();
  if (!grid.length || !size) {
    sizeBadge.textContent = '—';
    gridEl.innerHTML = '<div class="empty-state">Press Solve to scan the board.</div>';
    return;
  }
  sizeBadge.textContent = `${size}×${size}`;
  gridEl.style.setProperty('--size', String(size));
  const boxRows = size === 6 ? 2 : 3;
  const boxCols = 3;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const cell = document.createElement('div');
      cell.className = 'solution-cell';
      if ((c + 1) % boxCols === 0 && c + 1 < size) cell.classList.add('box-right');
      if ((r + 1) % boxRows === 0 && r + 1 < size) cell.classList.add('box-bottom');
      cell.textContent = String(grid[r]?.[c] ?? '');
      cell.title = `[${r + 1},${c + 1}]`;
      gridEl.appendChild(cell);
    }
  }
}

async function send(type) { return chrome.runtime.sendMessage({ type }); }

solveButton.addEventListener('click', async () => {
  solveButton.disabled = true;
  setStatus('Scanning, solving, validating, and filling…', true, true);
  try {
    const result = await send('SUDOKU_SOLVE');
    renderSolution(result);
    if (!result?.ok) throw new Error(result?.error || 'Could not solve the Sudoku.');
    const size = result.diagnostics?.size || 'Sudoku';
    const filled = result.filled ?? 0;
    setStatus(`${size} solved and ${filled} value${filled === 1 ? '' : 's'} filled.`, true);
  } catch (error) {
    setStatus(error.message || 'Extension communication failed.', false);
  } finally {
    solveButton.disabled = false;
  }
});
