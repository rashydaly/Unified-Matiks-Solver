(() => {
  'use strict';
  const VERSION = 'scanner-v1';
  const pagePayloads=[];
  if(typeof window!=='undefined'&&typeof window.addEventListener==='function')window.addEventListener('__cross_math_page_payload__',event=>{
    try{
      const payload=JSON.parse(String(event.detail||''));
      if(!payload?.body||typeof payload.body!=='string')return;
      pagePayloads.push({source:payload.source||'unknown',url:payload.url||'',bytes:payload.body.length,body:payload.body});
      if(pagePayloads.length>12)pagePayloads.splice(0,pagePayloads.length-12);
    }catch{}
  });
  function directPuzzleCandidates(item){
    let root;
    try{root=JSON.parse(item.body);}catch{return[];}
    const found=[],visited=new WeakSet();
    const add=(path,value)=>{
      if(!value||typeof value!=='object'||found.length>=3)return;
      try{found.push({path,preview:JSON.stringify(value).slice(0,14000)});}catch{}
    };
    const walk=(value,path,depth)=>{
      if(!value||typeof value!=='object'||depth>7||found.length>=3)return;
      if(visited.has(value))return;visited.add(value);
      if(Object.prototype.hasOwnProperty.call(value,'puzzle'))add(`${path}.puzzle`,value.puzzle);
      if(Object.prototype.hasOwnProperty.call(value,'crossMathPuzzle'))add(`${path}.crossMathPuzzle`,value.crossMathPuzzle);
      if(Array.isArray(value.cells)&&value.cells.length&&value.cells.length<=49)add(`${path}.cells`,{cells:value.cells,availableAnswers:value.availableAnswers||[]});
      const expression=value.expression;
      const candidateExpression=Array.isArray(expression)?expression[0]:expression;
      if(candidateExpression){
        try{const candidate=typeof candidateExpression==='string'?JSON.parse(candidateExpression):candidateExpression;if(candidate&&typeof candidate==='object')add(`${path}.expression[0]`,candidate);}catch{}
      }
      const keys=Array.isArray(value)?value.keys():Object.keys(value);
      for(const key of keys){const child=value[key];if(child&&typeof child==='object')walk(child,Array.isArray(value)?`${path}[${key}]`:`${path}.${key}`,depth+1);}
    };
    walk(root,'$',0);
    return found;
  }
  const STATIC_REFS = {"0":"M5.38 16.16L5.38 16.16Q4.05 16.16 2.98 15.49Q1.92 14.82 1.31 13.53Q0.70 12.24 0.70 10.40L0.70 10.40Q0.70 8.56 1.31 7.27Q1.92 5.98 2.98 5.31Q4.05 4.64 5.38 4.64L5.38 4.64Q6.72 4.64 7.78 5.31Q8.83 5.98 9.45 7.27Q10.06 8.56 10.06 10.40L10.06 10.40Q10.06 12.24 9.45 13.53Q8.83 14.82 7.78 15.49Q6.72 16.16 5.38 16.16ZM5.38 14.35L5.38 14.35Q6.16 14.35 6.74 13.93Q7.31 13.50 7.64 12.62Q7.97 11.74 7.97 10.40L7.97 10.40Q7.97 9.04 7.64 8.17Q7.31 7.30 6.74 6.87Q6.16 6.45 5.38 6.45L5.38 6.45Q4.62 6.45 4.04 6.87Q3.46 7.30 3.13 8.17Q2.80 9.04 2.80 10.40L2.80 10.40Q2.80 11.74 3.13 12.62Q3.46 13.50 4.04 13.93Q4.62 14.35 5.38 14.35Z","1":"M4.58 16L2.50 16L2.50 5.60L3.41 6.54L0.13 6.54L0.13 4.80L4.58 4.80L4.58 16Z","2":"M8.82 16L0.56 16L0.56 14.61L5.01 10.38Q5.57 9.86 5.84 9.46Q6.11 9.06 6.20 8.71Q6.29 8.37 6.29 8.06L6.29 8.06Q6.29 7.30 5.76 6.87Q5.23 6.45 4.21 6.45L4.21 6.45Q3.39 6.45 2.73 6.74Q2.06 7.02 1.58 7.62L1.58 7.62L0.13 6.50Q0.78 5.62 1.90 5.13Q3.01 4.64 4.38 4.64L4.38 4.64Q5.60 4.64 6.50 5.03Q7.41 5.42 7.90 6.14Q8.38 6.86 8.38 7.86L8.38 7.86Q8.38 8.40 8.24 8.94Q8.10 9.47 7.70 10.06Q7.30 10.66 6.53 11.39L6.53 11.39L2.70 15.02L2.27 14.24L8.82 14.24L8.82 16Z","3":"M3.17 12.12L3.17 12.12Q2.28 12.12 1.43 11.86Q0.59 11.60 0.01 11.15L0.01 11.15L0.68 9.94Q1.14 10.31 1.79 10.54Q2.44 10.76 3.14 10.76L3.14 10.76Q3.98 10.76 4.45 10.42Q4.92 10.08 4.92 9.49L4.92 9.49Q4.92 8.92 4.49 8.58Q4.06 8.24 3.10 8.24L3.10 8.24L2.33 8.24L2.33 7.18L4.73 4.32L4.93 4.91L0.42 4.91L0.42 3.60L6.14 3.60L6.14 4.64L3.74 7.50L2.93 7.02L3.40 7.02Q4.94 7.02 5.72 7.71Q6.49 8.40 6.49 9.48L6.49 9.48Q6.49 10.19 6.13 10.79Q5.77 11.39 5.03 11.75Q4.30 12.12 3.17 12.12Z","4":"M10.69 13.46L0.54 13.46L0.54 12.02L6.06 4.80L8.29 4.80L2.85 12.02L1.81 11.70L10.69 11.70L10.69 13.46ZM8.70 16L6.69 16L6.69 13.46L6.75 11.70L6.75 9.44L8.70 9.44L8.70 16Z","5":"M4.42 16.16L4.42 16.16Q3.23 16.16 2.10 15.82Q0.98 15.47 0.21 14.86L0.21 14.86L1.09 13.25Q1.70 13.74 2.57 14.05Q3.44 14.35 4.38 14.35L4.38 14.35Q5.49 14.35 6.12 13.89Q6.75 13.42 6.75 12.64L6.75 12.64Q6.75 12.11 6.49 11.71Q6.22 11.31 5.56 11.10Q4.90 10.90 3.74 10.90L3.74 10.90L1.04 10.90L1.62 4.80L8.19 4.80L8.19 6.54L2.38 6.54L3.47 5.55L3.04 10.11L1.95 9.14L4.21 9.14Q5.87 9.14 6.89 9.58Q7.90 10.02 8.38 10.79Q8.85 11.57 8.85 12.56L8.85 12.56Q8.85 13.54 8.37 14.35Q7.89 15.17 6.90 15.66Q5.92 16.16 4.42 16.16Z","6":"M5.55 16.16L5.55 16.16Q4.03 16.16 2.94 15.51Q1.86 14.86 1.28 13.63Q0.70 12.40 0.70 10.59L0.70 10.59Q0.70 8.67 1.40 7.34Q2.10 6.02 3.34 5.33Q4.58 4.64 6.19 4.64L6.19 4.64Q7.04 4.64 7.82 4.82Q8.59 4.99 9.14 5.36L9.14 5.36L8.37 6.93Q7.90 6.62 7.37 6.50Q6.83 6.38 6.24 6.38L6.24 6.38Q4.66 6.38 3.73 7.36Q2.80 8.34 2.80 10.24L2.80 10.24Q2.80 10.54 2.82 10.95Q2.83 11.36 2.93 11.78L2.93 11.78L2.29 11.07Q2.58 10.42 3.08 9.98Q3.58 9.54 4.28 9.31Q4.98 9.09 5.79 9.09L5.79 9.09Q6.90 9.09 7.76 9.51Q8.62 9.94 9.14 10.71Q9.65 11.49 9.65 12.53L9.65 12.53Q9.65 13.63 9.10 14.45Q8.56 15.26 7.63 15.71Q6.70 16.16 5.55 16.16ZM5.44 14.53L5.44 14.53Q6.08 14.53 6.58 14.30Q7.07 14.06 7.35 13.63Q7.63 13.20 7.63 12.62L7.63 12.62Q7.63 11.74 7.02 11.23Q6.42 10.72 5.39 10.72L5.39 10.72Q4.72 10.72 4.22 10.97Q3.71 11.22 3.42 11.65Q3.12 12.08 3.12 12.64L3.12 12.64Q3.12 13.15 3.39 13.58Q3.66 14.02 4.18 14.27Q4.70 14.53 5.44 14.53Z","7":"M4.80 16L2.58 16L7.20 5.63L7.74 6.56L1.39 6.56L2.38 5.55L2.38 8.46L0.45 8.46L0.45 4.80L9.15 4.80L9.15 6.19L4.80 16Z","8":"M5.20 16.16L5.20 16.16Q3.81 16.16 2.78 15.74Q1.76 15.33 1.20 14.57Q0.64 13.81 0.64 12.78L0.64 12.78Q0.64 11.76 1.18 11.06Q1.73 10.35 2.75 9.98Q3.78 9.62 5.20 9.62L5.20 9.62Q6.62 9.62 7.66 9.98Q8.69 10.35 9.24 11.06Q9.79 11.78 9.79 12.78L9.79 12.78Q9.79 13.81 9.22 14.57Q8.66 15.33 7.62 15.74Q6.59 16.16 5.20 16.16ZM5.20 14.53L5.20 14.53Q6.35 14.53 7.02 14.05Q7.70 13.57 7.70 12.72L7.70 12.72Q7.70 11.89 7.02 11.41Q6.35 10.93 5.20 10.93L5.20 10.93Q4.05 10.93 3.39 11.41Q2.74 11.89 2.74 12.72L2.74 12.72Q2.74 13.57 3.39 14.05Q4.05 14.53 5.20 14.53ZM5.20 10.70L5.20 10.70Q3.90 10.70 2.98 10.36Q2.05 10.02 1.54 9.35Q1.04 8.69 1.04 7.76L1.04 7.76Q1.04 6.80 1.56 6.10Q2.08 5.41 3.02 5.02Q3.97 4.64 5.20 4.64L5.20 4.64Q6.45 4.64 7.39 5.02Q8.34 5.41 8.86 6.10Q9.39 6.80 9.39 7.76L9.39 7.76Q9.39 8.69 8.89 9.35Q8.38 10.02 7.44 10.36Q6.50 10.70 5.20 10.70ZM5.20 9.42L5.20 9.42Q6.19 9.42 6.77 9Q7.34 8.58 7.34 7.86L7.34 7.86Q7.34 7.10 6.75 6.69Q6.16 6.27 5.20 6.27L5.20 6.27Q4.24 6.27 3.66 6.69Q3.09 7.10 3.09 7.86L3.09 7.86Q3.09 8.58 3.66 9Q4.22 9.42 5.20 9.42Z","9":"M4.48 4.64L4.48 4.64Q6.02 4.64 7.10 5.29Q8.18 5.94 8.75 7.17Q9.33 8.40 9.33 10.21L9.33 10.21Q9.33 12.13 8.63 13.46Q7.94 14.78 6.70 15.47Q5.47 16.16 3.84 16.16L3.84 16.16Q2.99 16.16 2.22 15.98Q1.46 15.81 0.90 15.44L0.90 15.44L1.66 13.87Q2.13 14.18 2.67 14.30Q3.22 14.42 3.79 14.42L3.79 14.42Q5.38 14.42 6.30 13.44Q7.23 12.46 7.23 10.56L7.23 10.56Q7.23 10.26 7.22 9.85Q7.20 9.44 7.10 9.02L7.10 9.02L7.74 9.73Q7.47 10.38 6.96 10.82Q6.45 11.26 5.76 11.49Q5.07 11.71 4.24 11.71L4.24 11.71Q3.15 11.71 2.28 11.29Q1.41 10.86 0.90 10.09Q0.38 9.31 0.38 8.27L0.38 8.27Q0.38 7.15 0.93 6.34Q1.47 5.54 2.41 5.09Q3.34 4.64 4.48 4.64ZM4.59 6.27L4.59 6.27Q3.95 6.27 3.46 6.50Q2.96 6.74 2.68 7.16Q2.40 7.58 2.40 8.18L2.40 8.18Q2.40 9.06 3.01 9.57Q3.62 10.08 4.64 10.08L4.64 10.08Q5.31 10.08 5.82 9.83Q6.34 9.58 6.62 9.14Q6.91 8.70 6.91 8.16L6.91 8.16Q6.91 7.63 6.64 7.21Q6.37 6.78 5.86 6.53Q5.34 6.27 4.59 6.27Z","+":"M5.58 14L3.87 14L3.87 6.80L5.58 6.80L5.58 14ZM8.42 11.20L1.04 11.20L1.04 9.60L8.42 9.60L8.42 11.20Z","-":"M5.28 12.38L0.88 12.38L0.88 10.72L5.28 10.72L5.28 12.38Z","*":"M2.66 13.62L1.58 12.45L6.78 7.18L7.89 8.35L2.66 13.62ZM6.78 13.62L1.58 8.35L2.66 7.18L7.89 12.45L6.78 13.62Z","÷":"M8.42 11.20L1.04 11.20L1.04 9.60L8.42 9.60L8.42 11.20ZM4.72 14.78L4.72 14.78Q4.26 14.78 3.94 14.46Q3.62 14.13 3.62 13.63L3.62 13.63Q3.62 13.12 3.94 12.81Q4.26 12.50 4.72 12.50L4.72 12.50Q5.20 12.50 5.52 12.81Q5.84 13.12 5.84 13.63L5.84 13.63Q5.84 14.13 5.52 14.46Q5.20 14.78 4.72 14.78ZM4.72 8.30L4.72 8.30Q4.26 8.30 3.94 7.98Q3.62 7.65 3.62 7.15L3.62 7.15Q3.62 6.66 3.94 6.34Q4.26 6.02 4.72 6.02L4.72 6.02Q5.20 6.02 5.52 6.34Q5.84 6.66 5.84 7.15L5.84 7.15Q5.84 7.65 5.52 7.98Q5.20 8.30 4.72 8.30Z","=":"M8.42 9.26L1.04 9.26L1.04 7.66L8.42 7.66L8.42 9.26ZM8.42 13.14L1.04 13.14L1.04 11.54L8.42 11.54L8.42 13.14Z"};
  const DIGITS = '0123456789'.split('');
  const OPERATORS = ['+','-','*','÷','='];
  const clean = v => String(v ?? '').replace(/\s+/g, ' ').trim();
  const norm = v => clean(v).replace(/[×xX]/g, '*').replace(/÷/g, '÷');
  const numberRe = /^-?\d+$/;
  const visible = el => { if (!el) return false; const r=el.getBoundingClientRect(),s=getComputedStyle(el); return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'; };
  const background = el => `${el?.style?.backgroundColor || ''} ${el ? getComputedStyle(el).backgroundColor : ''}`.toLowerCase();
  const isGreen = bg => bg.includes('10, 185, 99') || bg.includes('10,185,99');
  const nums = d => (clean(d).match(/[-+]?(?:\d*\.\d+|\d+\.?\d*)/g)||[]).map(Number);
  // Preserve actual translated coordinates. Seeding bounds with zero falsely
  // makes right-shifted glyphs overlap the leading minus contour.
  const box = d => { const n=nums(d),xs=[],ys=[]; for(let i=0;i+1<n.length;i+=2){xs.push(n[i]);ys.push(n[i+1]);} return {minX:xs.length?Math.min(...xs):0,maxX:xs.length?Math.max(...xs):0,minY:ys.length?Math.min(...ys):0,maxY:ys.length?Math.max(...ys):0}; };
  const width = b => Math.max(.001,b.maxX-b.minX);
  const height = b => Math.max(.001,b.maxY-b.minY);
  const aspect = b => width(b)/height(b);
  function subpaths(d) {
    const raw=clean(d), out=[], re=/([Mm])\s*([-+]?(?:\d*\.\d+|\d+\.?\d*))/g; let m;
    while((m=re.exec(raw))) out.push({at:m.index,x:Number(m[2])});
    if(!out.length) return [{d:raw,x:0,box:box(raw)}];
    return out.map((s,i)=>{const end=i+1<out.length?out[i+1].at:raw.length;const part=raw.slice(s.at,end).trim();return {d:part,x:s.x,box:box(part)};});
  }
  function contains(inner, outer) {
    const pad=.25;
    return inner.minX>=outer.minX-pad&&inner.maxX<=outer.maxX+pad&&inner.minY>=outer.minY-pad&&inner.maxY<=outer.maxY+pad&&width(inner)<width(outer)*.94&&height(inner)<height(outer)*.98;
  }
  function mergeBox(a,b){return {minX:Math.min(a.minX,b.minX),maxX:Math.max(a.maxX,b.maxX),minY:Math.min(a.minY,b.minY),maxY:Math.max(a.maxY,b.maxY)};}
  function xOverlap(a,b){const overlap=Math.max(0,Math.min(a.maxX,b.maxX)-Math.max(a.minX,b.minX));return overlap/Math.max(.001,Math.min(width(a),width(b)));}
  function groupContours(parts) {
    const groups=[];
    for(const part of parts){
      let owner=null;
      for(let i=groups.length-1;i>=0;i--){
        const g=groups[i];
        if(contains(part.box,g.box) || contains(g.box,part.box) || (xOverlap(part.box,g.box)>=.35 && part.x<=g.box.maxX+.45)){owner=g;break;}
      }
      if(owner){owner.d += ' '+part.d; owner.contours++; owner.box=mergeBox(owner.box,part.box); owner.lastX=part.x; owner.parts.push(part);}
      else groups.push({d:part.d,contours:1,box:part.box,lastX:part.x,parts:[part]});
    }
    return groups.sort((a,b)=>a.box.minX-b.box.minX);
  }
  function canonical(d) {
    const n=nums(d); if(!n.length)return clean(d);
    const b=box(d),sx=width(b),sy=height(b); let out='';
    for(let i=0;i<n.length;i++) out += (i%2===0 ? ((n[i]-b.minX)/sx) : ((n[i]-b.minY)/sy)).toFixed(2)+',';
    return out;
  }
  function similarity(a,b){const n=a.length,m=b.length;if(!n||!m)return 0;let prev=Array.from({length:m+1},(_,i)=>i);for(let i=1;i<=n;i++){const cur=[i];for(let j=1;j<=m;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur;}return 1-prev[m]/Math.max(n,m);}
  function refFeature(d){const raw=clean(d),cached=featureCache.get(raw);if(cached)return cached;const b=box(raw),feature={d:raw,canon:canonical(raw),aspect:aspect(b),contours:subpaths(raw).length,commands:(raw.match(/[A-Za-z]/g)||[]).length};featureCache.set(raw,feature);return feature;}
  const featureCache = new Map(), decodeCache = new Map();
  const refs = new Map(Object.entries(STATIC_REFS).map(([ch,d])=>[ch,[refFeature(d)]]));
  function learn(label,d){const value=String(label);const chars=value.replace(/^-/,'').split('');const groups=groupContours(subpaths(d));if(groups.length!==chars.length)return;chars.forEach((ch,i)=>{if(!refs.has(ch))refs.set(ch,[]);refs.get(ch).push(refFeature(groups[i].d));});}
  function score(candidate,ref){const sim=similarity(candidate.canon,ref.canon);const asp=1-Math.min(1,Math.abs(Math.log(candidate.aspect/ref.aspect))/1.5);const contour=candidate.contours===ref.contours?1:Math.max(0,1-Math.abs(candidate.contours-ref.contours)/3);const cmds=Math.max(0,1-Math.abs(candidate.commands-ref.commands)/Math.max(candidate.commands,ref.commands,1));return .72*sim+.13*asp+.10*contour+.05*cmds;}
  function matchGlyph(d,allowed){
    const candidate=refFeature(d), set=allowed||Array.from(refs.keys());
    // Keep the best score per CHARACTER first. Footer calibration adds more
    // samples of the same digit; those must not count as an ambiguity.
    const byCharacter=[];
    for(const ch of set){
      let bestForCharacter=null;
      for(const ref of (refs.get(ch)||[])){
        const refScore=score(candidate,ref);
        if(!bestForCharacter||refScore>bestForCharacter.score)bestForCharacter={ch,score:refScore};
      }
      if(bestForCharacter)byCharacter.push(bestForCharacter);
    }
    byCharacter.sort((a,b)=>b.score-a.score);
    const best=byCharacter[0]||null, second=byCharacter[1]||null;
    const margin=best&&second?best.score-second.score:1;
    return best&&best.score>=.70&&margin>=.008?{ch:best.ch,score:best.score,margin}:null;
  }
  function shapeOperator(d){const b=box(d),w=width(b),h=height(b),commands=(clean(d).match(/[A-Za-z]/g)||[]).length;return {dash:w/h>2.1&&h/w<.55&&commands<=12,equals:w/h>1.8&&subpaths(d).length>=2,plus:commands<=8&&w/h<1.2};}
  function matchToken(d){const raw=clean(d);const exact=Object.entries(STATIC_REFS).find(([,v])=>clean(v)===raw);if(exact)return{ch:exact[0],score:1};const op=shapeOperator(raw);let first=matchGlyph(raw,OPERATORS);if(op.dash&&(!first||first.ch==='-'||first.score<.86))first={ch:'-',score:Math.max(first?.score||0,.86),margin:1};if(first&&first.score>=.70)return first;const digit=matchGlyph(raw,DIGITS);return digit||{ch:'?',score:0,margin:0};}
  function decodePath(d){const raw=clean(d);if(!raw)return{value:'?',confidence:0,segments:[]};const cached=decodeCache.get(raw);if(cached)return cached;const exactEntry=Object.entries(STATIC_REFS).find(([,v])=>clean(v)===raw);if(exactEntry){const result={value:exactEntry[0],confidence:1,segments:[{value:exactEntry[0],score:1,contours:subpaths(raw).length,bbox:box(raw),previewPath:raw}]};decodeCache.set(raw,result);return result;}const groups=groupContours(subpaths(raw));const segments=groups.map(g=>{const hit=matchToken(g.d);return {value:hit.ch,score:hit.score,contours:g.contours,bbox:g.box,previewPath:g.d};});const value=segments.map(s=>s.value).join('');const ok=segments.length>0&&segments.every(s=>s.value!=='?');const result={value:ok?value:'?',confidence:ok?Math.min(...segments.map(s=>s.score)):0,segments};decodeCache.set(raw,result);return result;}
  function decodeCell(el){const text=norm(el.innerText||el.textContent);if(numberRe.test(text)||/^[+\-*\/=÷]$/.test(text))return{text:text,value:text,confidence:1,segments:[]};const paths=Array.from(el.querySelectorAll('svg path'));if(!paths.length)return{text:'',value:'?',confidence:0,segments:[]};const decoded=paths.map(p=>decodePath(p.getAttribute('d')||''));const value=decoded.map(x=>x.value).join('');return{text:'',value:value||'?',confidence:Math.min(...decoded.map(x=>x.confidence)),segments:decoded.flatMap(x=>x.segments)};}
  function cellState(el){const paths=el.querySelectorAll('svg path').length;const bg=background(el);const inner=Array.from(el.querySelectorAll('div')).find(x=>isGreen(background(x)))||el;const ib=background(inner);if(paths)return'filled';if(ib.includes('0.4')||bg.includes('0.4'))return'blank';if(isGreen(bg))return'filled';return'outside';}
  function evalExpr(tokens){const vals=[],ops=[],prec=o=>o==='*'||o==='÷'||o==='/'?2:1;for(const t of tokens){if(/^-?\d+$/.test(String(t)))vals.push(Number(t));else if(['+','-','*','÷','/'].includes(t)){while(ops.length&&prec(ops[ops.length-1])>=prec(t)){const b=vals.pop(),a=vals.pop(),o=ops.pop();if(a===undefined||b===undefined)return null;if((o==='÷'||o==='/')&&(!b||a%b!==0))return null;vals.push(o==='+'?a+b:o==='-'?a-b:o==='*'?a*b:a/b);}ops.push(t);}else return null;}while(ops.length){const b=vals.pop(),a=vals.pop(),o=ops.pop();if(a===undefined||b===undefined)return null;if((o==='÷'||o==='/')&&(!b||a%b!==0))return null;vals.push(o==='+'?a+b:o==='-'?a-b:o==='*'?a*b:a/b);}return vals.length===1?vals[0]:null;}
  function solveCrossGrid(grid,options){const side=grid.length;if(![5,7].includes(side)||grid.some(row=>row.length!==side))return{found:false,reason:'Unsupported board dimensions.'};const blanks=[];grid.forEach((row,r)=>row.forEach((v,c)=>{if(v==='□')blanks.push({r,c,key:`${r},${c}`});}));if(!blanks.length||options.length!==blanks.length)return{found:false,reason:`Need ${blanks.length} answer values for ${options.length} playable blanks.`};if(grid.flat().some(v=>v==='?'))return{found:false,reason:'One or more populated SVG cells are unresolved.'};const lines=[];const add=(tokens,axis,index)=>{const t=tokens.filter(x=>x!=='·'),eq=t.indexOf('=');if(eq>0&&eq<t.length-1&&numberRe.test(String(t[eq+1])))lines.push({tokens:t,axis,index,eq,result:Number(t[eq+1])});};for(let r=0;r<side;r++)add(grid[r],'row',r);for(let c=0;c<side;c++)add(grid.map(row=>row[c]),'column',c);const valueFor=(line,i,assign)=>line.tokens[i]==='□'?assign[`${line.axis==='row'?line.index:i},${line.axis==='row'?i:line.index}`]:line.tokens[i];const valid=assign=>lines.length>0&&lines.every(line=>{const ts=line.tokens.map((_,i)=>String(valueFor(line,i,assign)??''));return ts.every(Boolean)&&evalExpr(ts.slice(0,line.eq))===line.result;});let answer=null,assign={},used=Array(options.length).fill(false);function dfs(i){if(answer)return;if(i===blanks.length){if(valid(assign))answer={...assign};return;}const b=blanks[i];for(let j=0;j<options.length;j++){if(used[j])continue;used[j]=true;assign[b.key]=Number(options[j]);dfs(i+1);used[j]=false;delete assign[b.key];if(answer)return;}}dfs(0);if(!answer)return{found:false,reason:'No answer-bank assignment satisfies every shared row and column equation.'};return{found:true,grid:grid.map((row,r)=>row.map((v,c)=>answer[`${r},${c}`]??v)),solutionCells:blanks.map(b=>({row:b.r+1,col:b.c+1,index:b.r*side+b.c,value:answer[b.key]})),validation:{equations:lines.length,passed:true}};}
  function scan(){const raw=Array.from(document.querySelectorAll('[data-testid^="grid-item-"]')).filter(visible).sort((a,b)=>Number(a.dataset.testid.split('-').pop())-Number(b.dataset.testid.split('-').pop()));const side=Math.sqrt(raw.length);if(!Number.isInteger(side)||![5,7].includes(side))return{ok:false,error:`Expected a 5×5 or 7×7 grid, found ${raw.length} visible grid cells. Open the active Cross Math puzzle first.`};const options=Array.from(document.querySelectorAll('[data-testid^="footer-item-"]')).filter(visible).map(el=>{const id=el.dataset.testid||'',m=id.match(/-(-?\d+)$/),value=m?m[1]:norm(el.innerText||el.textContent);const p=el.querySelector('svg path');if(p&&/^\d+$/.test(value))learn(value,p.getAttribute('d')||'');return{value,id};}).filter(x=>/^\d+$/.test(x.value));const cells=raw.map((el,index)=>{const state=cellState(el),decoded=state==='filled'?decodeCell(el):null;return{index,row:Math.floor(index/side)+1,col:index%side+1,state,value:state==='outside'?'·':state==='blank'?'□':decoded.value,confidence:decoded?.confidence||0,segments:decoded?.segments||[],paths:el.querySelectorAll('svg path').length};});const grid=Array.from({length:side},(_,r)=>cells.slice(r*side,r*side+side).map(c=>c.value));const unresolved=cells.filter(c=>c.state==='filled'&&c.value==='?').map(c=>({row:c.row,col:c.col,index:c.index,confidence:c.confidence,paths:c.paths,segments:c.segments}));const solved=solveCrossGrid(grid,options.map(x=>x.value)),shown=solved.found?solved.grid:grid;const rows=shown.map((row,i)=>({index:i+1,text:row.join(' ')})),cols=Array.from({length:side},(_,c)=>({index:c+1,text:shown.map(row=>row[c]).join(' ')}));const sourceProbe=pagePayloads.map(item=>({source:item.source,url:item.url,bytes:item.bytes,candidates:directPuzzleCandidates(item)}));return{ok:true,name:'Cross Math Solver',version:VERSION,rows:side,cols:side,grid:shown,cells,options,answerValues:options.map(x=>x.value),solutionCells:solved.solutionCells||[],unresolved,solved:solved.found,validation:solved.validation||null,rowsView:rows,colsView:cols,sourceProbe,counts:{gridCells:raw.length,filled:cells.filter(c=>c.state==='filled').length,playableBlanks:cells.filter(c=>c.state==='blank').length,inactiveGaps:cells.filter(c=>c.state==='outside').length,svgPaths:cells.reduce((n,c)=>n+c.paths,0),answerOptions:options.length,capturedPayloads:sourceProbe.length},message:solved.found?`Solved and validated using ${options.length} answer options on a ${side}×${side} board.`:`Captured board; solution unresolved${unresolved.length?` at ${unresolved.map(c=>`R${c.row}C${c.col}`).join(', ')}`:''}: ${solved.reason||'unknown'}`};}
  function clearLegacySolutionLabels(){document.getElementById?.('cross-math-solver-labels')?.remove();}
  function runAndRender(){clearLegacySolutionLabels();return scan();}
  // Minimal waits preserve the game's React/render event cycle without the old slow pauses.
  const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  function pressGameControl(element){
    if(!element)return false;
    try{element.focus?.({preventScroll:true});element.click();return true;}catch{return false;}
  }
  async function fillValidatedSolution(result,onProgress){
    if(!result?.ok||!result.solved||!Array.isArray(result.solutionCells)||!result.solutionCells.length)throw new Error('A validated solution is required before values can be filled.');
    const pending=result.solutionCells.filter(item=>result.cells?.[item.index]?.state==='blank');
    if(!pending.length)return{filled:0,total:0};
    let optionCache = null;
    const getOption = value => {
      if (!optionCache) {
        optionCache = new Map(Array.from(document.querySelectorAll('[data-testid^="footer-item-"]'))
          .filter(node => visible(node) && node.querySelector('svg path'))
          .map(node => [String(node.dataset.testid || '').split('-').pop(), node]));
      }
      let node = optionCache.get(String(value));
      if (!node || !node.isConnected || !visible(node)) {
        optionCache = null;
        node = new Map(Array.from(document.querySelectorAll('[data-testid^="footer-item-"]'))
          .filter(item => visible(item) && item.querySelector('svg path'))
          .map(item => [String(item.dataset.testid || '').split('-').pop(), item])).get(String(value));
      }
      return node || null;
    };
    for(let position=0;position<pending.length;position++){
      const item=pending[position];
      onProgress?.(position+1,pending.length,item.value);
      const grid=document.querySelector(`[data-testid="grid-item-${item.index}"]`);
      if(!grid||cellState(grid)!=='blank')throw new Error(`Blank cell ${item.index+1} is no longer available.`);
      const footer=getOption(item.value);
      if(!footer)throw new Error(`The required answer ${item.value} is no longer available.`);
      if(!pressGameControl(footer))throw new Error(`Could not select answer ${item.value}.`);
      await pause(0);
      if(!pressGameControl(grid))throw new Error(`Could not select blank cell ${item.index+1}.`);
      await pause(8);
      const updated=document.querySelector(`[data-testid="grid-item-${item.index}"]`);
      if(!updated||cellState(updated)!=='filled')throw new Error(`Matiks did not accept ${item.value} for blank cell ${item.index+1}.`);
    }
    return{filled:pending.length,total:pending.length};
  }
  let floatingSolver=null;
  function ensureFloatingSolver(){
    if(typeof location==='undefined'||location.hostname!=='matiks.com'||!document.body)return null;
    if(floatingSolver)return floatingSolver;
    document.getElementById('cross-math-floating-solver')?.remove();
    const host=document.createElement('div');host.id='cross-math-floating-solver';host.style.cssText='position:fixed;z-index:2147483647;pointer-events:none';
    const root=host.attachShadow({mode:'open'});
    root.innerHTML=`<style>:host{all:initial}*{box-sizing:border-box}.panel{position:fixed;right:18px;bottom:88px;width:298px;padding:9px;background:#17130a;border:1px solid #725920;border-radius:12px;color:#eafff2;box-shadow:0 12px 30px #000b;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;pointer-events:auto}.panel[hidden]{display:none}.bar{display:flex;align-items:center;gap:7px;cursor:grab;user-select:none}.bar:active{cursor:grabbing}.mark{position:relative;width:28px;height:28px;display:grid;place-items:center;overflow:hidden;border:1px solid #a67b17;border-radius:7px;background:#173425;isolation:isolate}.bolt{position:absolute;z-index:-1;width:5px;height:38px;background:#a7f3c5;clip-path:polygon(45% 0,100% 0,67% 39%,100% 39%,39% 100%,48% 56%,0 56%);filter:drop-shadow(0 0 3px #8df0b7)}.bolt.a{transform:rotate(-45deg)}.bolt.b{transform:rotate(45deg)}.mark b{color:#ddffe9;font-size:6px;font-weight:1000;letter-spacing:-.7px;text-shadow:0 1px 2px #000}.title{min-width:0;flex:1}.eyebrow{color:#a7f3c5;font-size:8px;font-weight:900;letter-spacing:.14em}.name{margin-top:1px;font-size:13px;font-weight:900;letter-spacing:-.02em}.close{width:22px;height:22px;border:0;border-radius:6px;background:#1c3225;color:#b7e8c9;cursor:pointer;font-size:15px}.solve{width:100%;margin-top:8px;padding:8px;border:0;border-radius:8px;background:#a7f3c5;color:#211701;font-weight:950;font-size:12px;cursor:pointer}.solve:disabled{opacity:.6}.status{margin:7px 1px 0;color:#c4b477;font-size:9px;line-height:1.35}.status.good{color:#caffdf}.status.bad{color:#ff9d79}.grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:3px;margin-top:8px}.tile{aspect-ratio:1;display:grid;place-items:center;border-radius:4px;background:#79d9a2;color:#0d2117;font:850 9px/1 ui-monospace,SFMono-Regular,Menlo,monospace}.tile.op{background:#58bf86}.tile.blank{background:#14261c;border:1px solid #367256;color:transparent}.tile.gap{background:transparent;border:1px solid transparent}.tile.solution{background:#c7f7d8;color:#332400;box-shadow:inset 0 -2px #4bbf7a}.hint{margin-top:6px;color:#a4cdb2;font-size:8px;text-align:center}</style><section class="panel" hidden><header class="bar"><div class="mark" aria-label="MATH lightning X logo"><i class="bolt a"></i><i class="bolt b"></i><b>MATH</b></div><div class="title"><div class="eyebrow">CROSS MATH · V1</div><div class="name">Floating Solver</div></div><button class="close" title="Minimize">×</button></header><button class="solve">Solve & Fill</button><div class="status">Panel is empty. Press Solve & Fill to read and place the current values.</div><div class="grid"></div><div class="hint">Uses the game’s own grid and answer-bank controls.</div></section>`;
    const panel=root.querySelector('.panel'),bar=root.querySelector('.bar'),close=root.querySelector('.close'),solveButton=root.querySelector('.solve'),status=root.querySelector('.status'),grid=root.querySelector('.grid');
    const setOpen=open=>{panel.hidden=!open;};
    const render=result=>{status.className=`status ${result?.solved?'good':'bad'}`;status.textContent=result?.solved?`Solved · ${result.validation?.equations||0} equations verified`:result?.message||'Could not solve this board.';grid.replaceChildren();if(!result?.ok)return;result.grid.flat().forEach((value,index)=>{const token=String(value??'·'),tile=document.createElement('span'),solution=result.solutionCells?.some(cell=>cell.index===index);tile.className=token==='·'?'tile gap':token==='□'||token==='?'?'tile blank':solution?'tile solution':/^[+\-*\/=÷]$/.test(token)?'tile op':'tile';tile.textContent=token==='·'||token==='□'?'':token;grid.appendChild(tile);});};
    close.addEventListener('click',()=>setOpen(false));solveButton.addEventListener('click',async()=>{solveButton.disabled=true;try{const result=runAndRender();render(result);if(!result.solved)throw new Error(result.message||'Puzzle was not validated.');const fill=await fillValidatedSolution(result,(current,total,value)=>{status.className='status good';status.textContent=`Placing ${value} · ${current}/${total}`;});status.className='status good';status.textContent=`Placed ${fill.filled} value${fill.filled===1?'':'s'} using Matiks controls.`;}catch(error){status.className='status bad';status.textContent=error?.message||'Could not place the solution.';}finally{solveButton.disabled=false;}});
    let drag=null;bar.addEventListener('pointerdown',event=>{if(event.target.closest('button'))return;const rect=panel.getBoundingClientRect();drag={x:event.clientX,y:event.clientY,left:rect.left,top:rect.top};panel.style.left=`${rect.left}px`;panel.style.top=`${rect.top}px`;panel.style.right='auto';panel.style.bottom='auto';bar.setPointerCapture(event.pointerId);});bar.addEventListener('pointermove',event=>{if(!drag)return;const rect=panel.getBoundingClientRect(),left=Math.max(8,Math.min(window.innerWidth-rect.width-8,drag.left+event.clientX-drag.x)),top=Math.max(8,Math.min(window.innerHeight-rect.height-8,drag.top+event.clientY-drag.y));panel.style.left=`${left}px`;panel.style.top=`${top}px`;});bar.addEventListener('pointerup',()=>{drag=null;});
    document.body.appendChild(host);floatingSolver={toggle:()=>{setOpen(panel.hidden);return !panel.hidden;},render};return floatingSolver;
  }
  if(typeof window!=='undefined') window.__crossMathDebug={decodePath,groupContours,subpaths,matchToken,STATIC_REFS,scan,runAndRender};
  if(typeof document!=='undefined'){document.getElementById?.('cross-math-floating-solver')?.remove();clearLegacySolutionLabels();}
  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{if(msg?.type==='CROSS_MATH_CLEAR'){const controls=Array.from(document.querySelectorAll('button,[role=button]'));const clear=controls.find(el=>/^clear$/i.test(norm(el.innerText||el.textContent))||/^clear$/i.test(norm(el.getAttribute('aria-label')||'')));if(!clear){sendResponse({ok:false,error:'Game CLEAR control was not found.'});return false;}try{clear.click();sendResponse({ok:true});}catch(error){sendResponse({ok:false,error:error?.message||'Could not clear the game board.'});}return false;}if(msg?.type==='CROSS_MATH_SCAN'||msg?.type==='EQUATION_CAPTURE'){sendResponse(runAndRender());return false;}if(msg?.type==='CROSS_MATH_SOLVE_FILL'){const result=runAndRender();if(!result?.solved){sendResponse({...result,fill:{ok:false,error:result?.message||'Puzzle was not validated.'}});return false;}fillValidatedSolution(result).then(fill=>sendResponse({...result,fill:{ok:true,...fill}})).catch(error=>sendResponse({...result,fill:{ok:false,error:error?.message||'Could not place the solution.'}}));return true;}if(msg?.type==='CROSS_MATH_PING'){sendResponse({ok:true,version:VERSION});return false;}});
})();
