(() => {
  'use strict';
  const EVENT = '__cross_math_page_payload__';
  const MAX_BYTES = 180000;
  const emitted = new Set();

  function report(source, url, text) {
    if (typeof text !== 'string' || text.length < 20 || text.length > MAX_BYTES) return;
    if (!/(challenge|puzzle|grid|answer|option|equation|expression|availableAnswers|emptyblock)/i.test(text)) return;
    try {
      JSON.parse(text);
    } catch {
      return;
    }
    const key = `${source}|${url}|${text.length}|${text.slice(0, 96)}`;
    if (emitted.has(key)) return;
    emitted.add(key);
    window.dispatchEvent(new CustomEvent(EVENT, {
      detail: JSON.stringify({ source, url, body: text }),
    }));
  }

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = function (...args) {
      return originalFetch.apply(this, args).then((response) => {
        try {
          response.clone().text().then((text) => report('fetch', response.url, text)).catch(() => {});
        } catch {}
        return response;
      });
    };
  }

  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__crossMathProbeUrl = String(url || '');
    return open.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', () => {
      try {
        report('xhr', this.responseURL || this.__crossMathProbeUrl || '', this.responseText || '');
      } catch {}
    }, { once: true });
    return send.apply(this, args);
  };

  const NativeWebSocket = window.WebSocket;
  if (typeof NativeWebSocket === 'function') {
    function CrossMathWebSocket(...args) {
      const socket = new NativeWebSocket(...args);
      socket.addEventListener('message', (event) => {
        if (typeof event.data === 'string') report('websocket', String(args[0] || ''), event.data);
      });
      return socket;
    }
    CrossMathWebSocket.prototype = NativeWebSocket.prototype;
    Object.setPrototypeOf(CrossMathWebSocket, NativeWebSocket);
    window.WebSocket = CrossMathWebSocket;
  }
})();
