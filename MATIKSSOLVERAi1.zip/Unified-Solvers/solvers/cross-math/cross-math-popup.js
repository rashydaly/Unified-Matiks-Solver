const $ = id => document.getElementById(id);
const setStatus = (message, good = true) => { $('status').textContent = message; $('dot').className = good ? 'good' : 'bad'; };
const formatAxis = list => list?.length ? list.map(e => `${String(e.index).padStart(2, '0')}:  ${e.expression}`).join('\n') : 'No operators or equals signs detected.';
function render(result) {
  if (!result?.ok) {
    $('dimensions').textContent = '—'; $('cellCount').textContent = '—'; $('optionCount').textContent = '—'; $('pathCount').textContent = '—';
    $('grid').innerHTML = '<span class="empty-state">No puzzle captured.</span>'; $('rows').textContent = '—'; $('columns').textContent = '—'; $('answers').textContent = '—'; $('details').textContent = result?.error || 'Scan failed.';
    setStatus(result?.error || 'Scan failed.', false); return;
  }
  $('dimensions').textContent = `${result.rows} × ${result.cols}`;
  $('cellCount').textContent = result.cells?.length ?? 0;
  $('optionCount').textContent = result.options?.length ?? 0;
  $('pathCount').textContent = `${result.rows} × ${result.cols}`;
  $('grid').innerHTML = '';
  $('grid').style.setProperty('--cols', result.cols);
  result.grid.flatMap((row, r) => row.map((value, c) => ({ value, r, c }))).forEach(({ value, r, c }) => {
    const tile = document.createElement('span');
    const token = String(value ?? '.');
    const isSolution = Array.isArray(result.solutionCells) && result.solutionCells.some(cell => (cell.row === r + 1 && cell.col === c + 1) || (cell.index === r * result.cols + c));
    tile.className = token === '·' ? 'tile gap' : token === '□' || token === '?' || token === '.' ? 'tile blank' : isSolution ? 'tile solution' : /^[+\-*\/=÷]$/.test(token) ? 'tile operator' : 'tile value';
    tile.textContent = token === '·' ? '' : token === '□' || token === '.' ? '' : token;
    tile.title = `Row ${r + 1}, Column ${c + 1}: ${token === '.' ? 'blank' : token}${isSolution ? ' · solver value' : ''}`;
    $('grid').appendChild(tile);
  });
  $('rows').textContent = result.rowsView?.map(e => `${String(e.index).padStart(2, '0')}:  ${e.text}`).join('\n') || '—';
  $('columns').textContent = result.colsView?.map(e => `${String(e.index).padStart(2, '0')}:  ${e.text}`).join('\n') || '—';
  $('answers').innerHTML = '';
  if (result.options?.length) result.options.forEach(a => { const chip = document.createElement('span'); chip.className = 'answer'; chip.textContent = a.value; $('answers').appendChild(chip); }); else $('answers').textContent = 'No answer options detected in the lower bank.';
  const solState = $('solutionState'); const solSummary = $('solutionSummary');
  if (result.solved) { solState.textContent = 'VALID'; solState.className = 'valid'; solSummary.textContent = `All shared cells assigned. ${result.validation?.equations ?? 0} row/column equations passed.`; }
  else { solState.textContent = 'NOT VALIDATED'; solState.className = 'invalid'; solSummary.textContent = result.message || 'No complete valid assignment found.'; }
  $('details').textContent = `Grid cells: ${result.counts?.gridCells ?? 0}\nFilled cells: ${result.counts?.filled ?? 0}\nPlayable blanks: ${result.counts?.playableBlanks ?? 0}\nSVG paths in board: ${result.counts?.svgPaths ?? 0}\nAnswer option tiles: ${result.counts?.answerOptions ?? 0}\n\nScanner mode: read-only; no cells are filled.`;
  setStatus(result.message || 'Puzzle captured.', true);
}

let lastSignature = '';
let completedSignature = '';
let autoTimer = null;
let scanBusy = false;
let fillInProgress = false;
let autoSolvedSignature = '';
const resultSignature = result => result?.ok ? `${result.rows}x${result.cols}|${result.grid?.flat().join(',')}|${result.options?.map(x=>x.value).join(',')}` : '';
async function scanOnce(silent=false) {
  if (scanBusy || fillInProgress) return null;
  scanBusy = true;
  try {
    const result = await chrome.runtime.sendMessage({ type: 'CROSS_MATH_SCAN' });
    const signature = resultSignature(result);
    if (signature && signature === completedSignature) return result;
    if (signature !== completedSignature) completedSignature = '';
    if (!silent || signature !== lastSignature) { render(result); lastSignature = signature; }
    if (result?.ok && result.solved) {
      $('fill').disabled = false;
      if (autoSolveEnabled && signature && signature !== autoSolvedSignature) {
        autoSolvedSignature = signature;
        setTimeout(() => { if (!$('fill').disabled && !fillInProgress) $('fill').click(); }, 0);
      }
      return result;
    }
    if (!silent && result?.ok && !result.solved) {
      $('fill').disabled = true;
      setStatus('Not validated. Clearing and retrying in 2 seconds…', false);
      setAutoScan(false);
      await clearAndWait();
      setAutoScan(scanEnabled);
      return result;
    }
    if (!result?.ok && !silent) $('fill').disabled = true;
    return result;
  } catch (error) {
    if (!silent) setStatus(error.message || 'Scan failed.', false);
    return null;
  } finally { scanBusy = false; }
}
async function clearAndWait() {
  await chrome.runtime.sendMessage({ type: 'CROSS_MATH_CLEAR' });
  lastSignature = ''; completedSignature = ''; autoSolvedSignature = '';
  await new Promise(resolve => setTimeout(resolve, 2000));
}
function setAutoScan(enabled) {
  clearInterval(autoTimer); autoTimer = null;
  if (enabled && !fillInProgress) { scanOnce(true); autoTimer = setInterval(() => scanOnce(true), 500); }
}
let scanEnabled = true;
let autoSolveEnabled = false;
$('scanToggle').addEventListener('click', () => {
  scanEnabled = !scanEnabled;
  const button = $('scanToggle'); button.className = `power-toggle ${scanEnabled ? 'on' : 'off'}`; button.textContent = scanEnabled ? 'ON' : 'OFF'; button.setAttribute('aria-pressed', String(scanEnabled));
  setAutoScan(scanEnabled);
  setStatus(scanEnabled ? 'Auto scan enabled.' : 'Auto scan paused.', scanEnabled);
});
$('autoSolveToggle').addEventListener('click', () => {
  autoSolveEnabled = !autoSolveEnabled;
  const button = $('autoSolveToggle'); button.className = `power-toggle ${autoSolveEnabled ? 'on' : 'off'}`; button.textContent = autoSolveEnabled ? 'ON' : 'OFF'; button.setAttribute('aria-pressed', String(autoSolveEnabled));
  if (!autoSolveEnabled) autoSolvedSignature = '';
  setStatus(autoSolveEnabled ? 'Auto solve enabled.' : 'Auto solve disabled.', autoSolveEnabled);
});
setAutoScan(true);


$('fill').addEventListener('click', async () => {
  if (fillInProgress) return;
  fillInProgress = true;
  setAutoScan(false);
  $('fill').disabled = true; $('scanToggle').disabled = true; setStatus('Filling solution…');
  try {
    const result = await chrome.runtime.sendMessage({ type: 'CROSS_MATH_SOLVE_FILL' });
    if (!result?.ok || !result?.fill?.ok) {
      setStatus(result?.fill?.wrong ? 'Wrong fill detected. Clearing board…' : 'Not validated. Clearing board…', false);
      await chrome.runtime.sendMessage({ type: 'CROSS_MATH_CLEAR' });
      lastSignature = ''; completedSignature = ''; autoSolvedSignature = '';
      $('grid').innerHTML = '<span class="empty-state">Board cleared after invalid fill.</span>';
      throw new Error(result?.fill?.error || result?.error || 'Could not fill the solution.');
    }
    render(result);
    completedSignature = resultSignature(result);
    lastSignature = completedSignature;
    setStatus(`Filled ${result.fill.filled} validated values. Waiting for next puzzle…`, true);
    setTimeout(() => { if (scanEnabled && !fillInProgress) setAutoScan(true); }, 350);
  } catch (error) { setStatus(error.message || 'Fill failed.', false); }
  finally { fillInProgress = false; $('scanToggle').disabled = false; $('fill').disabled = false; if (scanEnabled && !autoTimer) setAutoScan(true); }
});
