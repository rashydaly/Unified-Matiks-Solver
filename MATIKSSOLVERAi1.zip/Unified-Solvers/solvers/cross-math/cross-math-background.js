const ACTIONS = new Set(['CROSS_MATH_SCAN', 'CROSS_MATH_SOLVE_FILL', 'CROSS_MATH_CLEAR']);

async function ensureContent(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'CROSS_MATH_PING' });
    if (ping?.ok && String(ping.version || '').startsWith('scanner-')) return;
  } catch {}
  await chrome.scripting.executeScript({ target: { tabId }, files: ['solvers/cross-math/cross-math-content.js'] });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!ACTIONS.has(msg?.type)) return;
  chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(async tabs => {
    const tab = tabs[0];
    if (!tab?.id) throw new Error('No active game tab found.');
    await ensureContent(tab.id);
    return chrome.tabs.sendMessage(tab.id, msg);
  }).then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message || 'Unable to scan the active tab.' }));
  return true;
});
