if (!globalThis.__MATIKS_MIND_SNAP_CONTENT_LOADED__) {
  globalThis.__MATIKS_MIND_SNAP_CONTENT_LOADED__ = true;
(() => {
  if (window.__MIND_SNAP_SCANNER__) return;
  window.__MIND_SNAP_SCANNER__ = true;

  let lastCapture = null;
  let cachedCanvas = null;
  let autoEnabled = false;
  let autoFillEnabled = false;
  let fillAccuracy = 50;
  let autoRunId = 0;
  let autoFillRunId = 0;
  let autoSawReveal = false;
  let autoBusy = false;
  const OVERLAY_ID = '__mind_snap_canvas_grid_overlay__';
  const FAST_SCAN_MAX_MS = 360;
  const FAST_TAP_DELAY = 8;
  const PROBE_TAP_DELAY = 16;
  const MAX_PROBE_CLICKS = 16;
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  async function restorePersistentSettings() {
    try {
      const saved = await chrome.runtime.sendMessage({ type: 'MIND_SNAP_CONTENT_READY' });
      if (!saved?.ok) return;
      fillAccuracy = Math.max(10, Math.min(100, Number(saved.accuracy) || 50));
      if (!saved.scannerEnabled) return;
      autoEnabled = true;
      autoFillEnabled = !!saved.autoSolverEnabled;
      autoRunId += 1;
      autoSawReveal = false;
      autoBusy = false;
      autoLoop(autoRunId);
    } catch (_error) {
      // The page can still operate manually if settings cannot be restored.
    }
  }

  function removeOverlay() {
    document.getElementById(OVERLAY_ID)?.remove();
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function canvasRect(canvas) {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    return { left: rect.left, top: rect.top, width: rect.width, height: rect.height, right: rect.right, bottom: rect.bottom };
  }

  function findGameCanvas() {
    if (cachedCanvas?.isConnected) {
      const cachedRect = canvasRect(cachedCanvas);
      if (cachedRect && cachedRect.width >= 120 && cachedRect.height >= 120) return { canvas: cachedCanvas, rect: cachedRect };
    }
    const canvases = [...document.querySelectorAll('canvas')]
      .map(canvas => ({ canvas, rect: canvasRect(canvas) }))
      .filter(item => item.rect && item.rect.width >= 120 && item.rect.height >= 120 && item.rect.width <= 900 && item.rect.height <= 900)
      .filter(item => Math.max(item.rect.width, item.rect.height) / Math.min(item.rect.width, item.rect.height) <= 1.2)
      .filter(item => item.rect.bottom > 80 && item.rect.top < innerHeight - 10);
    canvases.sort((a, b) => {
      const areaDiff = b.rect.width * b.rect.height - a.rect.width * a.rect.height;
      if (Math.abs(areaDiff) > 100) return areaDiff;
      return (b.rect.top + b.rect.left * .1) - (a.rect.top + a.rect.left * .1);
    });
    cachedCanvas = canvases[0]?.canvas || null;
    return canvases[0] || null;
  }

  function readCanvas(canvas) {
    const width = canvas.width;
    const height = canvas.height;
    if (!width || !height) return Promise.resolve(null);
    try {
      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (context) return Promise.resolve({ width, height, data: context.getImageData(0, 0, width, height).data });
    } catch (_error) {
      // A WebGL-backed canvas may not expose a 2D context; use its rendered image below.
    }
    return new Promise(resolve => {
      try {
        const image = new Image();
        image.onload = () => {
          try {
            const copy = document.createElement('canvas');
            copy.width = width;
            copy.height = height;
            const context = copy.getContext('2d', { willReadFrequently: true });
            context.drawImage(image, 0, 0, width, height);
            resolve({ width, height, data: context.getImageData(0, 0, width, height).data });
          } catch (_error) {
            resolve(null);
          }
        };
        image.onerror = () => resolve(null);
        image.src = canvas.toDataURL('image/png');
      } catch (_error) {
        resolve(null);
      }
    });
  }

  function pixelAt(image, x, y) {
    const px = clamp(Math.round(x), 0, image.width - 1);
    const py = clamp(Math.round(y), 0, image.height - 1);
    const index = (py * image.width + px) * 4;
    return [image.data[index], image.data[index + 1], image.data[index + 2], image.data[index + 3]];
  }

  function isBluePixel(rgb) {
    const [r, g, b, a] = rgb;
    if (a < 80) return false;
    const max = Math.max(r, g, b);
    if (max < 100) return false;
    return (g >= 115 && b >= 115 && g - r >= 14 && b - r >= 14) || (b >= 135 && b - r >= 28 && b >= g * .86);
  }

  function luminance(rgb) {
    return rgb[0] * .2126 + rgb[1] * .7152 + rgb[2] * .0722;
  }

  function rowProfile(image, y) {
    const profile = [];
    const step = Math.max(1, Math.floor(image.width / 420));
    for (let x = 0; x < image.width; x += step) profile.push(luminance(pixelAt(image, x, y)));
    return { values: profile, step };
  }

  function columnProfile(image, x) {
    const profile = [];
    const step = Math.max(1, Math.floor(image.height / 420));
    for (let y = 0; y < image.height; y += step) profile.push(luminance(pixelAt(image, x, y)));
    return { values: profile, step };
  }

  function findBands(profile, threshold) {
    const bands = [];
    let start = -1;
    for (let i = 0; i < profile.values.length; i += 1) {
      if (profile.values[i] >= threshold && start < 0) start = i;
      if ((profile.values[i] < threshold || i === profile.values.length - 1) && start >= 0) {
        const end = i === profile.values.length - 1 && profile.values[i] >= threshold ? i : i - 1;
        if (end - start + 1 >= 2) bands.push({ start, end });
        start = -1;
      }
    }
    return bands;
  }

  function candidateBoundaries(values, minGap) {
    const sorted = [...values].sort((a, b) => b - a);
    const chosen = [];
    for (const value of sorted) {
      if (!chosen.some(existing => Math.abs(existing - value) < minGap)) chosen.push(value);
    }
    return chosen.sort((a, b) => a - b);
  }

  function inferAxis(image, axis) {
    const dimension = axis === 'x' ? image.width : image.height;
    const samples = [];
    const sampleCount = Math.max(5, Math.min(15, Math.round(dimension / 28)));
    for (let i = 1; i < sampleCount; i += 1) {
      const fraction = i / sampleCount;
      const profile = axis === 'x' ? rowProfile(image, Math.round(image.height * fraction)) : columnProfile(image, Math.round(image.width * fraction));
      const maxValue = Math.max(...profile.values);
      const minValue = Math.min(...profile.values);
      const threshold = minValue + (maxValue - minValue) * .38;
      const bands = findBands(profile, threshold);
      for (const band of bands) {
        const center = (band.start + band.end) / 2 * profile.step;
        const size = (band.end - band.start + 1) * profile.step;
        if (size >= dimension * .015 && size <= dimension * .46) samples.push({ center, size });
      }
    }

    const spacing = Math.max(4, dimension * .018);
    const bands = [];
    for (const item of samples.sort((a, b) => a.center - b.center)) {
      const previous = bands[bands.length - 1];
      if (previous && Math.abs(previous.center - item.center) < spacing) {
        previous.center = (previous.center * previous.count + item.center) / (previous.count + 1);
        previous.size = Math.max(previous.size, item.size);
        previous.count += 1;
      } else {
        bands.push({ center: item.center, size: item.size, count: 1 });
      }
    }

    const strong = bands.filter(band => band.count >= Math.max(2, Math.floor(sampleCount / 5)));
    if (strong.length >= 3) return strong;
    return bands;
  }

  function axisFromDarkBands(image, axis, expectedSize) {
    const dimension = axis === 'x' ? image.width : image.height;
    const profile = axis === 'x' ? rowProfile(image, Math.round(image.height * .5)) : columnProfile(image, Math.round(image.width * .5));
    const minValue = Math.min(...profile.values);
    const maxValue = Math.max(...profile.values);
    const contrast = maxValue - minValue;
    if (contrast < 5) return null;

    const gapThreshold = minValue + contrast * .36;
    const tileBands = findBands(profile, gapThreshold).filter(band => {
      const size = (band.end - band.start + 1) * profile.step;
      return size >= dimension / (expectedSize * 2.4) && size <= dimension / (expectedSize * .45);
    });
    if (tileBands.length >= expectedSize - 1) {
      const centers = tileBands.map(band => (band.start + band.end) / 2 * profile.step);
      const avgSize = tileBands.reduce((sum, band) => sum + (band.end - band.start + 1) * profile.step, 0) / tileBands.length;
      const gap = dimension / expectedSize;
      const first = centers[0];
      return { count: expectedSize, centers: Array.from({ length: expectedSize }, (_, i) => first + i * gap), tileSize: avgSize };
    }
    return null;
  }

  function scoreGrid(image, size, xBands, yBands) {
    if (xBands.length !== size || yBands.length !== size) return -Infinity;
    const xGaps = xBands.slice(1).map((value, i) => value - xBands[i]);
    const yGaps = yBands.slice(1).map((value, i) => value - yBands[i]);
    const avgX = xGaps.reduce((sum, value) => sum + value, 0) / xGaps.length;
    const avgY = yGaps.reduce((sum, value) => sum + value, 0) / yGaps.length;
    const gapError = [...xGaps, ...yGaps].reduce((sum, value) => sum + Math.abs(value - (avgX + avgY) / 2), 0) / (xGaps.length + yGaps.length);
    const centerX = xBands.reduce((sum, value) => sum + value, 0) / size;
    const centerY = yBands.reduce((sum, value) => sum + value, 0) / size;
    const centerBonus = centerX > image.width * .15 && centerX < image.width * .85 && centerY > image.height * .15 && centerY < image.height * .85 ? 1 : 0;
    return size * 5 + centerBonus * 3 - gapError / Math.max(1, (avgX + avgY) / 2) * 20;
  }

  function makeAxisCenters(bands, size, dimension) {
    if (bands.length < size) return null;
    const candidates = bands.map(band => band.center);
    let best = null;
    for (let start = 0; start <= candidates.length - size; start += 1) {
      const selected = candidates.slice(start, start + size);
      const gaps = selected.slice(1).map((value, i) => value - selected[i]);
      const average = gaps.reduce((sum, value) => sum + value, 0) / Math.max(1, gaps.length);
      const error = gaps.reduce((sum, value) => sum + Math.abs(value - average), 0);
      if (!best || error < best.error) best = { centers: selected, error };
    }
    return best?.centers || null;
  }

  function bandMean(image, x0, x1, y0, y1) {
    let total = 0;
    let count = 0;
    const left = Math.max(0, Math.floor(x0));
    const right = Math.min(image.width - 1, Math.ceil(x1));
    const top = Math.max(0, Math.floor(y0));
    const bottom = Math.min(image.height - 1, Math.ceil(y1));
    for (let y = top; y <= bottom; y += 1) {
      for (let x = left; x <= right; x += 1) {
        total += luminance(pixelAt(image, x, y));
        count += 1;
      }
    }
    return count ? total / count : 0;
  }

  function partitionEvidence(image, size) {
    const cellW = image.width / size;
    const cellH = image.height / size;
    const samples = [];
    const sideWindowX = Math.max(2, Math.round(cellW * .08));
    const sideWindowY = Math.max(2, Math.round(cellH * .08));
    for (let col = 1; col < size; col += 1) {
      const x = col * cellW;
      for (let row = 0; row < size; row += 1) {
        const y = (row + .5) * cellH;
        const leftTile = bandMean(image, x - sideWindowX * 2, x - sideWindowX, y - cellH * .18, y + cellH * .18);
        const rightTile = bandMean(image, x + sideWindowX, x + sideWindowX * 2, y - cellH * .18, y + cellH * .18);
        const gap = bandMean(image, x - 1, x + 1, y - cellH * .18, y + cellH * .18);
        samples.push(Math.max(0, (Math.min(leftTile, rightTile) - gap) / 255));
      }
    }
    for (let row = 1; row < size; row += 1) {
      const y = row * cellH;
      for (let col = 0; col < size; col += 1) {
        const x = (col + .5) * cellW;
        const topTile = bandMean(image, x - cellW * .18, x + cellW * .18, y - sideWindowY * 2, y - sideWindowY);
        const bottomTile = bandMean(image, x - cellW * .18, x + cellW * .18, y + sideWindowY, y + sideWindowY * 2);
        const gap = bandMean(image, x - cellW * .18, x + cellW * .18, y - 1, y + 1);
        samples.push(Math.max(0, (Math.min(topTile, bottomTile) - gap) / 255));
      }
    }
    if (!samples.length) return 0;
    const strong = samples.filter(value => value > .025).length / samples.length;
    const average = samples.reduce((sum, value) => sum + value, 0) / samples.length;
    return average * 100 + strong * 18;
  }

  function calibratedBoardSize(canvas) {
    const known = [
      { size: 4, internal: 302, css: 241.92 },
      { size: 5, internal: 378, css: 302.4 },
      { size: 6, internal: 454, css: 362.88 },
      { size: 7, internal: 529, css: 423.36 },
      { size: 8, internal: 605, css: 483.84 },
      { size: 9, internal: 544, css: 544.32 },
    ];
    const internal = Math.max(Number(canvas.width) || 0, Number(canvas.height) || 0);
    const css = canvasRect(canvas);
    const cssSize = css ? Math.max(css.width, css.height) : 0;
    const byInternal = known.reduce((best, item) => Math.abs(item.internal - internal) < Math.abs(best.internal - internal) ? item : best, known[0]);
    const byCss = known.reduce((best, item) => Math.abs(item.css - cssSize) < Math.abs(best.css - cssSize) ? item : best, known[0]);
    if (internal && Math.abs(byInternal.internal - internal) <= 28) return byInternal.size;
    if (cssSize && Math.abs(byCss.css - cssSize) <= 24) return byCss.size;
    return null;
  }

  function inferBoardGeometry(canvas, image) {
    const calibratedSize = calibratedBoardSize(canvas);
    if (calibratedSize) {
      const gapX = image.width / calibratedSize;
      const gapY = image.height / calibratedSize;
      return makeBoard(canvas, image, calibratedSize, Array.from({ length: calibratedSize }, (_, i) => gapX * (i + .5)), Array.from({ length: calibratedSize }, (_, i) => gapY * (i + .5)));
    }
    let best = null;
    for (let size = 4; size <= 9; size += 1) {
      const evidence = partitionEvidence(image, size);
      const score = evidence + size * .01;
      if (!best || score > best.score) best = { size, score };
    }
    const size = best && best.score >= .35 ? best.size : 4;
    const gapX = image.width / size;
    const gapY = image.height / size;
    return makeBoard(canvas, image, size, Array.from({ length: size }, (_, i) => gapX * (i + .5)), Array.from({ length: size }, (_, i) => gapY * (i + .5)));
  }

  function makeBoard(canvas, image, size, xs, ys) {
    const cellWidth = image.width / size;
    const cellHeight = image.height / size;
    const cells = [];
    const blueCells = [];
    const canvasCss = canvasRect(canvas);
    const scaleX = canvasCss.width / image.width;
    const scaleY = canvasCss.height / image.height;
    for (let row = 0; row < size; row += 1) {
      for (let col = 0; col < size; col += 1) {
        const leftPx = col * cellWidth;
        const topPx = row * cellHeight;
        const sampleLeft = leftPx + cellWidth * .25;
        const sampleTop = topPx + cellHeight * .25;
        const sampleRight = leftPx + cellWidth * .75;
        const sampleBottom = topPx + cellHeight * .75;
        let blueSamples = 0;
        let totalSamples = 0;
        for (let sy = sampleTop; sy <= sampleBottom; sy += Math.max(2, cellHeight / 3)) {
          for (let sx = sampleLeft; sx <= sampleRight; sx += Math.max(2, cellWidth / 3)) {
            totalSamples += 1;
            if (isBluePixel(pixelAt(image, sx, sy))) blueSamples += 1;
          }
        }
        const blue = totalSamples > 0 && blueSamples / totalSamples >= .12;
        const rect = {
          left: canvasCss.left + leftPx * scaleX,
          top: canvasCss.top + topPx * scaleY,
          width: cellWidth * scaleX,
          height: cellHeight * scaleY,
        };
        rect.right = rect.left + rect.width;
        rect.bottom = rect.top + rect.height;
        const cell = { row: row + 1, col: col + 1, blue, rect };
        cells.push(cell);
        if (blue) blueCells.push({ row: row + 1, col: col + 1 });
      }
    }
    return { canvas, canvasCss, size, xs, ys, cells, blueCells, tileCount: cells.length };
  }

  function showGridOverlay(board) {
    removeOverlay();
    const layer = document.createElement('div');
    layer.id = OVERLAY_ID;
    layer.style.cssText = 'position:fixed;inset:0;z-index:2147483646;pointer-events:none;opacity:.5;font-family:Arial,sans-serif;';
    const label = document.createElement('div');
    label.textContent = `${board.size}×${board.size} CANVAS GRID`;
    label.style.cssText = `position:fixed;left:${Math.max(4, board.canvasCss.left)}px;top:${Math.max(4, board.canvasCss.top - 22)}px;padding:3px 7px;border:1px solid #c4c7cc;border-radius:5px;background:rgba(17,24,39,.9);color:#e5e7eb;font:600 10px/1 Arial,sans-serif;letter-spacing:.06em;`;
    layer.appendChild(label);
    for (const cell of board.cells) {
      const box = document.createElement('div');
      box.style.cssText = `position:fixed;left:${cell.rect.left}px;top:${cell.rect.top}px;width:${cell.rect.width}px;height:${cell.rect.height}px;box-sizing:border-box;border:2px solid ${cell.blue ? '#67e8f9' : '#aeb4bc'};background:${cell.blue ? 'rgba(34,211,238,.16)' : 'rgba(156,163,175,.08)'};border-radius:7px;`;
      layer.appendChild(box);
    }
    const outline = document.createElement('div');
    outline.style.cssText = `position:fixed;left:${board.canvasCss.left - 2}px;top:${board.canvasCss.top - 2}px;width:${board.canvasCss.width + 4}px;height:${board.canvasCss.height + 4}px;box-sizing:border-box;border:2px solid #aeb4bc;border-radius:9px;`;
    layer.appendChild(outline);
    document.documentElement.appendChild(layer);
    window.setTimeout(() => layer.remove(), 7000);
  }

  async function sample() {
    const found = findGameCanvas();
    if (!found) return { ok: false, error: 'Could not find the Memory canvas.' };
    const image = await readCanvas(found.canvas);
    if (!image) return { ok: false, error: 'Canvas pixels could not be read.' };
    const board = inferBoardGeometry(found.canvas, image);
    return {
      ok: true,
      boardSize: board.size,
      rows: board.size,
      cols: board.size,
      tileCount: board.tileCount,
      blueCount: board.blueCells.length,
      blueCells: board.blueCells,
      cells: board.cells,
      diagnostic: `${board.size}×${board.size} canvas · ${board.blueCells.length} blue · ${board.tileCount} cells`,
      canvasDetected: true,
      capturedAt: Date.now(),
    };
  }

  function showCaptureOverlay(result) {
    const left = Math.min(...result.cells.map(cell => cell.rect.left));
    const top = Math.min(...result.cells.map(cell => cell.rect.top));
    const right = Math.max(...result.cells.map(cell => cell.rect.right));
    const bottom = Math.max(...result.cells.map(cell => cell.rect.bottom));
    showGridOverlay({
      size: result.boardSize,
      cells: result.cells,
      canvasCss: { left, top, width: right - left, height: bottom - top },
    });
  }

  async function scanRevealWindow() {
    removeOverlay();
    const started = Date.now();
    let best = null;
    let attempts = 0;
    let stable = 0;
    let lastBlueCount = -1;
    while (Date.now() - started < FAST_SCAN_MAX_MS) {
      const current = await sample();
      attempts += 1;
      if (current.ok) {
        if (!best || current.blueCount > best.blueCount) best = current;
        if (current.blueCount === lastBlueCount) stable += 1;
        else stable = 0;
        lastBlueCount = current.blueCount;
        if (current.blueCount > 0 && stable >= 2) {
          best = current.blueCount >= (best?.blueCount || 0) ? current : best;
          break;
        }
      }
      await wait(12);
    }
    const result = best || await sample();
    if (result.ok) {
      result.diagnostic = `${result.boardSize}×${result.boardSize} canvas · ${result.blueCount} blue · ${result.tileCount} cells · ${attempts} samples`;
      lastCapture = result;
      removeOverlay();
    }
    return result;
  }

  function pointerInit(x, y) {
    return { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true };
  }

  function tapCanvasPoint(canvas, x, y) {
    const init = pointerInit(x, y);
    try { canvas.dispatchEvent(new PointerEvent('pointermove', { ...init, buttons: 0 })); } catch (_error) { canvas.dispatchEvent(new MouseEvent('mousemove', init)); }
    try { canvas.dispatchEvent(new PointerEvent('pointerdown', init)); } catch (_error) { canvas.dispatchEvent(new MouseEvent('mousedown', init)); }
    try { canvas.dispatchEvent(new PointerEvent('pointerup', { ...init, buttons: 0 })); } catch (_error) { canvas.dispatchEvent(new MouseEvent('mouseup', { ...init, buttons: 0 })); }
    canvas.dispatchEvent(new MouseEvent('click', { ...init, buttons: 0 }));
  }

  function shuffled(items) {
    const copy = [...items];
    for (let index = copy.length - 1; index > 0; index -= 1) {
      const swap = Math.floor(Math.random() * (index + 1));
      [copy[index], copy[swap]] = [copy[swap], copy[index]];
    }
    return copy;
  }

  async function clickCaptured({ randomMix = false } = {}) {
    if (!lastCapture?.ok || !lastCapture.blueCells?.length) return { ok: false, error: 'Scan blue tiles first.' };
    const total = lastCapture.blueCells.length;
    const correctCount = randomMix ? Math.max(1, Math.min(total, Math.ceil(total * fillAccuracy / 100))) : total;
    const randomCount = total - correctCount;
    const found = findGameCanvas();
    if (!found) return { ok: false, error: 'Memory canvas is no longer visible.' };
    const rect = found.rect;
    const size = lastCapture.boardSize;
    const capturedKeys = new Set(lastCapture.blueCells.map(cell => `${cell.row}:${cell.col}`));
    const allCells = Array.from({ length: size * size }, (_, index) => ({ row: Math.floor(index / size) + 1, col: (index % size) + 1 }));
    const correctCells = shuffled(lastCapture.blueCells).slice(0, correctCount);
    const randomPool = shuffled(allCells.filter(cell => !capturedKeys.has(`${cell.row}:${cell.col}`)));
    const randomCells = [];
    for (let index = 0; index < randomCount; index += 1) {
      randomCells.push(randomPool[index % Math.max(1, randomPool.length)] || allCells[index % allCells.length]);
    }
    const cellsToTap = shuffled([...correctCells, ...randomCells]);
    const targets = cellsToTap.map(cell => ({
      row: cell.row,
      col: cell.col,
      correct: capturedKeys.has(`${cell.row}:${cell.col}`),
      x: rect.left + ((cell.col - .5) / size) * rect.width,
      y: rect.top + ((cell.row - .5) / size) * rect.height,
    }));
    for (const target of targets) {
      tapCanvasPoint(found.canvas, target.x, target.y);
      await wait(FAST_TAP_DELAY);
    }
    return { ok: true, clicked: targets.length, capturedCount: correctCount, randomCount, accuracy: randomMix ? fillAccuracy : 100, boardSize: size, targets };
  }

  async function tapAnyCells() {
    return clickCaptured({ randomMix: true });
  }

  async function probeUntilNextRound(size) {
    const found = findGameCanvas();
    if (!found || !size) return { probed: 0 };
    const rect = found.rect;
    const total = size * size;
    const cells = Array.from({ length: total }, (_, index) => ({ row: Math.floor(index / size) + 1, col: (index % size) + 1 }));
    for (let index = cells.length - 1; index > 0; index -= 1) {
      const swap = Math.floor(Math.random() * (index + 1));
      [cells[index], cells[swap]] = [cells[swap], cells[index]];
    }
    const captured = new Set((lastCapture?.blueCells || []).map(cell => `${cell.row}:${cell.col}`));
    let probed = 0;
    for (const cell of cells) {
      if (captured.has(`${cell.row}:${cell.col}`)) continue;
      const x = rect.left + ((cell.col - .5) / size) * rect.width;
      const y = rect.top + ((cell.row - .5) / size) * rect.height;
      tapCanvasPoint(found.canvas, x, y);
      probed += 1;
      await wait(PROBE_TAP_DELAY);
      if (probed >= MAX_PROBE_CLICKS) break;
      const current = await sample();
      if (current.ok && current.blueCount > 0) break;
    }
    return { probed };
  }

  function stopAutomaticModes() {
    autoEnabled = false;
    autoFillEnabled = false;
    autoBusy = false;
    autoSawReveal = false;
    autoRunId += 1;
    autoFillRunId += 1;
    removeOverlay();
  }

  async function autoLoop(runId) {
    while (autoEnabled && runId === autoRunId) {
      try {
        const probe = await sample();
        if (!probe.ok) {
          autoBusy = false;
          autoSawReveal = false;
          await wait(250);
          continue;
        }

        const blueNow = probe.blueCount > 0;
        if (!autoBusy && blueNow) {
          lastCapture = probe;
          autoSawReveal = true;
        } else if (!autoBusy && autoFillEnabled && autoSawReveal && !blueNow && lastCapture?.blueCells?.length) {
          autoBusy = true;
          autoSawReveal = false;
          const filled = await clickCaptured({ randomMix: false });
          autoBusy = false;
          if (!filled.ok) {
            autoBusy = false;
            autoSawReveal = false;
            await wait(250);
            continue;
          }
          await wait(420);
        }
      } catch (_error) {
        stopAutomaticModes();
        break;
      }
      await wait(42);
    }
  }

  function setAuto(enabled) {
    autoEnabled = !!enabled;
    autoRunId += 1;
    autoSawReveal = false;
    autoBusy = false;
    if (!autoEnabled) {
      autoFillEnabled = false;
      autoFillRunId += 1;
    } else {
      autoLoop(autoRunId);
    }
    return { ok: true, enabled: autoEnabled, autoFillEnabled };
  }

  function setAutoFill(enabled) {
    if (enabled && !autoEnabled) return { ok: false, error: 'Turn Scanner ON first.' };
    autoFillEnabled = !!enabled;
    autoFillRunId += 1;
    if (!autoFillEnabled) autoSawReveal = false;
    return { ok: true, enabled: autoFillEnabled, autoEnabled };
  }

  function setFillAccuracy(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return { ok: false, error: 'Invalid accuracy.' };
    fillAccuracy = Math.max(10, Math.min(100, Math.round(numeric / 10) * 10));
    return { ok: true, accuracy: fillAccuracy };
  }

  async function scanOrFill() {
    const probe = await sample();
    if (probe.ok && probe.blueCount > 0) {
      lastCapture = probe;
      removeOverlay();
      return { ...probe, mode: 'scan', diagnostic: `${probe.boardSize}×${probe.boardSize} · ${probe.blueCount} blue · instant scan` };
    }
    if (lastCapture?.ok && lastCapture.blueCells?.length) {
      const filled = await clickCaptured();
      const probeResult = await probeUntilNextRound(filled.boardSize);
      return { ...filled, ...probeResult, mode: 'fill', capture: lastCapture };
    }
    return { ok: false, error: 'No blue reveal or previous capture found.' };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'MIND_SNAP_AUTO_TOGGLE') {
      sendResponse(setAuto(message.enabled));
      return false;
    }
    if (message?.type === 'MIND_SNAP_AUTO_STATE') {
      sendResponse({ ok: true, enabled: autoEnabled, autoFillEnabled, accuracy: fillAccuracy });
      return false;
    }
    if (message?.type === 'MIND_SNAP_AUTO_FILL_TOGGLE') {
      sendResponse(setAutoFill(message.enabled));
      return false;
    }
    if (message?.type === 'MIND_SNAP_SET_ACCURACY') {
      sendResponse(setFillAccuracy(message.accuracy));
      return false;
    }
    if (message?.type === 'MIND_SNAP_FILL_CAPTURED') {
      clickCaptured({ randomMix: false }).then(result => sendResponse({ ...result, mode: 'fill', capture: lastCapture })).catch(error => sendResponse({ ok: false, error: error?.message || 'Fill failed.' }));
      return true;
    }
    if (message?.type === 'MIND_SNAP_TAP_ANY') {
      tapAnyCells().then(sendResponse).catch(error => sendResponse({ ok: false, error: error?.message || 'Random tapping failed.' }));
      return true;
    }
    if (message?.type === 'MIND_SNAP_SCAN_OR_FILL') {
      scanOrFill().then(sendResponse).catch(error => sendResponse({ ok: false, error: error?.message || 'Scan/fill failed.' }));
      return true;
    }
    if (message?.type === 'MIND_SNAP_SCAN') {
      scanRevealWindow().then(sendResponse).catch(error => sendResponse({ ok: false, error: error?.message || 'Scan failed.' }));
      return true;
    }
    if (message?.type === 'MIND_SNAP_GET_LAST') {
      sendResponse(lastCapture || { ok: false, error: 'No capture yet.' });
      return false;
    }
    if (message?.type === 'MIND_SNAP_CLICK_CAPTURED') {
      clickCaptured().then(sendResponse).catch(error => sendResponse({ ok: false, error: error?.message || 'Clicking failed.' }));
      return true;
    }
    return false;
  });

  restorePersistentSettings();
})();

}
