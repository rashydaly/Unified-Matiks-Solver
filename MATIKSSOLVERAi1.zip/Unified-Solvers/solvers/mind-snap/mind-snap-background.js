const REQUEST_TYPES = new Set([
  'MIND_SNAP_SCAN',
  'MIND_SNAP_GET_LAST',
  'MIND_SNAP_CLICK_CAPTURED',
  'MIND_SNAP_SCAN_OR_FILL',
  'MIND_SNAP_AUTO_TOGGLE',
  'MIND_SNAP_AUTO_STATE',
  'MIND_SNAP_FILL_CAPTURED',
  'MIND_SNAP_TAP_ANY',
  'MIND_SNAP_AUTO_FILL_TOGGLE',
  'MIND_SNAP_SET_ACCURACY',
  'MIND_SNAP_CONTENT_READY',
]);

const SETTINGS_KEY = 'mindsnapSettings';
const DEFAULT_SETTINGS = {
  scannerEnabled: false,
  autoSolverEnabled: false,
  accuracy: 50,
};
let settingsPromise = null;

function isSupportedTab(tab) {
  return /^https:\/\/(?:[^/]+\.)?matiks\.com\//i.test(tab?.url || '');
}

async function getSettings() {
  if (!settingsPromise) {
    settingsPromise = chrome.storage.local.get(SETTINGS_KEY).then(({ [SETTINGS_KEY]: saved }) => ({
      ...DEFAULT_SETTINGS,
      ...(saved && typeof saved === 'object' ? saved : {}),
    }));
  }
  return settingsPromise;
}

async function saveSettings(patch) {
  const current = await getSettings();
  const next = { ...current, ...patch };
  settingsPromise = Promise.resolve(next);
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return next;
}

async function getTargetTab(message, sender) {
  const requestedTabId = Number.isInteger(message?.tabId) ? message.tabId : null;
  if (requestedTabId !== null) return chrome.tabs.get(requestedTabId);
  if (sender?.tab?.id !== undefined) return chrome.tabs.get(sender.tab.id);
  const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return activeTab || null;
}

async function sendToContent(tab, message) {
  if (!tab?.id) throw new Error('No active tab found. Open Mind Snap on matiks.com first.');
  if (!isSupportedTab(tab)) throw new Error('Open the Mind Snap game on matiks.com before using the solver.');

  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch (firstError) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['solvers/mind-snap/mind-snap-content.js'] });
      return await chrome.tabs.sendMessage(tab.id, message);
    } catch (secondError) {
      const detail = secondError?.message || firstError?.message || 'The page scanner could not be loaded.';
      throw new Error(`Could not load the page scanner: ${detail}`);
    }
  }
}

async function persistSuccessfulSetting(message, result) {
  if (!result?.ok) return;
  if (message.type === 'MIND_SNAP_AUTO_TOGGLE') {
    await saveSettings({
      scannerEnabled: !!result.enabled,
      autoSolverEnabled: !!result.autoFillEnabled,
    });
  } else if (message.type === 'MIND_SNAP_AUTO_FILL_TOGGLE') {
    await saveSettings({
      scannerEnabled: !!result.autoEnabled,
      autoSolverEnabled: !!result.enabled,
    });
  } else if (message.type === 'MIND_SNAP_SET_ACCURACY') {
    await saveSettings({ accuracy: Number(result.accuracy) || DEFAULT_SETTINGS.accuracy });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!REQUEST_TYPES.has(message?.type)) return false;

  if (message.type === 'MIND_SNAP_CONTENT_READY') {
    getSettings()
      .then(settings => sendResponse({ ok: true, ...settings }))
      .catch(error => sendResponse({ ok: false, error: error?.message || 'Could not restore solver settings.' }));
    return true;
  }

  (async () => {
    const tab = await getTargetTab(message, sender);
    const result = await sendToContent(tab, message);
    await persistSuccessfulSetting(message, result);
    return result;
  })()
    .then(sendResponse)
    .catch(error => sendResponse({ ok: false, error: error?.message || 'Could not communicate with the Memory board.' }));

  return true;
});
