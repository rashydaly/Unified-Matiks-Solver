const $ = id => document.getElementById(id);

let busy = false;
let scannerEnabled = false;
let autoSolverEnabled = false;
let accuracy = 50;
let lastCapturedAt = 0;
let captureSyncInFlight = false;

$('autoButton').addEventListener('click', async () => {
  if (busy) return;
  const next = !scannerEnabled;
  $('autoButton').disabled = true;
  try {
    const result = await sendToActiveTab({ type: 'MIND_SNAP_AUTO_TOGGLE', enabled: next });
    if (!result?.ok) throw new Error(result?.error || 'Could not change Scanner mode.');
    scannerEnabled = !!result.enabled;
    autoSolverEnabled = !!result.autoFillEnabled;
    updateModeButtons();
    setStatus(scannerEnabled ? 'Scanner ON · auto scan only' : 'Scanner OFF · all scanning stopped', scannerEnabled ? 'good' : 'error');
  } catch (error) {
    setStatus(formatError(error, 'Scanner mode failed.'), 'error');
  } finally {
    $('autoButton').disabled = false;
  }
});

$('fillButton').addEventListener('click', () => runTapAction('MIND_SNAP_FILL_CAPTURED', 'Solving captured pattern…', false));
$('tapAnyButton').addEventListener('click', () => runTapAction('MIND_SNAP_TAP_ANY', 'Random solving…', true));

$('autoFillButton').addEventListener('click', async () => {
  if (busy) return;
  const next = !autoSolverEnabled;
  $('autoFillButton').disabled = true;
  try {
    const result = await sendToActiveTab({ type: 'MIND_SNAP_AUTO_FILL_TOGGLE', enabled: next });
    if (!result?.ok) throw new Error(result?.error || 'Turn Scanner ON first.');
    autoSolverEnabled = !!result.enabled;
    scannerEnabled = !!result.autoEnabled;
    updateModeButtons();
    setStatus(autoSolverEnabled ? 'Auto Solver ON' : 'Auto Solver OFF', autoSolverEnabled ? 'good' : '');
  } catch (error) {
    setStatus(formatError(error, 'Auto Solver failed.'), 'error');
  } finally {
    $('autoFillButton').disabled = false;
  }
});

$('accuracySelect').addEventListener('change', async () => {
  accuracy = Number($('accuracySelect').value);
  try {
    const result = await sendToActiveTab({ type: 'MIND_SNAP_SET_ACCURACY', accuracy });
    if (!result?.ok) throw new Error(result?.error || 'Could not set accuracy.');
    accuracy = Number(result.accuracy) || accuracy;
    $('accuracySelect').value = String(accuracy);
    setStatus(`Accuracy set to ${accuracy}%`, 'good');
  } catch (error) {
    setStatus(formatError(error, 'Accuracy update failed.'), 'error');
  }
});

async function runTapAction(type, progressText, usesRandomAccuracy) {
  if (busy) return;
  busy = true;
  setActionButtonsDisabled(true);
  const displayedAccuracy = usesRandomAccuracy ? accuracy : 100;
  setStatus(`${progressText} ${displayedAccuracy}%`, 'active');
  try {
    const result = await sendToActiveTab({ type });
    if (!result?.ok) throw new Error(result?.error || 'Tap action failed.');
    if (result.capture?.ok) renderCapture(result.capture);
    const count = result.clicked ?? result.capturedCount ?? result.randomCount ?? 0;
    setStatus(`${count} tap${count === 1 ? '' : 's'} sent · ${displayedAccuracy}% correct`, 'good');
  } catch (error) {
    setStatus(formatError(error, 'Tap action failed.'), 'error');
  } finally {
    busy = false;
    setActionButtonsDisabled(false);
  }
}

async function sendToActiveTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error('No active tab found. Open Mind Snap on matiks.com first.');
  return chrome.runtime.sendMessage({ ...message, tabId: tab.id });
}

function formatError(error, fallback) {
  const message = String(error?.message || error || fallback);
  return message.replace(/^Error:\s*/i, '').trim() || fallback;
}

async function syncModes() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'MIND_SNAP_CONTENT_READY' });
    if (result?.ok) {
      scannerEnabled = !!(result.scannerEnabled ?? result.enabled);
      autoSolverEnabled = !!(result.autoSolverEnabled ?? result.autoFillEnabled);
      accuracy = Number(result.accuracy) || accuracy;
      $('accuracySelect').value = String(accuracy);
      updateModeButtons();
    }
  } catch (_error) {
    // The popup can still be opened on non-game tabs; show a useful state only when an action is attempted.
  }
}

async function syncLastCapture() {
  if (captureSyncInFlight) return;
  captureSyncInFlight = true;
  try {
    const result = await sendToActiveTab({ type: 'MIND_SNAP_GET_LAST' });
    if (result?.ok && result.capturedAt && result.capturedAt > lastCapturedAt) {
      lastCapturedAt = result.capturedAt;
      renderCapture(result);
      if (!busy) setStatus(`${result.boardSize}×${result.boardSize} · ${result.blueCount} blue · captured`, 'good');
    }
  } catch (_error) {
    // Ignore non-game tabs and tabs that are still loading.
  } finally {
    captureSyncInFlight = false;
  }
}

function setActionButtonsDisabled(disabled) {
  $('fillButton').disabled = disabled;
  $('tapAnyButton').disabled = disabled;
}

function updateModeButtons() {
  $('autoButton').textContent = `Scanner: ${scannerEnabled ? 'ON' : 'OFF'}`;
  $('autoButton').setAttribute('aria-pressed', String(scannerEnabled));
  $('autoButton').classList.toggle('enabled', scannerEnabled);
  $('autoFillButton').textContent = `Auto Solver: ${autoSolverEnabled ? 'ON' : 'OFF'}`;
  $('autoFillButton').setAttribute('aria-pressed', String(autoSolverEnabled));
  $('autoFillButton').classList.toggle('enabled', autoSolverEnabled);
}

function setStatus(text, state = '') {
  $('statusText').textContent = text;
  $('statusDot').className = `status-dot${state ? ` ${state}` : ''}`;
}

function renderCapture(capture) {
  const size = Number(capture.boardSize) || Math.max(Number(capture.rows) || 0, Number(capture.cols) || 0);
  if (!Number.isInteger(size) || size < 1 || size > 20) throw new Error('Board size was not detected.');
  const active = new Set((capture.blueCells || []).map(cell => `${cell.row}:${cell.col}`));
  const board = $('miniBoard');
  board.replaceChildren();
  board.style.setProperty('--size', String(size));

  for (let row = 1; row <= size; row += 1) {
    for (let col = 1; col <= size; col += 1) {
      const tile = document.createElement('span');
      const captured = active.has(`${row}:${col}`);
      tile.className = `mini-tile${captured ? ' captured' : ''}`;
      tile.title = `Row ${row}, Column ${col}${captured ? ' · blue during reveal' : ''}`;
      tile.setAttribute('aria-label', tile.title);
      board.appendChild(tile);
    }
  }

  lastCapturedAt = Math.max(lastCapturedAt, Number(capture.capturedAt) || 0);
  $('boardMeta').textContent = `${size}×${size} · ${Number(capture.blueCount) || active.size} blue`;
  $('boardCard').hidden = false;
  $('emptyCard').hidden = true;
  const boardWidth = board.getBoundingClientRect().width;
  if (boardWidth > 0) board.style.height = `${boardWidth}px`;
}

updateModeButtons();
syncModes();
syncLastCapture();
window.setInterval(syncLastCapture, 420);
