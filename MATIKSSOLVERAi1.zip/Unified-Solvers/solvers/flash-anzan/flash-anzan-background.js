/**
 * Flash Anzan Solver — Manifest V3 service worker.
 * Owns persisted state and coordinates the popup with the Matiks page.
 */

import {
  addNumber,
  createInitialState,
  normalizeState,
  resetState,
  setAutoMode,
  setStatus,
} from './flash-anzan-solver.js';

const MATIKS_URL = /^https:\/\/(?:www\.)?matiks\.com\//i;
const STORAGE_KEY = 'flashAnzanState';
const ROUND_TIMEOUT_MS = 1200;
const AUTO_FILL_RETRY_DELAY_MS = 450;
const MAX_AUTO_FILL_RETRIES = 4;

let autoFillTimerId = null;
let roundTabId = null;
let capturedInRound = 0;
let detectionQueue = Promise.resolve();

chrome.runtime.onInstalled.addListener(() => {
  ensureInitialState().catch((error) => console.error('[Flash Anzan] Could not initialize storage:', error));
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab?.url || !MATIKS_URL.test(tab.url)) return;
  readState()
    .then((state) => {
      if (!state.autoMode) return;
      roundTabId = tabId;
      return sendToContentScript(tabId, { type: 'START_AUTO_SCAN' });
    })
    .catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return undefined;

  if (message.type === 'RESET_SUM') {
    resetAndPublish()
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Reset failed.' }));
    return true;
  }

  if (message.type === 'FLASH_ANZAN_FILL_ANSWER') {
    fillAnswerAndReset(message.tabId)
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not fill the answer.' }));
    return true;
  }

  if (message.type === 'SET_AUTO_MODE') {
    toggleAutoMode(Boolean(message.enabled), message.tabId)
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not change Auto Mode.' }));
    return true;
  }

  if (message.type === 'AUTO_NUMBER_DETECTED') {
    detectionQueue = detectionQueue
      .then(() => processAutoNumber(message, sender.tab?.id))
      .catch((error) => console.debug('[Flash Anzan] Ignored auto capture:', error));
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'FLASH_ANZAN_GET_STATE') {
    readState()
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not read state.' }));
    return true;
  }

  return undefined;
});

async function toggleAutoMode(enabled, requestedTabId) {
  const current = await readState();

  if (enabled) {
    const tab = await resolveTargetTab(requestedTabId);
    assertMatiksTab(tab);

    // Persist the enabled state before starting the scan so the first immediate
    // detection cannot be discarded by the service worker.
    const activeState = setAutoMode(current, true);
    await publishState(activeState);
    roundTabId = tab.id;
    capturedInRound = 0;
    clearAutoFillTimer();

    try {
      await sendToContentScript(tab.id, { type: 'START_AUTO_SCAN' });
      return activeState;
    } catch (error) {
      const failedState = setStatus(setAutoMode(activeState, false), error?.message || 'Could not start Auto Mode.', 'error');
      await publishState(failedState);
      roundTabId = null;
      throw error;
    }
  }

  const tab = await resolveTargetTab(requestedTabId).catch(() => null);
  if (tab?.id) await sendToContentScript(tab.id, { type: 'STOP_AUTO_SCAN' }).catch(() => {});
  clearAutoFillTimer();
  capturedInRound = 0;
  roundTabId = null;

  const updated = setAutoMode(current, false);
  await publishState(updated);
  return updated;
}

async function processAutoNumber(message, tabId) {
  const state = await readState();
  const number = Number(message.number);
  if (!state.autoMode || !Number.isSafeInteger(number)) return;

  capturedInRound += 1;
  roundTabId = Number.isInteger(tabId) ? tabId : roundTabId;
  const updated = addNumber(state, number, message.matched || {});
  await publishState(updated);

  clearAutoFillTimer();
  autoFillTimerId = setTimeout(() => {
    tryAutoFillAfterSilence(roundTabId, 0).catch((error) => console.debug('[Flash Anzan] Auto fill pending:', error));
  }, ROUND_TIMEOUT_MS);
}

async function tryAutoFillAfterSilence(tabId, attempt) {
  const state = await readState();
  if (!state.autoMode || capturedInRound === 0 || !state.history.length || !Number.isInteger(tabId)) return;

  const answer = String(state.sum);
  const response = await sendToContentScript(tabId, { type: 'FLASH_ANZAN_FILL_ANSWER', answer }).catch(() => null);

  if (response?.ok) {
    const finished = resetState(state);
    finished.status = `Answer ${answer} filled. Ready for the next round.`;
    finished.lastFilledAnswer = answer;
    capturedInRound = 0;
    roundTabId = tabId;
    clearAutoFillTimer();
    await publishState(finished);
    return;
  }

  if (attempt < MAX_AUTO_FILL_RETRIES) {
    autoFillTimerId = setTimeout(() => {
      tryAutoFillAfterSilence(tabId, attempt + 1).catch(() => {});
    }, AUTO_FILL_RETRY_DELAY_MS);
    return;
  }

  await publishState(setStatus(state, 'Round complete. The answer area is not ready yet.', 'complete'));
}

async function resetAndPublish() {
  const state = resetState(await readState());
  capturedInRound = 0;
  clearAutoFillTimer();
  await publishState(state);
  return state;
}

async function fillAnswerAndReset(requestedTabId) {
  const tab = await resolveTargetTab(requestedTabId);
  assertMatiksTab(tab);

  const current = await readState();
  const answer = String(current.sum);
  const response = await sendToContentScript(tab.id, { type: 'FLASH_ANZAN_FILL_ANSWER', answer });
  if (!response?.ok) throw new Error(response?.error || 'No visible answer area found.');

  const ready = resetState(current);
  ready.status = `Answer ${answer} filled. Ready for the next round.`;
  ready.lastFilledAnswer = answer;
  capturedInRound = 0;
  clearAutoFillTimer();
  await publishState(ready);
  return ready;
}

function clearAutoFillTimer() {
  if (autoFillTimerId !== null) {
    clearTimeout(autoFillTimerId);
    autoFillTimerId = null;
  }
}

async function resolveTargetTab(requestedTabId) {
  if (Number.isInteger(requestedTabId)) return chrome.tabs.get(requestedTabId);
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error('No active browser tab available.');
  return tab;
}

function assertMatiksTab(tab) {
  if (!MATIKS_URL.test(tab?.url || '')) throw new Error('Open a Matiks game page in the active tab.');
}

async function sendToContentScript(tabId, message) {
  if (!Number.isInteger(tabId)) throw new Error('No active Matiks tab found.');
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (firstError) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['solvers/flash-anzan/flash-anzan-content.js'] });
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (secondError) {
      throw new Error(secondError?.message || firstError?.message || 'Could not reach the game page. Refresh the Matiks tab and try again.');
    }
  }
}

async function ensureInitialState() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  if (!stored[STORAGE_KEY]) await chrome.storage.local.set({ [STORAGE_KEY]: createInitialState() });
}

async function readState() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const state = normalizeState(stored[STORAGE_KEY] || createInitialState());
  const staleStatus = /ocr|96px|montserrat-600|screenshot|capture context/i.test(state.status);
  if (staleStatus) {
    state.status = state.autoMode ? 'Auto Mode is on. Scanning the active Matiks tab…' : 'Ready. Open a Matiks game to begin.';
    state.stage = state.autoMode ? 'capturing' : 'idle';
  }
  return state;
}

async function publishState(state) {
  const normalized = { ...normalizeState(state), updatedAt: Date.now() };
  await chrome.storage.local.set({ [STORAGE_KEY]: normalized });
  try {
    await chrome.runtime.sendMessage({ type: 'FLASH_ANZAN_STATE_UPDATED', state: normalized });
  } catch {
    // The popup may be closed; persisted storage remains authoritative.
  }
  return normalized;
}
