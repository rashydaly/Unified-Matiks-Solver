/**
 * Flash Anzan Solver — pure state helpers shared by the service worker.
 */

const MAX_HISTORY = 60;

export function createInitialState() {
  return {
    sum: 0,
    history: [],
    status: 'Ready. Open a Matiks game to begin.',
    stage: 'idle',
    autoMode: false,
    updatedAt: Date.now(),
  };
}

export function addNumber(state, value, metadata = {}) {
  const number = Number(value);
  if (!Number.isSafeInteger(number)) throw new Error('Only whole numbers within the safe integer range can be captured.');

  const current = normalizeState(state);
  const nextSum = current.sum + number;
  if (!Number.isSafeInteger(nextSum)) throw new Error('The running sum is outside the safe integer range.');

  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    number,
    runningSum: nextSum,
    capturedAt: Date.now(),
    fontSize: Number.isFinite(Number(metadata.fontSize)) ? Number(metadata.fontSize) : 96,
    fontFamily: metadata.fontFamily || 'Montserrat',
  };

  return {
    ...current,
    sum: nextSum,
    history: [entry, ...current.history].slice(0, MAX_HISTORY),
    status: `Captured ${formatSignedNumber(number)} · Running total: ${formatNumber(nextSum)}`,
    stage: 'complete',
    updatedAt: Date.now(),
    lastDetection: metadata,
  };
}

export function resetState(state = {}) {
  const current = normalizeState(state);
  return {
    ...current,
    sum: 0,
    history: [],
    status: current.autoMode ? 'Auto Mode is on. Waiting for flash numbers…' : 'Sum reset to zero. Ready.',
    stage: current.autoMode ? 'capturing' : 'idle',
    lastDetection: null,
    lastFilledAnswer: null,
    updatedAt: Date.now(),
  };
}

export function setStatus(state, status, stage = 'idle') {
  return { ...normalizeState(state), status: String(status || 'Ready.'), stage, updatedAt: Date.now() };
}

export function setAutoMode(state, autoMode) {
  const enabled = Boolean(autoMode);
  const current = normalizeState(state);
  return {
    ...current,
    autoMode: enabled,
    status: enabled ? 'Auto Mode is on. Scanning the active Matiks tab…' : 'Auto Mode is off.',
    stage: enabled ? 'capturing' : 'idle',
    updatedAt: Date.now(),
  };
}

export function formatNumber(value) {
  return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0, useGrouping: false }).format(Number(value) || 0);
}

function formatSignedNumber(value) {
  const number = Number(value) || 0;
  return number > 0 ? `+${formatNumber(number)}` : formatNumber(number);
}

export function normalizeState(state) {
  const fallback = createInitialState();
  const source = state && typeof state === 'object' ? state : {};
  const sum = Number(source.sum);
  const history = Array.isArray(source.history)
    ? source.history
        .filter((entry) => entry && Number.isSafeInteger(Number(entry.number)))
        .map((entry) => ({
          ...entry,
          number: Number(entry.number),
          runningSum: Number.isSafeInteger(Number(entry.runningSum)) ? Number(entry.runningSum) : 0,
        }))
        .slice(0, MAX_HISTORY)
    : [];

  return {
    ...fallback,
    ...source,
    sum: Number.isSafeInteger(sum) ? sum : 0,
    history,
    autoMode: Boolean(source.autoMode),
    stage: ['idle', 'capturing', 'complete', 'error'].includes(source.stage) ? source.stage : 'idle',
    status: String(source.status || fallback.status),
  };
}
