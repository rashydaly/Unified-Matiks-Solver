const elements = {
  resetButton: document.querySelector('#resetButton'),
  autoModeToggle: document.querySelector('#autoModeToggle'),
  statusDot: document.querySelector('#statusDot'),
  statusDotText: document.querySelector('#statusDotText'),
  answerValue: document.querySelector('#answerValue'),
  captureCount: document.querySelector('#captureCount'),
  historyList: document.querySelector('#historyList'),
  historyCount: document.querySelector('#historyCount'),
  statusLog: document.querySelector('#statusLog'),
};

const fallbackState = {
  sum: 0,
  history: [],
  status: 'Ready. Turn Auto Capture on before starting a round.',
  stage: 'idle',
  autoMode: false,
};

let currentState = { ...fallbackState };
let busy = false;

initialize().catch((error) => renderError(error?.message || 'Could not initialize the popup.'));

async function initialize() {
  elements.resetButton?.addEventListener('click', () => performAction('RESET_SUM'));
  elements.autoModeToggle?.addEventListener('change', () => toggleAutoMode());

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'FLASH_ANZAN_STATE_UPDATED' && message.state) renderState(message.state, { animate: true });
  });

  const response = await chrome.runtime.sendMessage({ type: 'FLASH_ANZAN_GET_STATE' });
  renderState(response?.ok && response.result ? response.result : fallbackState);
}

async function toggleAutoMode() {
  if (busy || !elements.autoModeToggle) return;

  const enabled = elements.autoModeToggle.checked;
  setBusy(true);
  setStatus(enabled ? 'Starting Auto Capture…' : 'Stopping Auto Capture…', enabled ? 'capturing' : '');

  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const response = await chrome.runtime.sendMessage({
      type: 'SET_AUTO_MODE',
      enabled,
      tabId: tab?.id,
    });
    if (!response?.ok) throw new Error(response?.error || 'Could not change Auto Capture.');
    renderState(response.result || { ...currentState, autoMode: enabled });
  } catch (error) {
    elements.autoModeToggle.checked = !enabled;
    renderError(error?.message || 'Could not change Auto Capture.');
  } finally {
    setBusy(false);
  }
}

async function performAction(type) {
  if (busy) return;

  setBusy(true);
  setStatus(type === 'RESET_SUM' ? 'Resetting the running sum…' : 'Working…');

  try {
    const response = await chrome.runtime.sendMessage({ type });
    if (!response?.ok) throw new Error(response?.error || 'Action failed. Please try again.');
    if (response.result) renderState(response.result);
  } catch (error) {
    renderError(error?.message || 'Action failed. Please try again.');
  } finally {
    setBusy(false);
  }
}

function renderState(state, options = {}) {
  currentState = normalizeState(state);
  const history = currentState.history;
  const sum = currentState.sum;
  const previousSum = elements.answerValue?.textContent || '';
  const formattedSum = formatInteger(sum);

  if (elements.autoModeToggle) elements.autoModeToggle.checked = currentState.autoMode;
  if (elements.statusDot) elements.statusDot.className = currentState.autoMode ? 'status-dot active' : 'status-dot';
  if (elements.statusDotText) elements.statusDotText.textContent = currentState.autoMode ? 'Auto Active' : 'Auto Off';
  if (elements.answerValue) elements.answerValue.textContent = formattedSum;
  if (elements.captureCount) elements.captureCount.textContent = `${history.length} ${history.length === 1 ? 'capture' : 'captures'}`;
  if (elements.historyCount) elements.historyCount.textContent = `${history.length} ${history.length === 1 ? 'item' : 'items'}`;

  if (options.animate && previousSum !== formattedSum && elements.answerValue) {
    elements.answerValue.classList.remove('bump');
    requestAnimationFrame(() => {
      elements.answerValue.classList.add('bump');
      window.setTimeout(() => elements.answerValue?.classList.remove('bump'), 220);
    });
  }

  renderHistory(history);
  setStatus(currentState.status || 'Ready.', currentState.stage === 'error' ? 'error' : currentState.stage === 'capturing' ? 'capturing' : '');
}

function renderHistory(history) {
  if (!elements.historyList) return;
  elements.historyList.replaceChildren();

  if (!history.length) {
    const placeholder = document.createElement('div');
    placeholder.className = 'history-placeholder';
    placeholder.textContent = currentState.autoMode ? 'Waiting for the next flash number…' : 'Turn Auto Capture on to begin';
    elements.historyList.append(placeholder);
    return;
  }

  history.forEach((entry, index) => {
    const row = document.createElement('div');
    row.className = 'history-item';

    const indexEl = document.createElement('span');
    indexEl.className = 'history-index';
    indexEl.textContent = String(index + 1).padStart(2, '0');

    const numberEl = document.createElement('span');
    numberEl.className = 'history-number';
    numberEl.textContent = formatSignedInteger(entry.number);

    const runningEl = document.createElement('span');
    runningEl.className = 'history-running';
    runningEl.textContent = formatInteger(entry.runningSum);

    row.append(indexEl, numberEl, runningEl);
    elements.historyList.append(row);
  });
}

function setBusy(disabled) {
  busy = disabled;
  for (const element of [elements.resetButton, elements.autoModeToggle]) {
    if (element) element.disabled = disabled;
  }
}

function setStatus(message, state = '') {
  if (!elements.statusLog) return;
  elements.statusLog.textContent = message;
  elements.statusLog.className = `status-log${state ? ` ${state}` : ''}`;
}

function renderError(message) {
  setStatus(message, 'error');
}

function normalizeState(state) {
  const history = Array.isArray(state?.history)
    ? state.history.filter((entry) => entry && Number.isFinite(Number(entry.number)))
    : [];
  return {
    ...fallbackState,
    ...(state && typeof state === 'object' ? state : {}),
    sum: Number.isFinite(Number(state?.sum)) ? Number(state.sum) : 0,
    history,
    autoMode: Boolean(state?.autoMode),
  };
}

function formatInteger(value) {
  return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0, useGrouping: false }).format(Number(value) || 0);
}

function formatSignedInteger(value) {
  const number = Number(value) || 0;
  return number > 0 ? `+${formatInteger(number)}` : formatInteger(number);
}
