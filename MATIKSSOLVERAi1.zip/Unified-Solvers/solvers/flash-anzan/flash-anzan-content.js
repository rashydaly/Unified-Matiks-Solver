if (!globalThis.__MATIKS_FLASH_ANZAN_CONTENT_LOADED__) {
  globalThis.__MATIKS_FLASH_ANZAN_CONTENT_LOADED__ = true;
/**
 * Flash Anzan Solver — page-side Auto Capture.
 *
 * The original extension searched every visible div for an integer. That also
 * matched the game's idle/placeholder 0. This version focuses on the actual
 * central flash display, prefers elements under the viewport center, ignores
 * zero placeholders, and requires two consecutive frames before reporting.
 */
(() => {
  const LOADED_FLAG = '__flashAnzanSolverLoaded__';
  if (globalThis[LOADED_FLAG]) return;
  globalThis[LOADED_FLAG] = true;

  const AUTO_SCAN_INTERVAL_MS = 35;
  const TARGET_FONT_SIZE = 96;
  const FONT_SIZE_TOLERANCE = 16;
  const NUMBER_PATTERN = /^[+-]?\d[\d,\s]*$/;
  const NUMBER_ELEMENTS = 'div, span, p, strong, b, h1, h2, h3, output';

  let autoScanTimer = null;
  let lastReportedKey = null;
  let pendingKey = null;
  let pendingDetection = null;
  let pendingFrames = 0;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message.type !== 'string') return undefined;

    if (message.type === 'START_AUTO_SCAN') {
      startAutoScan();
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === 'STOP_AUTO_SCAN') {
      stopAutoScan();
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === 'FLASH_ANZAN_FILL_ANSWER') {
      try {
        sendResponse(fillAnswer(String(message.answer ?? '')));
      } catch (error) {
        console.error('[Flash Anzan] Answer fill failed:', error);
        sendResponse({ ok: false, error: error?.message || 'Could not fill the answer.' });
      }
      return true;
    }

    return undefined;
  });

  function startAutoScan() {
    stopAutoScan();
    scanAndReport();
    autoScanTimer = window.setInterval(scanAndReport, AUTO_SCAN_INTERVAL_MS);
  }

  function stopAutoScan() {
    if (autoScanTimer !== null) {
      window.clearInterval(autoScanTimer);
      autoScanTimer = null;
    }
    lastReportedKey = null;
    pendingKey = null;
    pendingDetection = null;
    pendingFrames = 0;
  }

  function scanAndReport() {
    try {
      const detection = extractCurrentNumber();
      if (detection.number === null) {
        pendingKey = null;
        pendingDetection = null;
        pendingFrames = 0;
        lastReportedKey = null;
        return;
      }

      const key = `${detection.number}|${detection.matched?.text || ''}`;
      if (key === pendingKey) {
        pendingFrames += 1;
      } else {
        pendingKey = key;
        pendingDetection = detection;
        pendingFrames = 1;
      }

      // Two frames filters out idle labels and intermediate React renders while
      // still catching normal flash intervals.
      if (pendingFrames < 2 || key === lastReportedKey) return;
      lastReportedKey = key;
      chrome.runtime.sendMessage({
        type: 'AUTO_NUMBER_DETECTED',
        number: detection.number,
        matched: detection.matched,
      }).catch(() => {});
    } catch (error) {
      console.debug('[Flash Anzan] Waiting for the flash display:', error);
    }
  }

  function extractCurrentNumber() {
    const candidates = [];
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    const centerElements = getCenterElements(centerX, centerY);

    for (const element of document.querySelectorAll(NUMBER_ELEMENTS)) {
      const text = normalizeText(element.innerText || element.textContent || '');
      if (!NUMBER_PATTERN.test(text)) continue;
      if (hasMatchingElementChild(element, text)) continue;

      const parsed = parseInteger(text);
      // A persistent zero is the page's idle value, not a useful flash operand.
      if (!Number.isSafeInteger(parsed) || parsed === 0) continue;

      const style = window.getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      const fontSize = Number.parseFloat(style.fontSize);
      const family = String(style.fontFamily || '').toLowerCase();
      const weight = Number.parseInt(style.fontWeight, 10);
      const hasMontserrat600Family = /montserrat[-\s]?600/.test(family);
      const hasHeavyComputedWeight = Number.isFinite(weight) && weight >= 500;
      if (!isVisibleElement(element, style, rect)) continue;
      if (!Number.isFinite(fontSize) || Math.abs(fontSize - TARGET_FONT_SIZE) > FONT_SIZE_TOLERANCE) continue;
      if (!family.includes('montserrat')) continue;
      if (!hasMontserrat600Family && !hasHeavyComputedWeight) continue;

      const elementCenterX = rect.left + rect.width / 2;
      const elementCenterY = rect.top + rect.height / 2;
      const distanceFromCenter = Math.hypot(elementCenterX - centerX, elementCenterY - centerY);
      const isCenterProbeMatch = centerElements.includes(element);
      const score =
        (isCenterProbeMatch ? 5000 : 0) +
        1200 - Math.min(distanceFromCenter, 1200) * 1.2 -
        Math.abs(fontSize - TARGET_FONT_SIZE) * 12 +
        Math.min(rect.width * rect.height, 200000) / 4000;

      candidates.push({
        number: parsed,
        text,
        fontSize,
        fontFamily: style.fontFamily,
        fontWeight: style.fontWeight,
        minHeight: Number.parseFloat(style.minHeight) || 0,
        left: rect.left,
        top: rect.top,
        score,
      });
    }

    candidates.sort((left, right) => right.score - left.score);
    const best = candidates[0];
    if (!best) return { number: null, candidateCount: 0 };

    return {
      number: best.number,
      candidateCount: candidates.length,
      matched: {
        text: best.text,
        fontSize: best.fontSize,
        fontFamily: best.fontFamily,
        fontWeight: best.fontWeight,
        minHeight: best.minHeight,
        left: best.left,
        top: best.top,
      },
    };
  }

  function getCenterElements(centerX, centerY) {
    if (typeof document.elementsFromPoint !== 'function') return [];
    const points = [
      [centerX, centerY],
      [centerX, centerY - Math.min(80, window.innerHeight / 8)],
      [centerX, centerY + Math.min(80, window.innerHeight / 8)],
    ];
    const elements = [];
    for (const [x, y] of points) {
      for (const element of document.elementsFromPoint(x, y) || []) {
        if (!elements.includes(element)) elements.push(element);
      }
    }
    return elements;
  }

  function hasMatchingElementChild(element, text) {
    return [...element.children].some((child) => normalizeText(child.innerText || child.textContent || '') === text);
  }

  function isVisibleElement(element, style, rect) {
    return Boolean(
      rect.width > 0 && rect.height > 0 &&
      rect.bottom >= 0 && rect.right >= 0 &&
      rect.top <= window.innerHeight && rect.left <= window.innerWidth &&
      style.display !== 'none' && style.visibility !== 'hidden' &&
      style.visibility !== 'collapse' && style.opacity !== '0' &&
      style.contentVisibility !== 'hidden'
    );
  }

  function normalizeText(value) {
    return String(value).replace(/[−–—]/g, '-').replace(/\u00a0/g, ' ').trim();
  }

  function parseInteger(text) {
    return Number.parseInt(normalizeText(text).replace(/[\s,]/g, ''), 10);
  }

  function fillAnswer(answer) {
    if (!/^[+-]?\d+$/.test(answer) || !Number.isSafeInteger(Number(answer))) {
      return { ok: false, error: 'The running sum is not a valid whole number.' };
    }

    const controls = [...document.querySelectorAll('input, textarea, [contenteditable="true"]')]
      .filter(isVisibleEditableControl)
      .sort((left, right) => scoreAnswerField(right) - scoreAnswerField(left));
    const target = controls[0];
    if (!target) return { ok: false, error: 'No visible answer input was found on this Matiks page.' };

    target.focus({ preventScroll: true });
    if (typeof target.select === 'function') target.select();
    if (target.isContentEditable) target.textContent = answer;
    else setNativeValue(target, answer);

    target.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: answer }));
    target.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    return { ok: true, filled: answer, tagName: target.tagName };
  }

  function isVisibleEditableControl(element) {
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const type = String(element.type || '').toLowerCase();
    return Boolean(
      rect.width >= 8 && rect.height >= 8 && style.display !== 'none' &&
      style.visibility !== 'hidden' && style.opacity !== '0' && !element.disabled &&
      !element.readOnly && !['hidden', 'button', 'submit', 'checkbox', 'radio', 'file', 'reset'].includes(type)
    );
  }

  function scoreAnswerField(element) {
    const attributes = [
      element.id, element.name, element.placeholder, element.getAttribute('aria-label'),
      element.getAttribute('autocomplete'), element.getAttribute('data-testid'),
      typeof element.className === 'string' ? element.className : '',
    ].filter(Boolean).join(' ').toLowerCase();

    let score = 0;
    if (/answer|response|result|solution|reply|final|guess/.test(attributes)) score += 60;
    if (element.type === 'number' || element.type === 'tel') score += 25;
    if (element.tagName === 'TEXTAREA' || element.isContentEditable) score += 8;
    if (element.type === 'text') score += 4;
    return score;
  }

  function setNativeValue(element, value) {
    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
    if (descriptor?.set) descriptor.set.call(element, value);
    else element.value = value;
  }
})();

}
