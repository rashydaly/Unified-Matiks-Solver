// Clean isolated solver backgrounds.
import './solvers/ability-duels/ability-duels-background.js';
import './solvers/cross-math/cross-math-background.js';
import './solvers/flash-anzan/flash-anzan-background.js';
import './solvers/ken-ken/ken-ken-background.js';
import './solvers/math-maze/math-maze-background.js';
import './solvers/mind-snap/mind-snap-background.js';
import './solvers/sprint-duel/sprint-duel-background.js';
import './solvers/sudoku/sudoku-background.js';

const activeSolverByTab = new Map();
const contentPaths = {
  'ability-duels': 'solvers/ability-duels/ability-duels-content.js',
  'cross-math': 'solvers/cross-math/cross-math-content.js',
  'flash-anzan': 'solvers/flash-anzan/flash-anzan-content.js',
  'ken-ken': 'solvers/ken-ken/ken-ken-content.js',
  'math-maze': 'solvers/math-maze/math-maze-content.js',
  'mind-snap': 'solvers/mind-snap/mind-snap-content.js',
  'sprint-duel': 'solvers/sprint-duel/sprint-duel-content.js',
  'sudoku': 'solvers/sudoku/sudoku-content.js',
};
const stopMessages = [
  { type: 'SET_AUTO_WATCH', enabled: false },
  { type: 'SET_AUTO_MODE', enabled: false },
  { type: 'PATH_AUTO_STOP' },
  { type: 'MIND_SNAP_AUTO_TOGGLE', enabled: false },
  { type: 'MIND_SNAP_AUTO_FILL_TOGGLE', enabled: false },
  { type: 'SPRINT_DUEL_POPUP_ACTION', action: 'stop' },
  { type: 'SUDOKU_AUTO_STOP' },
];

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'HUB_INJECT_SOLVER') {
    const tabId = Number(message.tabId);
    const path = contentPaths[String(message.solverId || '')];
    if (!Number.isInteger(tabId) || !path) { sendResponse({ ok: false, error: 'Invalid solver or tab.' }); return false; }
    chrome.scripting.executeScript({ target: { tabId }, files: [path] })
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error?.message || 'Could not load solver on this page.' }));
    return true;
  }
  if (message?.type !== 'HUB_SELECT_SOLVER' && message?.type !== 'HUB_CLEAR_SOLVER') return false;
  const tabId = Number(message.tabId);
  if (!Number.isInteger(tabId)) {
    sendResponse({ ok: false, error: 'No active tab found.' });
    return false;
  }
  const previous = activeSolverByTab.get(tabId);
  const next = message.type === 'HUB_CLEAR_SOLVER' ? null : String(message.solverId || '');
  if (previous !== next) {
    Promise.allSettled(stopMessages.map(stop => chrome.tabs.sendMessage(tabId, stop))).catch(() => {});
  }
  if (next) activeSolverByTab.set(tabId, next); else activeSolverByTab.delete(tabId);
  sendResponse({ ok: true, previous, active: next });
  return false;
});

chrome.tabs.onRemoved?.addListener(tabId => activeSolverByTab.delete(tabId));
